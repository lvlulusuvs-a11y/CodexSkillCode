# Git workflow

## Просмотр истории
```bash
git log --oneline --graph -20          # последние 20 коммитов
git log --all --oneline --graph        # вся история
git blame <file>                       # кто и когда менял строки
git log -p -S "function_name"          # когда появился/исчез текст
```

## Работа с изменениями
```bash
git diff                       # unstaged changes
git diff --cached              # staged changes
git diff main..feature         # между ветками
git stash -u                   # спрятать всё, включая новые файлы
git stash pop                  # вернуть
```

## Коммиты (conventional)
```bash
git commit -m "feat: add user login"
git commit -m "fix(api): handle null response"
git commit -m "refactor: extract parse logic"
git commit -m "chore: bump deps"
```

## Отмена изменений
```bash
git checkout -- <file>         # отменить незакоммиченные
git reset HEAD~1               # отменить последний коммит (сохранить файлы)
git reset --hard HEAD~1        # отменить последний коммит (удалить изменения)
git revert <commit>            # безопасный revert (новый коммит)
```
