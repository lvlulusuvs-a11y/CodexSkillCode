# Virtual Environments Guide

## venv
```bash
# Создание
python3 -m venv .venv

# Активация
source .venv/bin/activate  # Linux/Mac
.venv\Scripts\activate     # Windows

# Деактивация
deactivate
```

## uv (быстрая альтернатива)
```bash
# Установка
pip install uv

# Создание и активация
uv venv
source .venv/bin/activate

# Установка пакетов (в 10-100x быстрее pip)
uv pip install -e ".[dev]"

# Lock file
uv pip compile pyproject.toml > requirements.txt
```

## pipenv
```bash
pip install pipenv
pipenv install --dev
pipenv shell
```

## poetry
```bash
poetry new myproject
poetry add requests
poetry add --dev pytest
poetry install
poetry shell
```

## pyenv — управление версиями Python
```bash
pyenv install 3.12.3
pyenv global 3.12.3
pyenv local 3.11.0  # для конкретного проекта
```

## Рекомендация
```bash
# Быстро и современно:
python3 -m venv .venv
source .venv/bin/activate
pip install uv
uv pip install -e ".[dev]"
```
