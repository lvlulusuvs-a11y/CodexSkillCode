# Design Patterns in Python

## Singleton
```python
class Singleton:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

# или через метакласс
class SingletonMeta(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

class Config(metaclass=SingletonMeta):
    pass
```

## Observer
```python
from abc import ABC, abstractmethod
from typing import Any

class Observer(ABC):
    @abstractmethod
    def update(self, event: str, data: Any) -> None: ...

class Subject:
    def __init__(self):
        self._observers: list[Observer] = []

    def attach(self, observer: Observer) -> None:
        self._observers.append(observer)

    def detach(self, observer: Observer) -> None:
        self._observers.remove(observer)

    def notify(self, event: str, data: Any) -> None:
        for observer in self._observers:
            observer.update(event, data)

class Logger(Observer):
    def update(self, event: str, data: Any) -> None:
        print(f"[LOG] {event}: {data}")
```

## Builder
```python
class QueryBuilder:
    def __init__(self):
        self._table = ""
        self._fields = ["*"]
        self._where: list[str] = []
        self._order = ""
        self._limit = 0

    def table(self, name: str) -> "QueryBuilder":
        self._table = name
        return self

    def select(self, *fields: str) -> "QueryBuilder":
        self._fields = list(fields) if fields else ["*"]
        return self

    def where(self, condition: str) -> "QueryBuilder":
        self._where.append(condition)
        return self

    def order_by(self, field: str, asc: bool = True) -> "QueryBuilder":
        self._order = f"{field} {'ASC' if asc else 'DESC'}"
        return self

    def limit(self, n: int) -> "QueryBuilder":
        self._limit = n
        return self

    def build(self) -> str:
        sql = f"SELECT {', '.join(self._fields)} FROM {self._table}"
        if self._where:
            sql += " WHERE " + " AND ".join(self._where)
        if self._order:
            sql += " ORDER BY " + self._order
        if self._limit:
            sql += f" LIMIT {self._limit}"
        return sql

# Usage
query = (QueryBuilder()
         .table("users")
         .select("id", "name", "email")
         .where("age > 18")
         .where("active = true")
         .order_by("name")
         .limit(10)
         .build())
```

## Adapter
```python
class JSONLogger:
    def log_json(self, data: dict) -> None:
        import json
        print(json.dumps(data, indent=2))

class XMLLogger:
    def log_xml(self, data: str) -> None:
        print(f"<log>{data}</log>")

class LoggerAdapter:
    def __init__(self, logger: JSONLogger):
        self._logger = logger

    def log(self, message: str) -> None:
        self._logger.log_json({"message": message, "level": "info"})

# Usage
json_logger = JSONLogger()
adapter = LoggerAdapter(json_logger)
adapter.log("Hello Adapter!")  # {"message": "Hello Adapter!", "level": "info"}
```
