# Testing Strategies

**Реальные стратегии тестирования для продакшена. Не "как писать тесты", а "что и когда тестировать".**

---

## I. Пирамида тестов (реальная)

```text
         ╱╲
        ╱ E2E ╲         3-5% — критические сценарии
       ╱────────╲
      ╱ Integration ╲   15-20% — взаимодействие модулей
     ╱──────────────╲
    ╱   Unit Tests    ╲  75-80% — изолированная логика
   ╱────────────────────╲
```

**Правило:**
- Unit-тесты — быстрые (мс), изолированные (моки), покрывают логику
- Integration — поднимают БД/API, проверяют связку
- E2E — полный сценарий, только критические пути

**Не делай:**
- E2E на каждую мелочь (медленно, хрупко)
- Unit без моков на внешние сервисы (тестируешь сеть)
- 100% coverage как самоцель (бессмысленные тесты)

## II. Что тестировать (приоритеты)

### 🔴 Обязательно (без этого — баги в проде)
- **Core бизнес-логика** — расчёты, валидация, статусы
- **Edge cases** — пустой ввод, null, граничные значения
- **Обработка ошибок** — что если БД упала, API не отвечает
- **Безопасность** — SQL injection, XSS, авторизация

### 🟡 Желательно (сэкономит время при рефакторинге)
- **Repository слой** — запросы к БД (интеграционные)
- **API handlers** — статусы ответов, валидация
- **Serialization** — правильные поля, форматы

### 🟢 Хорошо бы (но не критично)
- **UI компоненты** — рендер, клики
- **Configuration** — все комбинации настроек
- **Performance tests** — под нагрузкой

### ⚪ Не трать время
- **Геттеры/сеттеры** (без логики)
- **Plain dataclasses** (без __post_init__)
- **Тривиальные delegation** (обёртки без логики)
- **Тесты на тесты** (coverage 100% ради цифры)

## III. Паттерны тестирования

### 1. Arrange-Act-Assert (AAA) — стандарт

```python
def test_discount_calculation() -> None:
    # Arrange
    order = Order(total=1000, user=User(tier="gold"))
    
    # Act
    discount = calculate_discount(order)
    
    # Assert
    assert discount == 100  # 10% для gold
```

### 2. Given-When-Then (BDD-style)

```python
def test_order_status_transition() -> None:
    # Given новый заказ
    order = Order(status=OrderStatus.PENDING)
    
    # When подтверждаем
    order.confirm()
    
    # Then статус изменился
    assert order.status == OrderStatus.CONFIRMED
```

### 3. Test Parametrization

```python
import pytest

@pytest.mark.parametrize("total,tier,expected", [
    (100, "regular", 0),
    (500, "regular", 25),    # 5%
    (1000, "regular", 50),   # 5% (не 10%)
    (100, "gold", 10),       # 10%
    (1000, "gold", 100),     # 10%
    (5000, "gold", 500),     # 10% (не больше)
    (0, "regular", 0),
    (-100, "regular", 0),    # edge case
])
def test_discount(total: int, tier: str, expected: float) -> None:
    assert calculate_discount(Order(total=total, user=User(tier=tier))) == expected
```

### 4. Fixtures with Cleanup

```python
@pytest_asyncio.fixture
async def db_session():
    """Фикстура с cleanup."""
    session = AsyncSession(engine)
    async with session.begin():
        yield session
    # cleanup автоматически: rollback несохранённого

@pytest_asyncio.fixture
async def test_user(db_session) -> User:
    """Создать тестового пользователя."""
    user = User(name="Test", email="test@example.com")
    db_session.add(user)
    await db_session.flush()
    yield user
    # cleanup: удалить после теста
    await db_session.delete(user)
    await db_session.flush()
```

### 5. Mock External Services

```python
from unittest.mock import AsyncMock, patch

@pytest.mark.asyncio
async def test_send_notification() -> None:
    # Мокаем внешний сервис
    email_service = AsyncMock()
    email_service.send.return_value = True
    
    # Тестируем
    result = await notify_user(
        user_id=1,
        message="Hello",
        email_service=email_service,
    )
    
    assert result is True
    email_service.send.assert_called_once_with(
        to="user@example.com",
        subject="Notification",
        body="Hello",
    )
```

### 6. Integration Test with Test Container

```python
import pytest
import asyncpg

@pytest.mark.asyncio
async def test_user_crud(postgres_container: str) -> None:
    """Тест с реальной PostgreSQL."""
    conn = await asyncpg.connect(postgres_container)
    try:
        # Create
        await conn.execute(
            "INSERT INTO users (name, email) VALUES ($1, $2)",
            "Test", "test@example.com",
        )
        
        # Read
        row = await conn.fetchrow(
            "SELECT * FROM users WHERE email = $1",
            "test@example.com",
        )
        assert row["name"] == "Test"
    finally:
        await conn.close()
```

## IV. Как тестировать асинхронный код

### Основные принципы

```python
import pytest
from unittest.mock import AsyncMock, patch

# Асинхронные тесты
@pytest.mark.asyncio
async def test_async_service() -> None:
    result = await my_async_function()
    assert result == expected

# Моки для async функций
async def test_with_async_mock() -> None:
    mock = AsyncMock()
    mock.fetch.return_value = {"id": 1}
    
    result = await service.get_data(mock)
    assert result["id"] == 1

# Контекстный менеджер async mock
async def test_with_async_context_manager() -> None:
    mock = AsyncMock()
    mock.__aenter__.return_value = mock
    
    async with mock as m:
        pass  # работает

# Таймауты для тестов (защита от вечно висящих)
@pytest.mark.asyncio
@pytest.mark.timeout(5)
async def test_with_timeout() -> None:
    result = await potentially_slow_function()
    assert result is not None
```

## V. Как тестировать работу с БД

### Стратегии
1. **In-memory SQLite** — быстро, подходит для тестов с SQLAlchemy
2. **Testcontainers** — реальная БД в Docker, медленно, но надёжно
3. **Фикстуры с транзакциями** — rollback после каждого теста

### Пример с SQLAlchemy (in-memory)

```python
@pytest_asyncio.fixture
async def async_engine():
    engine = create_async_engine("sqlite+aiosqlite://", echo=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()

@pytest_asyncio.fixture
async def session(async_engine) -> AsyncIterator[AsyncSession]:
    async with AsyncSession(async_engine, expire_on_commit=False) as sess:
        async with sess.begin():
            yield sess
            await sess.rollback()  # откат после каждого теста
```

## VI. Test Coverage (реальное использование)

```bash
# Запуск с coverage
pytest --cov=src --cov-report=term-missing --cov-report=html

# Проверить только изменённые файлы
pytest --cov=$(git diff --name-only main | grep '\.py$' | tr '\n' ' ')

# Игнорировать тесты, __init__.py, manage.py
# .coveragerc:
[run]
omit = */tests/*, */migrations/*, *__init__*, setup.py
```

**Реальные цели coverage:**
- 80%+ — хорошо
- 90%+ — отлично
- 60-80% — нормально для легаси
- <60% — тревожный сигнал

**Важно:** 100% coverage ≠ нет багов. Самое важное — покрытие бизнес-логики и edge cases.

## VII. Test Doubles Guide

| Тип | Когда использовать | Пример |
|-----|-------------------|--------|
| **Dummy** | Нужен параметр, который не используется | `None`, `MagicMock()` |
| **Fake** | Нужна работающая, но упрощённая реализация | in-memory DB вместо PostgreSQL |
| **Stub** | Нужен предсказуемый ответ | `mock.return_value = 42` |
| **Spy** | Нужно проверить, что вызвалось | `assert mock.call_count == 1` |
| **Mock** | Нужно проверить, как вызвалось | `mock.assert_called_with(1, 2)` |

**Fake example:**
```python
class FakeUserRepo:
    """In-memory реализация UserRepository для тестов."""
    def __init__(self) -> None:
        self._users: dict[int, User] = {}
        self._next_id = 1
    
    async def add(self, user: User) -> User:
        user.id = self._next_id
        self._next_id += 1
        self._users[user.id] = user
        return user
    
    async def get(self, user_id: int) -> User | None:
        return self._users.get(user_id)

# В тесте:
repo = FakeUserRepo()
service = UserService(repo)
await service.register("test@example.com")
user = await repo.get(1)
assert user.email == "test@example.com"
```

## VIII. Когда НЕ писать тест

- **Одноразовый скрипт** — миграция данных, разовый импорт
- **Prototype/Proof of concept** — выкинешь после проверки
- **UI, который меняется каждый спринт** — тесты будут мешать
- **Очевидный код** — тривиальные геттеры/сеттеры
- **Чужая ответственность** — не тестируй библиотеки

## IX. Bad Test Smells

```python
# ❌ Тест тестирует две вещи
def test_user_creation_and_validation():
    ...

# ✅ Раздели
def test_user_creation():
    ...

def test_user_validation():
    ...

# ❌ Тест зависит от других тестов
def test_user():  # предполагает, что test_setup уже выполнился
    ...

# ✅ Каждый тест независим
@pytest.fixture
def user():
    return User(name="Test")

def test_user_has_name(user):
    assert user.name == "Test"

# ❌ Тест использует реальную сеть
def test_external_api():
    response = requests.get("https://api.example.com/data")
    assert response.status_code == 200  # упадёт без интернета

# ✅ Мокаем внешние вызовы
def test_external_api(mock_api):
    mock_api.get.return_value = Mock(status_code=200)
    ...

# ❌ Тест проверяет реализацию, а не поведение
def test_sort():
    items = [3, 1, 2]
    result = sort(items)
    assert result == [1, 2, 3]
    assert items is not result  # ❌ проверка, что вернул НОВЫЙ список, а не изменил старый
    # Если реализация изменится — тест упадёт, хотя поведение верное

# ✅ Проверяй поведение
def test_sort_does_not_mutate_input():
    items = [3, 1, 2]
    result = sort(items)
    assert result == [1, 2, 3]
    # sorted() не меняет исходный

# ❌ Хрупкий тест (тестирует слишком много)
def test_api_response():
    response = client.get("/users/1")
    assert response.json() == {
        "id": 1, "name": "Alice", "email": "alice@example.com",
        "created_at": "2024-01-01T00:00:00", # ❌ depends on exact timestamp
        "orders_count": 5,
        ...
    }

# ✅ Тестируй только важное
def test_api_returns_user_data():
    response = client.get("/users/1")
    data = response.json()
    assert data["id"] == 1
    assert data["name"] == "Alice"
    assert response.status_code == 200
```

## X. Quick Start: минимальный набор фикстур

```python
# conftest.py
import pytest_asyncio
from typing import AsyncIterator
from unittest.mock import AsyncMock

@pytest_asyncio.fixture
async def db() -> AsyncIterator[...]:
    """In-memory БД для тестов."""
    engine = create_async_engine("sqlite+aiosqlite://")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with AsyncSession(engine) as session:
        yield session
    await engine.dispose()

@pytest.fixture
def mock_email() -> AsyncMock:
    """Mock email сервиса."""
    return AsyncMock()

@pytest.fixture
def user_repo(db) -> UserRepository:
    """Repository с реальной in-memory БД."""
    return UserRepository(db)

@pytest.fixture
def user_service(user_repo, mock_email) -> UserService:
    """Сервис с реальным repo и mock email."""
    return UserService(repo=user_repo, email_service=mock_email)
```
