# Data Structures Guide

**Когда что использовать. Выбор структуры данных = 80% производительности.**

---

## Core Structures

### List vs Tuple vs Array

```python
# List — mutable, разнородные, частые вставки/удаления
items: list[int] = [1, 2, 3]

# Tuple — immutable, хэшируемый (ключ в dict), распаковка
point: tuple[int, int] = (10, 20)
d: dict[tuple[int, int], str] = {point: "home"}

# Array — однородные числа, меньше памяти
from array import array
numbers: array[int] = array("i", [1, 2, 3])  # ~4 bytes per element

# Что выбрать:
# ╔══════════╦════════════════════════════╦══════════════════════════╗
# ║ Нужно    ║ Выбрать                   ║ Почему                   ║
# ╠══════════╬════════════════════════════╬══════════════════════════╣
# ║ Изменять ║ List, Array               ║ mutable                   ║
# ║ Хэшировать║ Tuple                     ║ immutable → __hash__      ║
# ║ Экономия пам.║ Array, tuple (без __dict__) ║ меньше overhead      ║
# ║ Быстрый доступ║ List, Array, Tuple   ║ O(1) index               ║
# ╚══════════╩════════════════════════════╩══════════════════════════╝
```

### Dict vs defaultdict vs Counter

```python
from collections import defaultdict, Counter

# dict — general purpose
user = {"name": "Alice", "age": 30}

# defaultdict — auto-default для missing keys
grouped: defaultdict[str, list[int]] = defaultdict(list)
for item in items:
    grouped[item.type].append(item.id)  # не надо проверять существование

# Counter — подсчёт элементов
text = "hello world"
freq = Counter(text)
# Counter({'l': 3, 'o': 2, 'h': 1, 'e': 1, ' ': 1, 'w': 1, 'r': 1, 'd': 1})
print(freq.most_common(3))  # [('l', 3), ('o', 2), ('h', 1)]
```

### Set vs frozenset

```python
# Set — mutable, нехэшируемый
unique = {1, 2, 3}
unique.add(4)

# frozenset — immutable, хэшируемый (можно в set of sets)
immutable = frozenset([1, 2, 3])
set_of_sets = {frozenset([1, 2]), frozenset([3, 4])}
```

### deque (double-ended queue)

```python
from collections import deque

# O(1) вставка/удаление с обоих концов
queue: deque[str] = deque(maxlen=100)  # fixed size queue

queue.append("right")     # O(1)
queue.appendleft("left")  # O(1)
queue.pop()               # O(1)
queue.popleft()           # O(1)

# Использовать для:
# - Очередь задач
# - Rolling window (maxlen)
# - BFS в графах
```

### Heapq (priority queue)

```python
import heapq

# list как min-heap
heap = [3, 1, 4, 1, 5]
heapq.heapify(heap)        # O(n) → [1, 1, 4, 3, 5]
heapq.heappush(heap, 2)    # O(log n)
smallest = heapq.heappop(heap)  # O(log n)

# Max-heap через отрицательные значения
max_heap = [-x for x in [3, 1, 4]]
heapq.heapify(max_heap)
largest = -heapq.heappop(max_heap)  # 4

# N largest/smallest
top_3 = heapq.nlargest(3, [3, 1, 4, 1, 5])  # [5, 4, 3]
```

### Namedtuple vs Dataclass

```python
from typing import NamedTuple
from dataclasses import dataclass

# NamedTuple — immutable, легковесный, сравнение по значению
class Point(NamedTuple):
    x: float
    y: float

p1 = Point(1.0, 2.0)
p2 = Point(1.0, 2.0)
assert p1 == p2  # True
assert hash(p1) == hash(p2)  # да, хэшируемый

# Dataclass — mutable, гибкий, методы
@dataclass(frozen=True)  # frozen = immutable
class User:
    id: int
    name: str
    
    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("name required")

# Когда что:
# NamedTuple: маленькие value objects, совместимость с tuple
# Dataclass: сложная логика, валидация, мутабельность
```

## Advanced Structures

### ChainMap (multiple dicts as one)

```python
from collections import ChainMap

# Объединяет dicts без копирования
defaults = {"host": "localhost", "port": 8080, "debug": False}
overrides = {"port": 9000, "debug": True}

config = ChainMap(overrides, defaults)  # overrides приоритет
print(config["host"])  # localhost (from defaults)
print(config["port"])  # 9000 (from overrides)
print(config["debug"]) # True (from overrides)
```

### OrderedDict (insertion order)

```python
from collections import OrderedDict

# Python 3.7+: dict сохраняет порядок
# OrderedDict нужен для:
# 1. move_to_end()
# 2. popitem(last=False) — FIFO

cache = OrderedDict()

# LRU cache реализация:
def lru_get(key: str) -> Any | None:
    if key not in cache:
        return None
    cache.move_to_end(key)  # обновить позицию
    return cache[key]

def lru_put(key: str, value: Any, maxsize: int = 100) -> None:
    if key in cache:
        cache.move_to_end(key)
    cache[key] = value
    if len(cache) > maxsize:
        cache.popitem(last=False)  # удалить самый старый
```

### Weak references

```python
import weakref

# Ссылка, не увеличивающая refcount
class ExpensiveObject:
    pass

# WeakValueDictionary — значения удаляются, если на них нет ссылок
cache = weakref.WeakValueDictionary[int, ExpensiveObject]()

# WeakSet — set из слабых ссылок
from weakref import WeakSet

class EventListener:
    pass

listeners = WeakSet[EventListener]()

# Использовать для:
# - Кэш объектов (автоочистка)
# - Наблюдатели (не мешать GC)
# - Tree structures (родитель — слабая ссылка на детей)
```

## Time Complexity Reference

| Structure | Index | Search | Insert | Delete | Memory |
|-----------|-------|--------|--------|--------|--------|
| list | O(1) | O(n) | O(n)* | O(n) | Низкая |
| tuple | O(1) | O(n) | - | - | Низкая |
| set | - | O(1) | O(1) | O(1) | Средняя |
| dict | - | O(1) | O(1) | O(1) | Средняя |
| deque | O(1) | O(n) | O(1) | O(1) | Низкая |
| heap | - | O(n) | O(log n) | - | Низкая |
| array | O(1) | O(n) | O(1)* | O(1)* | Очень низкая |
| str | O(1) | O(n) | - | - | Низкая |
| bytes | O(1) | O(n) | - | - | Очень низкая |

*Insert в список O(1) в конце, O(n) в начале.
*Array: append O(1), insert O(n).

## Quick Decision Tree

```
Нужно хранить элементы?
├─ Важен порядок?
│  ├─ Да → list (изменяемый) / tuple (фикс)
│  └─ Нет → set (уникальные) / list (неуникальные)
├─ Важен поиск?
│  ├─ По ключу → dict
│  ├─ По значению, много → set (если уникальные)
│  └─ По значению, мало → list (простой перебор)
├─ Нужна очередь?
│  ├─ FIFO → deque
│  ├─ Priority → heap
│  └─ Lifo → list (pop/append)
└─ Нужен счётчик?
   └─ Counter (collections)
```
