# Pydantic v2 Guide

## BaseModel
```python
from pydantic import BaseModel, Field, EmailStr, HttpUrl
from datetime import datetime
from typing import Any

class UserCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(ge=0, le=150, default=0)
    website: HttpUrl | None = None
    tags: list[str] = Field(default_factory=list)

    @field_validator("name")
    @classmethod
    def name_must_be_valid(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Name cannot be empty")
        return v.strip()

class User(UserCreate):
    id: int
    created_at: datetime

data = {
    "name": "Alice",
    "email": "alice@test.com",
    "id": 1,
    "created_at": "2026-01-01T00:00:00",
}
user = User(**data)
print(user.model_dump_json(indent=2))
```

## Settings
```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "MyApp"
    debug: bool = False
    database_url: str = "sqlite:///db.sqlite3"
    redis_url: str = "redis://localhost:6379/0"
    secret_key: str
    allowed_hosts: list[str] = ["*"]

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}

# .env:
# SECRET_KEY=super-secret-key
# DATABASE_URL=postgresql://user:pass@localhost/db

settings = Settings()
```

## Type Adapters
```python
from pydantic import TypeAdapter
from datetime import date

# Валидация простых типов
int_adapter = TypeAdapter(int)
int_adapter.validate_python("42")  # 42
int_adapter.validate_python("abc")  # ValidationError

# Сложные типы
adapter = TypeAdapter(dict[str, list[int]])
data = adapter.validate_python({"a": [1, 2], "b": [3]})  # OK
data = adapter.validate_python({"a": ["x"]})  # ValidationError
```

## Discriminated Unions
```python
from typing import Literal
from pydantic import BaseModel, Field

class Cat(BaseModel):
    pet_type: Literal["cat"] = "cat"
    meow_volume: int = Field(ge=0, le=100)

class Dog(BaseModel):
    pet_type: Literal["dog"] = "dog"
    bark_volume: int = Field(ge=0, le=100)

class Pet(BaseModel):
    __root__: Cat | Dog

    # discriminated union
    @classmethod
    def from_dict(cls, data: dict) -> "Cat | Dog":
        if data.get("pet_type") == "cat":
            return Cat(**data)
        return Dog(**data)
```

## Serialization
```python
from pydantic import BaseModel
from datetime import datetime

class Event(BaseModel):
    name: str
    timestamp: datetime
    metadata: dict[str, str] = {}

event = Event(
    name="test",
    timestamp=datetime.now(),
    metadata={"key": "value"},
)

# Dict
print(event.model_dump())

# JSON string
print(event.model_dump_json(indent=2))

# Dict with exclude
print(event.model_dump(exclude={"metadata"}))

# By alias
print(event.model_dump(by_alias=True))
```
