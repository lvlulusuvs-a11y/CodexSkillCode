# System Design Reference

**Как проектировать системы. Паттерны, компромиссы, реальные примеры.**

---

## 1. CAP Theorem и выбор БД

```
Consistency (C)  ─────  Availability (A)
        ╲                ╱
         ╲   Partition  ╱
          ╲  Tolerance ╱
           ╲   (P)    ╱
            ╲        ╱
             ╲______╱

Выбирай 2 из 3, но Network Partition неизбежен → выбирай между CP и AP.

┌────────────────────┬────────────────────┬────────────────────┐
│                    │        CP          │        AP          │
├────────────────────┼────────────────────┼────────────────────┤
│ Примеры            │ etcd, Zookeeper,   │ Cassandra,         │
│                    │ Consul            │ DynamoDB, Riak     │
├────────────────────┼────────────────────┼────────────────────┤
│ Когда нужен        │ Финансы,           │ Соцсети,           │
│                    │ заказы,            │ лента новостей,    │
│                    │ блокчейн           │ аналитика          │
├────────────────────┼────────────────────┼────────────────────┤
│ Что жертвуем       │ Доступность при    │ Консистентность    │
│                    │ разделении сети    │ (eventual          │
│                    │                    │ consistency)       │
└────────────────────┴────────────────────┴────────────────────┘

PostgreSQL/MySQL: CA (без разделения сети), CP (с разделением)
MongoDB: CP по умолчанию, AP опционально
Cassandra: AP
Redis: CP (single node), AP (cluster)
```

## 2. Database Selection

```python
# ─── Выбор БД ─────────────────────────────────────────────────────
# PostgreSQL:    Структурированные данные, ACID, сложные запросы
# ClickHouse:    Аналитика, временные ряды, миллиарды строк
# MongoDB:       JSON-документы, гибкая схема, прототипирование
# Redis:         Кэш, сессии, очереди, rate limiting
# Cassandra:     Горизонтальное масштабирование, write-heavy
# Elasticsearch: Полнотекстовый поиск, логи, observability
# S3/MinIO:      Файлы, изображения, бэкапы, большие данные

# ─── SQL vs NoSQL ─────────────────────────────────────────────────
# SQL:
# + ACID, joins, constraints, standardised
# - Вертикальное масштабирование, rigid schema
# Выбирай SQL, пока не докажешь, что нужен NoSQL

# NoSQL:
# + Горизонтальное масштабирование, flexible schema
# - Нет joins, eventual consistency, vendor lock-in
# Выбирай NoSQL, когда:
#   - >10TB данных
#   - Пишешь >100K запросов/сек
#   - Схема данных постоянно меняется
#   - Нужна геораспределённость
```

## 3. API Architecture

### REST
```python
# Ресурсы, HTTP методы, stateless
# ✅ GET /users        → список
# ✅ POST /users       → создать
# ✅ GET /users/1      → один
# ✅ PUT /users/1      → полностью заменить
# ✅ PATCH /users/1    → частично изменить
# ✅ DELETE /users/1   → удалить

# Статусы:
# 200 OK             — успех
# 201 Created        — создано
# 204 No Content     — удалено
# 400 Bad Request    — невалидный запрос
# 401 Unauthorized   — не авторизован
# 403 Forbidden      — нет прав
# 404 Not Found      — не найдено
# 409 Conflict       — конфликт
# 422 Unprocessable  — валидация не прошла
# 429 Too Many       — rate limit
# 500 Internal       — сервер упал
```

### GraphQL
```python
# Один endpoint, клиент выбирает поля
# Плюс: нет over/under-fetching, типизированная схема
# Минус: сложное кэширование, N+1 через resolver'ы
# Когда: сложные клиенты с разными потребностями в данных

# Решение N+1 в GraphQL: DataLoader (batching + caching)
from typing import Any
class UserDataLoader:
    def __init__(self, db):
        self._db = db
        self._cache: dict[int, Any] = {}
        
    async def load(self, user_id: int) -> Any:
        if user_id not in self._cache:
            # Batch load: один SQL запрос для всех ID
            users = await self._db.fetch(
                "SELECT * FROM users WHERE id = ANY($1)",
                list(self._cache.keys()),
            )
            for user in users:
                self._cache[user["id"]] = user
        return self._cache.get(user_id)
```

### gRPC
```python
# Protocol Buffers, HTTP/2, streaming
# Плюс: быстрый (binary), строгая типизация, bidirectional streaming
# Минус: сложный дебаг, нет браузерной поддержки
# Когда: микросервисы, mobile, real-time
```

## 4. Caching Strategies

```
                         ┌──────────────┐
                         │   Client     │
                         └──────┬───────┘
                                │
                         ┌──────▼───────┐
                         │  CDN Cache   │  CloudFlare, Akamai
                         └──────┬───────┘
                                │
                         ┌──────▼───────┐
                         │  App Cache   │  Redis, Memcached
                         └──────┬───────┘
                                │
                         ┌──────▼───────┐
                         │  DB Cache    │  PostgreSQL shared buffers
                         └──────────────┘
```

### Cache-Aside (Lazy Loading)
```python
async def get_user(user_id: int) -> User:
    # 1. Попробовать кэш
    if cached := await redis.get(f"user:{user_id}"):
        return User(**json.loads(cached))
    
    # 2. Промах → БД
    user = await db.get(User, user_id)
    if not user:
        return None
    
    # 3. Заполнить кэш
    await redis.setex(f"user:{user_id}", 300, user.model_dump_json())
    
    return user
```

### Write-Through
```python
async def update_user(user_id: int, data: dict) -> User:
    # Пишем в БД
    user = await db.update(User, user_id, data)
    
    # Пишем в кэш (синхронно с БД)
    await redis.setex(f"user:{user_id}", 300, user.model_dump_json())
    
    return user
```

### Write-Behind (асинхронная запись)
```python
async def update_user(user_id: int, data: dict) -> User:
    # Сразу пишем в кэш (быстрый ответ)
    await redis.setex(f"user:{user_id}", 300, json.dumps(data))
    
    # Отправляем в очередь на запись в БД
    await queue.put(("update_user", user_id, data))
    
    return User(**data)

# Background worker пишет в БД асинхронно
```

### Cache Invalidation
```python
# Сложность: устаревшие данные
# Стратегии:
# 1. TTL (Time To Live) — данные сами умирают
# 2. Event-based — при изменении данных, инвалидировать кэш
# 3. Versioning — версионировать данные, кэш по версии

async def invalidate_by_tag(tag: str) -> None:
    """Инвалидация по тегу."""
    keys = await redis.smembers(f"tag:{tag}")
    if keys:
        await redis.delete(*keys)
        await redis.delete(f"tag:{tag}")

async def set_tagged(key: str, value: Any, tags: list[str]) -> None:
    """Сохранение с тегированием."""
    await redis.setex(key, 300, value)
    for tag in tags:
        await redis.sadd(f"tag:{tag}", key)
```

## 5. Message Queue Patterns

### Когда нужна очередь
- **Decoupling** — producer не знает consumer'ов
- **Buffering** — сглаживание пиков нагрузки
- **Guaranteed delivery** — сообщение не потеряется
- **Fan-out** — одно сообщение → много обработчиков
- **Retry + DLQ** — Dead Letter Queue для упавших сообщений

### Broker сравнение
```python
# Redis List/Stream:  5K msg/s, просто, встроенно
# RabbitMQ:          20K msg/s, routing, ACK, management UI
# Kafka:            100K+ msg/s,持久化, replay, partitioning
# SQS/SNS:           cloud, managed, auto-scaling

# ─── Выбор ───
# Нужна надёжность + routing → RabbitMQ
# Нужен stream + replay → Kafka
# Нужен FIFO просто → Redis List
# Нужен pub/sub просто → Redis Pub/Sub
```

### Пример: надёжный consumer
```python
async def process_messages() -> None:
    consumer = create_consumer("orders")
    
    while True:
        try:
            message = await consumer.receive(timeout=30)
            
            async with message.process():
                # Если упадёт → retry, если retry исчерпан → DLQ
                result = await process_order(message.body)
                
                if not result.success:
                    await message.nack(delay=5.0)  # retry через 5s
                    continue
                
                await message.ack()  # подтвердить обработку
                
        except asyncio.TimeoutError:
            continue
        except Exception as e:
            logger.exception("Fatal consumer error")
            await asyncio.sleep(1)
```

## 6. Microservices Communication

```
               ┌──────────────┐
               │   API GW     │
               └──────┬───────┘
          ┌───────────┼───────────┐
          │           │           │
    ┌─────▼────┐ ┌───▼───┐ ┌────▼────┐
    │  Auth    │ │ User  │ │ Order   │───→ Orders DB
    │  Service │ │ Srv   │ │ Srv     │
    └──────────┘ └───────┘ └────┬────┘
                                │ gRPC/Event
                         ┌──────▼──────┐
                         │  Payment    │───→ Payments DB
                         │  Service    │
                         └─────────────┘
```

### Sync (REST/gRPC)
```python
# Плюс: простота, понятный flow
# Минус: каскадные сбои, latency = sum of all calls

# Защита: timeouts + circuit breaker
async def get_order_details(order_id: int) -> dict:
    order = await order_service.get(order_id)
    
    try:
        payment = await asyncio.wait_for(
            payment_service.get(order.payment_id),
            timeout=3.0,
        )
        order["payment"] = payment
    except (TimeoutError, ServiceError):
        order["payment"] = {"status": "unknown"}
    
    return order
```

### Async (Events/Messages)
```python
# Плюс: слабая связанность, resilience
# Минус: eventual consistency, сложный дебаг

# Пример: Order Created → send event
async def create_order(data: dict) -> Order:
    order = Order(**data)
    await db.save(order)
    
    # Публикуем событие (не ждём обработчиков)
    await event_bus.publish("order.created", {
        "order_id": order.id,
        "user_id": order.user_id,
        "amount": order.total,
    })
    
    return order

# Payment Service слушает и обрабатывает
@event_bus.on("order.created")
async def handle_order_created(event: dict) -> None:
    try:
        payment_id = await payment_service.charge(event["amount"])
        await event_bus.publish("payment.completed", {
            "order_id": event["order_id"],
            "payment_id": payment_id,
        })
    except Exception as e:
        await event_bus.publish("payment.failed", {
            "order_id": event["order_id"],
            "error": str(e),
        })
```

## 7. Error Handling Strategies

### Retry Strategies
```python
# ─── Immediate retry ───
# Для transient errors (connection reset, timeout)
# 1-3 попытки, без задержки

# ─── Exponential backoff ───
# 1s → 2s → 4s → 8s → ...
# Для rate limiting, overload

# ─── Jitter ───
# Добавить случайность: delay ± 20%
# Избежать thundering herd (все retry одновременно)

# ─── Circuit breaker ───
# После N ошибок → не вызывать сервис M секунд
# HALF_OPEN для проверки восстановления
```

### Graceful Degradation
```python
# Вместо падения — вернуть "лучшее из доступного"

async def get_recommendations(user_id: int) -> list[Product]:
    try:
        return await ml_service.recommend(user_id)
    except ServiceError:
        # ML сервис упал — вернуть популярные
        return await product_service.get_popular(limit=10)
    except Exception:
        # Всё плохо — вернуть пусто
        return []
```

## 8. Observability

### Three Pillars
```python
# 1. Logging — структурированные логи
# 2. Metrics — счётчики, гистограммы
# 3. Tracing — трейсинг запросов через сервисы

# RED method (микроcервисы):
# Rate — запросов в секунду
# Errors — ошибки в секунду
# Duration — время обработки

# USE method (инфраструктура):
# Utilization — загрузка ресурса
# Saturation — перегрузка
# Errors — количество ошибок
```

### Minimal Monitoring Setup
```python
# Prometheus + Grafana
# - Request rate, latency (p50, p95, p99), error rate
# - CPU, Memory, DB connections
# - Business metrics (заказы/мин, регистрации/день)

# Health endpoints:
# /health — liveness (сервер жив)
# /ready — readiness (готов принимать трафик)
# /metrics — для Prometheus

from prometheus_client import Counter, Histogram, generate_latest

REQUESTS = Counter("http_requests_total", "Total requests", ["method", "endpoint", "status"])
LATENCY = Histogram("http_request_duration_seconds", "Request latency", ["method", "endpoint"])
```

## 9. Scaling Patterns

### Horizontal Scaling (sharding)
```python
# Деление данных по ключу
# user_id % N → шард N
# Плюс: линейное масштабирование
# Минус: сложные跨шард запросы, rebalancing

class ShardedDB:
    def __init__(self, shards: list[Database]) -> None:
        self._shards = shards
    
    def _get_shard(self, key: str) -> Database:
        return self._shards[hash(key) % len(self._shards)]
    
    async def get(self, key: str) -> Any:
        return await self._get_shard(key).get(key)
    
    async def set(self, key: str, value: Any) -> None:
        await self._get_shard(key).set(key, value)
```

### Bulkhead Pattern
```python
# Изоляция компонентов — проблема в одном не валит всё

class BulkheadPool:
    """Пул с изоляцией по типу запроса."""
    
    def __init__(self) -> None:
        self._pools: dict[str, asyncio.Semaphore] = {}
    
    def add(self, name: str, max_concurrent: int = 10) -> None:
        self._pools[name] = asyncio.Semaphore(max_concurrent)
    
    async def execute(self, pool_name: str, func: Callable) -> Any:
        sem = self._pools.get(pool_name)
        if not sem:
            raise ValueError(f"No pool: {pool_name}")
        
        async with sem:
            return await func()

# Использование
pool = BulkheadPool()
pool.add("auth", max_concurrent=5)   # auth — редко
pool.add("orders", max_concurrent=20) # orders — часто
pool.add("payments", max_concurrent=3) # payments — медленно

await pool.execute("orders", create_order)
```

## 10. Security Patterns

### Token-based Auth
```python
# JWT: stateless, но нельзя отозвать
# Session: stateful (redis), можно отозвать

async def authenticate(request: Request) -> User | None:
    token = request.headers.get("Authorization", "").removeprefix("Bearer ")
    if not token:
        return None
    
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return await user_repo.get(payload["user_id"])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None
```

### Rate Limiting
```python
# Token bucket, Sliding window, Fixed window
# Per-IP, Per-User, Per-Endpoint

class SlidingWindowRateLimiter:
    def __init__(self, max_requests: int = 100, window: float = 60.0):
        self._max = max_requests
        self._window = window
        self._requests: dict[str, list[float]] = {}
    
    def allow(self, key: str) -> bool:
        now = time.monotonic()
        cutoff = now - self._window
        
        # Очистить старые
        if key in self._requests:
            self._requests[key] = [t for t in self._requests[key] if t > cutoff]
        
        # Проверить лимит
        if len(self._requests.get(key, [])) >= self._max:
            return False
        
        # Добавить запрос
        self._requests.setdefault(key, []).append(now)
        return True
```

### Input Validation
```python
# Никогда не доверяй пользовательскому вводу
# Валидация на границе системы (Pydantic, Marshmallow)

from pydantic import BaseModel, Field, EmailStr

class CreateUserSchema(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(ge=0, le=150)
    
    # Дополнительная валидация
    def validate_name(cls, v: str) -> str:
        if any(c in v for c in "<>\"'%"):
            raise ValueError("Invalid characters in name")
        return v.strip()

# SQL injection: always use parameterized queries
await conn.execute("SELECT * FROM users WHERE id = $1", user_id)

# XSS: escape HTML при выводе
import html
safe_html = html.escape(user_input)
```

## Decision Flow

```
Нужно хранить данные?
├─ Структурированные, связи → SQL (PostgreSQL)
├─ Документы, гибкая схема → MongoDB
├─ Ключ-значение, кэш → Redis
├─ Большие файлы → S3/MinIO
├─ Поиск → Elasticsearch
└─ Time-series → ClickHouse / TimescaleDB

Нужна коммуникация?
├─ Синхронная, простые микросервисы → REST/gRPC
├─ Асинхронная, decoupling → Message Queue
├─ Real-time → WebSocket / gRPC stream

Нужна обработка?
├─ API → FastAPI / Django
├─ Batch → Celery / Airflow
├─ Stream → Kafka Streams / Flink
└─ CPU-bound → Multiprocessing / Numba / Rust
```
