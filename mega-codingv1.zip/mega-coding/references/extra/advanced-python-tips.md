# Advanced Python Tips

**Приёмы Python, которые используют senior-разработчики.**

---

## 1. Context Manager for Timing

```python
from contextlib import contextmanager
from time import perf_counter
import logging

logger = logging.getLogger(__name__)

@contextmanager
def timer(name: str = "operation"):
    start = perf_counter()
    try:
        yield
    finally:
        elapsed = perf_counter() - start
        logger.info("%s took %.2fms", name, elapsed * 1000)

# Usage
with timer("database query"):
    users = await db.fetch_all("SELECT * FROM users")
```

## 2. Lazy Initialization with cached_property

```python
from functools import cached_property
import json

class ExpensiveObject:
    @cached_property
    def data(self) -> dict:
        """Computed once, cached forever (or until instance is recreated)."""
        print("Loading data...")
        with open("large_file.json") as f:
            return json.load(f)

obj = ExpensiveObject()
print(obj.data)  # loads
print(obj.data)  # cached
```

## 3. Sentinel Values for Optional Arguments

```python
_sentinel = object()

def get_user(user_id: int, default: Any = _sentinel) -> User:
    if user := db.get(User, user_id):
        return user
    if default is _sentinel:
        raise NotFoundError(f"User {user_id} not found")
    return default

# Usage
get_user(1)  # raises if not found
get_user(1, None)  # returns None if not found
```

## 4. Structural Pattern Matching

```python
from dataclasses import dataclass

@dataclass
class Success:
    data: Any

@dataclass
class Failure:
    error: str
    code: int

def handle(result: Success | Failure) -> str:
    match result:
        case Success(data):
            return f"Success: {data}"
        case Failure(error, code):
            return f"Error {code}: {error}"
```

## 5. Iterator Protocol

```python
class Range:
    def __init__(self, start, end):
        self._start = start
        self._end = end
    
    def __iter__(self):
        return RangeIterator(self._start, self._end)

class RangeIterator:
    def __init__(self, current, end):
        self._current = current
        self._end = end
    
    def __next__(self):
        if self._current >= self._end:
            raise StopIteration
        value = self._current
        self._current += 1
        return value

# Or simpler with generator
def range_gen(start, end):
    while start < end:
        yield start
        start += 1
```

## 6. Context Variables (asyncio)

```python
from contextvars import ContextVar
import uuid

request_id: ContextVar[str] = ContextVar("request_id", default="")

async def handler():
    request_id.set(uuid.uuid4().hex[:8])
    await process()

async def process():
    print(f"Processing request {request_id.get()}")

# Thread-safe, async-safe, no global state issues
```

## 7. Property Descriptors

```python
class PositiveNumber:
    def __set_name__(self, owner, name):
        self._name = f"_{name}"
    
    def __get__(self, obj, objtype=None):
        return getattr(obj, self._name, 0)
    
    def __set__(self, obj, value):
        if value <= 0:
            raise ValueError(f"{self._name[1:]} must be positive")
        setattr(obj, self._name, value)

class Account:
    balance = PositiveNumber()
    
    def __init__(self, balance):
        self.balance = balance  # calls PositiveNumber.__set__

# account.balance = -100 → raises ValueError
```

## 8. __init_subclass__ for Registry

```python
class Plugin:
    _registry: dict[str, type] = {}
    
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls._registry[cls.__name__] = cls

class JSONExporter(Plugin): pass
class CSVExporter(Plugin): pass

print(Plugin._registry)  # {'JSONExporter': ..., 'CSVExporter': ...}
```

## 9. WeakRef for Cache

```python
import weakref

class ObjectCache:
    def __init__(self):
        self._cache = weakref.WeakValueDictionary()
    
    def get(self, key):
        return self._cache.get(key)
    
    def set(self, key, value):
        self._cache[key] = value

# Objects are automatically removed when no external references exist
```

## 10. Dataclass with Validation

```python
from dataclasses import dataclass
from typing import Self

@dataclass(frozen=True)
class User:
    id: int
    name: str
    email: str
    
    def __post_init__(self: Self) -> None:
        if not self.name.strip():
            raise ValueError("Name cannot be empty")
        if "@" not in self.email:
            raise ValueError(f"Invalid email: {self.email}")

# Frozen = immutable, hashable, can be used in sets
```
