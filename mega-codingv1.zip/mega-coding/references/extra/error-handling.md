# Error Handling Patterns

**Как обрабатывать ошибки в продакшене. От 404 до circuit breaker.**

---

## 1. Кастомные исключения

```python
# Иерархия исключений приложения
class AppError(Exception):
    """Base exception for the application."""
    def __init__(self, message: str, code: str | None = None, details: dict | None = None) -> None:
        self.message = message
        self.code = code or self.__class__.__name__
        self.details = details or {}
        super().__init__(self.message)

class NotFoundError(AppError):
    """Resource not found."""
    status_code = 404

class ConflictError(AppError):
    """Resource conflict."""
    status_code = 409

class ValidationError(AppError):
    """Validation failed."""
    status_code = 422

class UnauthorizedError(AppError):
    """Authentication failed."""
    status_code = 401

class ForbiddenError(AppError):
    """Permission denied."""
    status_code = 403

class ServiceError(AppError):
    """External service error."""
    status_code = 502

# Использование
async def get_user(user_id: int) -> User:
    if user := await repo.get(user_id):
        return user
    raise NotFoundError(f"User {user_id} not found", code="USER_NOT_FOUND")
```

## 2. Global Exception Handler (FastAPI)

```python
from fastapi import Request, FastAPI
from fastapi.responses import JSONResponse

def setup_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def app_error_handler(request: Request, exc: AppError) -> JSONResponse:
        logger.warning("app_error", 
                      path=str(request.url),
                      error=exc.message,
                      code=exc.code,
                      details=exc.details)
        return JSONResponse(
            status_code=getattr(exc, "status_code", 500),
            content={
                "error": exc.code,
                "message": exc.message,
                "details": exc.details,
            },
        )
    
    @app.exception_handler(Exception)
    async def unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("unhandled_error", path=str(request.url))
        return JSONResponse(
            status_code=500,
            content={"error": "INTERNAL_ERROR", "message": "Internal server error"},
        )
    
    @app.exception_handler(HTTPException)
    async def http_error_handler(request: Request, exc: HTTPException) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": "HTTP_ERROR", "message": exc.detail},
        )
```

## 3. Error Boundary (Layer Pattern)

```python
# Repository layer — database errors
class UserRepository:
    async def get(self, user_id: int) -> User:
        try:
            return await self._session.get(User, user_id)
        except SQLAlchemyError as e:
            logger.error("db_error", operation="get_user", user_id=user_id, error=str(e))
            raise ServiceError("Database error") from e

# Service layer — business logic errors  
class UserService:
    async def register(self, email: str, password: str) -> User:
        try:
            existing = await self._repo.get_by_email(email)
            if existing:
                raise ConflictError(f"Email {email} already registered")
            return await self._repo.create({"email": email, "password": hash(password)})
        except AppError:
            raise  # пропускаем наши ошибки
        except Exception as e:
            logger.exception("unexpected_error")
            raise ServiceError("Registration failed") from e

# API/Handler layer — catch all, return appropriate response
@router.post("/users")
async def register(data: RegisterSchema, service: UserService = Depends(get_user_service)):
    try:
        user = await service.register(data.email, data.password)
        return UserResponse.from_orm(user)
    except ConflictError as e:
        raise HTTPException(status_code=409, detail=e.message)
```

## 4. Result Type (Functional Error Handling)

```python
from dataclasses import dataclass
from typing import Generic, TypeVar, Any

T = TypeVar("T")
E = TypeVar("E")

@dataclass(frozen=True)
class Ok(Generic[T]):
    value: T

@dataclass(frozen=True)
class Err(Generic[E]):
    error: E

type Result[T, E] = Ok[T] | Err[E]

# Функции возвращают Result вместо исключений
def divide(a: float, b: float) -> Result[float, str]:
    if b == 0:
        return Err("division by zero")
    return Ok(a / b)

def parse_int(s: str) -> Result[int, str]:
    try:
        return Ok(int(s))
    except ValueError:
        return Err(f"cannot parse '{s}' as int")

# Композиция
result = parse_int("42")
match result:
    case Ok(val): print(f"Parsed: {val}")
    case Err(e): print(f"Failed: {e}")

# Chain
def process(input: str) -> Result[float, str]:
    r1 = parse_int(input)
    if isinstance(r1, Err):
        return r1
    return divide(r1.value, 2)
```

## 5. Retry Strategy

```python
import asyncio
from functools import wraps
from typing import ParamSpec, TypeVar

P = ParamSpec("P")
T = TypeVar("T")

# Transient errors — можно retry
TRANSIENT_ERRORS = (
    ConnectionError,
    TimeoutError,
    aiohttp.ClientError,
    asyncpg.TooManyConnectionsError,
)

def with_retry(
    max_attempts: int = 3,
    base_delay: float = 1.0,
    backoff: float = 2.0,
    jitter: float = 0.1,
) -> Callable:
    """Retry with exponential backoff + jitter."""
    def decorator(func: Callable[P, Awaitable[T]]) -> Callable[P, Awaitable[T]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            last_error = None
            wait = base_delay
            
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except TRANSIENT_ERRORS as e:
                    last_error = e
                    if attempt < max_attempts - 1:
                        delay = wait + random.uniform(0, wait * jitter)
                        logger.warning("Retry %d/%d after %.2fs: %s", 
                                     attempt + 1, max_attempts, delay, e)
                        await asyncio.sleep(delay)
                        wait *= backoff
                except Exception as e:
                    # Non-transient — не retry
                    raise
            
            raise last_error  # type: ignore
        return wrapper
    return decorator
```

## 6. Graceful Error Recovery

```python
class GracefulDegradation:
    """Падай gracefully — не обрушивай всё приложение."""
    
    async def get_recommendations(self, user_id: int) -> list[Product]:
        try:
            return await self._ml_service.recommend(user_id)
        except ServiceError:
            logger.warning("ML service down, falling back to popular")
            return await self._popular_products()
        except Exception:
            logger.exception("Unexpected error in recommendations")
            return []  # Пустой список — лучше ошибки

    async def send_notification(self, user_id: int, message: str) -> bool:
        try:
            await self._push_service.send(user_id, message)
            return True
        except Exception as e:
            logger.error("Failed to send notification", error=str(e))
            # Пробуем fallback
            try:
                await self._email_service.send(user_id, message)
                return True
            except Exception:
                logger.critical("All notification channels failed")
                return False  # Сообщаем, что не удалось
```

## 7. Logging Errors

```python
# Всегда логируй достаточно контекста
try:
    result = await process_order(order_id, user_id, amount)
except Exception as e:
    logger.exception("order_processing_failed",  # включает traceback
                    order_id=order_id,
                    user_id=user_id,
                    amount=amount)
    # ⚠️ Не логируй пароли, токены, PII
    raise
```

## 8. Error Response Standard

```python
# Стандартный формат ошибки для API
{
    "error": {
        "code": "USER_NOT_FOUND",
        "message": "User 42 not found",
        "details": {
            "user_id": 42,
            "resource": "User"
        },
        "request_id": "abc123",
        "timestamp": "2024-01-15T10:30:00Z"
    }
}

# Pydantic schema
class ErrorResponse(BaseModel):
    code: str
    message: str
    details: dict[str, Any] = {}
    request_id: str = ""
    timestamp: str = ""
```
