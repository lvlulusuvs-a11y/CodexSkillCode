# Clean Code Principles

**Как писать код, который читается. Конкретные правила.**

---

## 1. Naming

```python
# ❌ Плохо
def proc(d):
    """Process data."""
    r = []
    for x in d:
        if x[0] > 0:
            r.append(x[1] * 2)
    return r

# ✅ Хорошо
def calculate_discounted_prices(products: list[tuple[float, float]]) -> list[float]:
    """Calculate double prices for products with positive margin."""
    return [price * 2 for margin, price in products if margin > 0]
```

## 2. Functions do ONE thing

```python
# ❌ Плохо: функция делает 3 вещи
def process_order(order_id: int) -> dict:
    order = fetch_order(order_id)     # 1. получить
    validate_payment(order)           # 2. проверить
    total = calculate_discount(order) # 3. рассчитать
    send_notification(order)          # 4. уведомить
    return total

# ✅ Хорошо: каждая функция делает одно
def process_order(order_id: int) -> ProcessResult:
    order = order_service.get(order_id)
    payment_service.validate(order.payment_id)
    total = pricing.calculate(order)
    notification.send(order.user.email)
    return ProcessResult(order_id=order_id, total=total)
```

## 3. No Magic Numbers

```python
# ❌ Плохо
if user.age > 18:
    # ...

# ✅ Хорошо
ADULT_AGE = 18
if user.age >= ADULT_AGE:
    # ...

# ❌
timeout = 30

# ✅
DEFAULT_TIMEOUT_SECONDS = 30
timeout = DEFAULT_TIMEOUT_SECONDS
```

## 4. Early Return

```python
# ❌ Плохо: вложенные if
def process(user):
    if user:
        if user.is_active:
            if user.has_permission:
                return do_work(user)
            else:
                return "no permission"
        else:
            return "not active"
    else:
        return "no user"

# ✅ Хорошо: guard clauses
def process(user):
    if not user:
        return "no user"
    if not user.is_active:
        return "not active"
    if not user.has_permission:
        return "no permission"
    return do_work(user)
```

## 5. No Side Effects

```python
# ❌ Плохо: функция меняет глобальное состояние
def add_item(item):
    cart.append(item)  # side effect!
    return len(cart)

# ✅ Хорошо: чистая функция
def add_item(cart: list, item: Any) -> list:
    return [*cart, item]
```

## 6. DRY vs WET

```python
# ❌ Плохо: дублирование
def get_active_users():
    return db.query("SELECT * FROM users WHERE active=1")

def get_active_admins():
    return db.query("SELECT * FROM admins WHERE active=1")

# ✅ Хорошо: параметризация
def get_active(table: str) -> list:
    return db.query(f"SELECT * FROM {table} WHERE active=1")
```

## 7. Comment Only WHY

```python
# ❌ Плохо: комментарий объясняет ЧТО
x = x + 1  # increment x by 1

# ✅ Хорошо: комментарий объясняет ПОЧЕМУ
# Retry with delay because external API has rate limit
await asyncio.sleep(RETRY_DELAY)
```

## 8. Single Responsibility (SRP)

```python
# ❌ Плохо: класс делает всё
class OrderHandler:
    def validate(self): ...
    def save(self): ...
    def send_email(self): ...
    def generate_pdf(self): ...

# ✅ Хорошо: разделённые классы
class OrderValidator: ...
class OrderRepository: ...
class EmailService: ...
class PDFGenerator: ...
```
