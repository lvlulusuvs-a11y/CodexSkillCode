# Migration Guide: Python 3.9 → 3.12

## Новый синтаксис

### 3.10 — match case
```python
match status_code:
    case 200:
        print("OK")
    case 404:
        print("Not Found")
    case _:
        print("Unknown")
```

### 3.11 — Self type
```python
from typing import Self

class MyClass:
    def clone(self) -> Self:
        return type(self)()
```

### 3.12 — PEP 695 (type parameter syntax)
```python
def first[T](items: list[T]) -> T:
    return items[0]

type Vector = list[float]
type Matrix[T] = list[list[T]]
```

## Старый → Новый

| Старый | Новый |
|--------|-------|
| `from typing import List` | `list[str]` |
| `from typing import Optional` | `str \| None` |
| `from typing import Union` | `str \| int` |
| `@dataclass` | то же, но с `slots=True` в 3.10+ |
| `enum.auto()` | то же |
| `asyncio.get_event_loop()` | `asyncio.run()` |

## Устаревшее
- `distutils` → удалён в 3.12, используй `setuptools`
- `imp` → удалён, используй `importlib`
- `pyimp` → удалён
- `asyncio.coroutine` → удалён, используй `async def`

## Новые фичи
- **3.10**: match-case, Parenthesized context managers
- **3.11**: Zero-cost exceptions, `Self`, `Self` type, `LiteralString`
- **3.12**: `typing` переписан в C, более понятные ошибки, f-string улучшения

## Обновление
```bash
# Проверить совместимость
pip install pip-upgrade
pip-upgrade

# Найти устаревшее
pip install pyupgrade
pyupgrade --py312-plus **/*.py
```

## Что проверить
- [ ] Все импорты из `typing` заменить на builtins (list → list, etc.)
- [ ] `Optional[X]` → `X | None`
- [ ] `Union[X, Y]` → `X | Y`
- [ ] `@dataclass` → `@dataclass(slots=True)` (если 3.10+)
- [ ] `pkg_resources` → `importlib.resources`
- [ ] `setup.py` → `pyproject.toml`
- [ ] `Loop.send()` → `gen.send()`
