# Flask Patterns

**Проверенные паттерны Flask для API и веб-приложений.**

---

## 1. Application Factory

```python
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config

db = SQLAlchemy()

def create_app(config_class=Config) -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    db.init_app(app)
    
    from routes.api import api_bp
    from routes.web import web_bp
    
    app.register_blueprint(api_bp, url_prefix="/api/v1")
    app.register_blueprint(web_bp)
    
    return app
```

## 2. Blueprint Structure

```python
# routes/api.py
from flask import Blueprint, jsonify, request

api_bp = Blueprint("api", __name__)

@api_bp.route("/users", methods=["GET"])
def list_users():
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@api_bp.route("/users", methods=["POST"])
def create_user():
    data = request.get_json()
    user = User(**data)
    db.session.add(user)
    db.session.commit()
    return jsonify(user.to_dict()), 201
```

## 3. Error Handling

```python
from flask import jsonify

class AppError(Exception):
    status_code = 400
    
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.message = message
        if status_code:
            self.status_code = status_code

@app.errorhandler(AppError)
def handle_app_error(error):
    return jsonify({"error": error.message}), error.status_code

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return jsonify({"error": "Internal server error"}), 500
```

## 4. SQLAlchemy Integration

```python
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timezone

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "users"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "created_at": self.created_at.isoformat(),
        }

# Query example
users = User.query.filter(User.is_active == True).order_by(User.created_at.desc()).limit(10).all()
```

## 5. Request Validation

```python
from marshmallow import Schema, fields, validate, ValidationError

class UserSchema(Schema):
    name = fields.String(required=True, validate=validate.Length(min=1, max=100))
    email = fields.Email(required=True)
    age = fields.Integer(validate=validate.Range(min=0, max=150))

user_schema = UserSchema()

@api_bp.route("/users", methods=["POST"])
def create_user():
    try:
        data = user_schema.load(request.get_json())
    except ValidationError as e:
        return jsonify({"errors": e.messages}), 422
    
    user = User(**data)
    db.session.add(user)
    db.session.commit()
    return jsonify(user.to_dict()), 201
```

## 6. Caching

```python
from flask_caching import Cache

cache = Cache(app)

@api_bp.route("/users/<int:user_id>")
@cache.cached(timeout=300, key_prefix="user_")
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())
```

## 7. Authentication

```python
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity

jwt = JWTManager(app)

@api_bp.route("/auth/login", methods=["POST"])
def login():
    data = request.get_json()
    user = User.query.filter_by(email=data["email"]).first()
    if user and check_password(user.password, data["password"]):
        token = create_access_token(identity=user.id)
        return jsonify(access_token=token)
    return jsonify({"error": "Invalid credentials"}), 401

@api_bp.route("/users/me")
@jwt_required()
def get_me():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())
```

## 8. CLI Commands

```python
import click
from flask.cli import with_appcontext

@app.cli.command("init-db")
@with_appcontext
def init_db_command():
    db.create_all()
    click.echo("Database initialized!")

@app.cli.command("create-admin")
@click.argument("email")
@click.argument("password")
@with_appcontext
def create_admin(email, password):
    admin = User(email=email, password=hash_password(password), is_admin=True)
    db.session.add(admin)
    db.session.commit()
    click.echo(f"Admin {email} created!")
```

## 9. Testing

```python
import pytest
from app import create_app, db

@pytest.fixture
def app():
    app = create_app()
    app.config["TESTING"] = True
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()

@pytest.fixture
def client(app):
    return app.test_client()

def test_get_users(client):
    response = client.get("/api/v1/users")
    assert response.status_code == 200
    assert response.json == []
```

## 10. Flask vs FastAPI Decision

```
┌────────────┬────────────────────────┬────────────────────────┐
│            │        Flask           │        FastAPI         │
├────────────┼────────────────────────┼────────────────────────┤
│ Async      │ Через gevent/threading │ Нативный async/await   │
│ Validation │ Marshmallow/Pydantic   │ Pydantic (встроенный)  │
│ Docs       │ Flasgger/Swagger       │ OpenAPI (авто)         │
│ DI         │ Нет встроенного        │ Depends (встроенный)   │
│ WebSocket  │ Flask-SocketIO         │ Нативная поддержка     │
│ GraphQL    │ graphene               │ strawberry              │
│ Когда      │ Простые сайты, админки │ API, микросервисы      │
└────────────┴────────────────────────┴────────────────────────┘
```
