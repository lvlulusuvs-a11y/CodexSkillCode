# Django-like Architecture in FastAPI

**Как организовать FastAPI проект как Django — проверенная архитектура.**

---

## Project Structure

```
project/
├── src/
│   ├── core/              # config, db, cache, logging
│   │   ├── __init__.py
│   │   ├── config.py      # pydantic-settings
│   │   ├── database.py    # engine, session, migrations
│   │   ├── cache.py       # redis client
│   │   ├── logging.py     # logger config
│   │   └── exceptions.py  # кастомные исключения
│   │
│   ├── apps/              # Django-style apps
│   │   ├── users/         # app: users
│   │   │   ├── __init__.py
│   │   │   ├── models.py      # SQLAlchemy models
│   │   │   ├── schemas.py     # Pydantic schemas
│   │   │   ├── router.py      # FastAPI router
│   │   │   ├── service.py     # бизнес-логика
│   │   │   ├── repository.py  # запросы к БД
│   │   │   ├── admin.py       # админка (опционально)
│   │   │   └── tests/         # тесты модуля
│   │   │       ├── __init__.py
│   │   │       ├── test_models.py
│   │   │       ├── test_service.py
│   │   │       └── test_api.py
│   │   │
│   │   ├── orders/         # app: orders
│   │   │   └── ...
│   │   │
│   │   └── payments/       # app: payments
│   │       └── ...
│   │
│   ├── lib/               # общие утилиты
│   │   ├── pagination.py
│   │   ├── permissions.py
│   │   ├── middleware.py
│   │   └── validators.py
│   │
│   ├── main.py            # FastAPI app
│   └── wsgi.py            # ASGI entry point
│
├── tests/                 # интеграционные тесты
│   ├── conftest.py
│   └── test_e2e.py
│
├── migrations/            # Alembic
│   ├── env.py
│   ├── script.py.mako
│   └── versions/
│       └── 0001_initial.py
│
├── .env
├── .env.example
├── pyproject.toml
├── Dockerfile
└── docker-compose.yml
```

## Core Components

### config.py

```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # App
    APP_NAME: str = "MyApp"
    DEBUG: bool = False
    
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://user:pass@localhost:5432/db"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_CACHE_TTL: int = 300
    
    # Auth
    SECRET_KEY: str
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_HOURS: int = 24
    
    # External services
    PAYMENT_API_KEY: str = ""
    NOTIFICATION_SERVICE_URL: str = ""
    
    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}

settings = Settings()
```

### database.py

```python
from sqlalchemy.ext.asyncio import (
    create_async_engine,
    AsyncSession,
    async_sessionmaker,
)
from core.config import settings

engine = create_async_engine(
    settings.DATABASE_URL,
    pool_size=settings.DATABASE_POOL_SIZE,
    max_overflow=settings.DATABASE_MAX_OVERFLOW,
    pool_pre_ping=True,
    echo=settings.DEBUG,
)

SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

async def get_db() -> AsyncIterator[AsyncSession]:
    async with SessionLocal() as session:
        yield session
```

### main.py

```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from core.config import settings
from core.exceptions import setup_exception_handlers
from apps.users.router import router as users_router
from apps.orders.router import router as orders_router

def create_app() -> FastAPI:
    """Application factory — как Django."""
    app = FastAPI(
        title=settings.APP_NAME,
        version="1.0.0",
        docs_url="/docs" if settings.DEBUG else None,
    )
    
    # Middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Routers
    app.include_router(users_router, prefix="/api/v1/users", tags=["users"])
    app.include_router(orders_router, prefix="/api/v1/orders", tags=["orders"])
    
    # Error handlers
    setup_exception_handlers(app)
    
    return app

app = create_app()
```

## App Structure (например Users)

### models.py

```python
from sqlalchemy import String, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from core.database import Base
from lib.mixins import TimestampMixin, SoftDeleteMixin

class User(Base, TimestampMixin, SoftDeleteMixin):
    __tablename__ = "users"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Relationships
    orders: Mapped[list["Order"]] = relationship(back_populates="user")
```

### schemas.py

```python
from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from typing import Optional

class UserCreate(BaseModel):
    email: EmailStr
    name: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=8)

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None

class UserResponse(BaseModel):
    id: int
    email: str
    name: str
    is_active: bool
    created_at: datetime
    
    model_config = {"from_attributes": True}

class UserList(BaseModel):
    data: list[UserResponse]
    total: int
    page: int
    page_size: int
```

### repository.py

```python
from typing import Optional
from core.database import AsyncSession
from .models import User

class UserRepository:
    def __init__(self, session: AsyncSession):
        self._session = session
    
    async def get(self, user_id: int) -> Optional[User]:
        return await self._session.get(User, user_id)
    
    async def get_by_email(self, email: str) -> Optional[User]:
        stmt = select(User).where(User.email == email)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
    
    async def list(self, skip: int = 0, limit: int = 100) -> list[User]:
        stmt = select(User).offset(skip).limit(limit).order_by(User.id)
        result = await self._session.execute(stmt)
        return list(result.scalars().all())
    
    async def create(self, data: dict) -> User:
        user = User(**data)
        self._session.add(user)
        await self._session.flush()
        return user
    
    async def update(self, user: User, data: dict) -> User:
        for key, value in data.items():
            setattr(user, key, value)
        await self._session.flush()
        return user
    
    async def delete(self, user: User) -> None:
        await self._session.delete(user)
        await self._session.flush()
```

### service.py

```python
from typing import Optional
from .repository import UserRepository
from .schemas import UserCreate, UserUpdate
from .models import User

class UserService:
    def __init__(self, repo: UserRepository):
        self._repo = repo
    
    async def get(self, user_id: int) -> User:
        if user := await self._repo.get(user_id):
            return user
        raise NotFoundError(f"User {user_id} not found")
    
    async def create(self, data: UserCreate) -> User:
        # Check existing
        if await self._repo.get_by_email(data.email):
            raise ConflictError(f"Email {data.email} already exists")
        
        # Hash password
        data_dict = data.model_dump()
        data_dict["hashed_password"] = hash_password(data_dict.pop("password"))
        
        return await self._repo.create(data_dict)
    
    async def update(self, user_id: int, data: UserUpdate) -> User:
        user = await self.get(user_id)
        
        if data.email and data.email != user.email:
            if await self._repo.get_by_email(data.email):
                raise ConflictError(f"Email {data.email} already exists")
        
        return await self._repo.update(user, data.model_dump(exclude_unset=True))
```

### router.py

```python
from fastapi import APIRouter, Depends, status
from core.database import get_db
from .service import UserService
from .repository import UserRepository
from .schemas import UserCreate, UserUpdate, UserResponse

router = APIRouter()

def get_user_service(db: AsyncSession = Depends(get_db)) -> UserService:
    return UserService(UserRepository(db))

@router.post("", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(data: UserCreate, service: UserService = Depends(get_user_service)):
    return await service.create(data)

@router.get("/{user_id}", response_model=UserResponse)
async def get_user(user_id: int, service: UserService = Depends(get_user_service)):
    return await service.get(user_id)

@router.patch("/{user_id}", response_model=UserResponse)
async def update_user(user_id: int, data: UserUpdate, service: UserService = Depends(get_user_service)):
    return await service.update(user_id, data)
```

## Testing

### conftest.py

```python
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from core.database import Base
from .main import create_app

@pytest_asyncio.fixture
async def db_session():
    engine = create_async_engine("sqlite+aiosqlite://")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    session = AsyncSession(engine, expire_on_commit=False)
    yield session
    await session.close()
    await engine.dispose()

@pytest_asyncio.fixture
async def client(db_session):
    app = create_app()
    app.dependency_overrides[get_db] = lambda: db_session
    async with AsyncClient(app=app, base_url="http://test") as ac:
        yield ac
```

## Key Principles

1. **Django-like structure** — apps, models, service, repository
2. **Dependency Injection** — через FastAPI Depends
3. **Separation of Concerns** — router → service → repository
4. **Testable** — каждый слой можно тестировать изолированно
5. **No global state** — всё через DI
