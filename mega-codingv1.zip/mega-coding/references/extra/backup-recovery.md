# Backup & Recovery Patterns

**Бэкапы, восстановление, disaster recovery для Python-приложений.**

---

## 1. Database Backup (PostgreSQL)

```python
import subprocess
from pathlib import Path
from datetime import datetime

async def backup_postgres(db_url: str, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = output_dir / f"backup_{timestamp}.sql"
    
    proc = await asyncio.create_subprocess_exec(
        "pg_dump", db_url,
        "--format=custom",
        "--compress=9",
        str(filename),
    )
    await proc.wait()
    return filename

async def restore_postgres(db_url: str, backup_file: Path) -> None:
    proc = await asyncio.create_subprocess_exec(
        "pg_restore", "--clean", "--no-owner",
        "-d", db_url,
        str(backup_file),
    )
    await proc.wait()
```

## 2. Automated Cleanup

```python
import shutil
from pathlib import Path

def cleanup_old_backups(backup_dir: Path, keep_days: int = 30) -> list[Path]:
    removed = []
    cutoff = datetime.now().timestamp() - (keep_days * 86400)
    
    for f in backup_dir.glob("backup_*.sql"):
        if f.stat().st_mtime < cutoff:
            f.unlink()
            removed.append(f)
    
    return removed
```
