# Python Developer Reference

**Полный справочник Python-разработчика. От синтаксиса до продвинутых приёмов.**

---

## 1. Core Syntax Reference

### 1.1 Type Annotations

```python
from __future__ import annotations

# Basic types
name: str = "Alice"
age: int = 30
height: float = 1.75
active: bool = True

# Collections
from collections.abc import Sequence, Mapping, Iterable, Callable
names: Sequence[str] = ["Alice", "Bob"]
lookup: Mapping[str, int] = {"a": 1, "b": 2}

# Optional / Union
from typing import Optional, Union
maybe_name: Optional[str] = None  # str | None
result: Union[int, str] = 42     # int | str (Python 3.10+: int | str)

# Aliases
type UserID = int
type JSON = dict[str, Any]

# Callable
Handler = Callable[[int, str], bool]
AsyncHandler = Callable[[int], Awaitable[bool]]
```

### 1.2 Comprehensions

```python
# List
squares = [x * x for x in range(10)]
evens = [x for x in range(10) if x % 2 == 0]

# Dict
square_dict = {x: x * x for x in range(10)}
filtered = {k: v for k, v in items.items() if v > 0}

# Set
unique = {x % 3 for x in range(100)}

# Generator (lazy)
total = sum(x * x for x in range(1000000))

# Nested
matrix = [[i * j for j in range(5)] for i in range(5)]
flat = [x for row in matrix for x in row]
```

### 1.3 Context Managers

```python
# Built-in
with open("file.txt") as f:
    data = f.read()

with lock:
    critical_section()

# Multiple
with open("a.txt") as a, open("b.txt") as b:
    ...

# Async
async with aiohttp.ClientSession() as session:
    async with session.get(url) as resp:
        data = await resp.json()
```

### 1.4 Pattern Matching (Python 3.10+)

```python
# match/case
def process(value: Any) -> str:
    match value:
        case 0:
            return "zero"
        case 1 | 2 | 3:
            return "small"
        case int(n) if n > 100:
            return "large"
        case str(s):
            return f"string: {s}"
        case [a, b, *rest]:
            return f"list: {a}, {b}"
        case {"name": name, "age": age}:
            return f"dict: {name}, {age}"
        case _:
            return "unknown"
```

### 1.5 Walrus Operator (:=)

```python
# Assignment expression
if (n := len(items)) > 0:
    print(f"Found {n} items")

# In comprehension
results = [y for x in data if (y := process(x)) is not None]

# In while
while (line := file.readline()) != "":
    process(line)
```

## 2. Standard Library Reference

### 2.1 collections

```python
from collections import (
    defaultdict, Counter, deque, 
    OrderedDict, ChainMap, namedtuple,
)

# defaultdict — auto-initialize
groups = defaultdict(list)
groups["a"].append(1)  # doesn't need to check existence

# Counter — count elements
freq = Counter("hello world")
most_common = freq.most_common(3)

# deque — double-ended queue
queue = deque(maxlen=100)
queue.append(1)
queue.appendleft(2)
first = queue.popleft()

# ChainMap — merge without copy
defaults = {"host": "localhost", "port": 8080}
overrides = {"port": 9000}
config = ChainMap(overrides, defaults)

# namedtuple — lightweight immutable
Point = namedtuple("Point", ["x", "y"])
p = Point(10, 20)
```

### 2.2 functools

```python
from functools import (
    lru_cache, cached_property, 
    partial, wraps, singledispatch,
)

# Caching
@lru_cache(maxsize=128)
def expensive(n: int) -> int:
    return n * n

@cached_property
def computed(self) -> float:
    return self.a + self.b

# Partial application
base_two = partial(int, base=2)
result = base_two("1000")  # 8

# Single dispatch (overload by type)
@singledispatch
def serialize(obj): raise NotImplementedError

@serialize.register
def _(obj: User) -> str: return f"User({obj.id})"

@serialize.register
def _(obj: Order) -> str: return f"Order({obj.id})"
```

### 2.3 itertools

```python
from itertools import (
    chain, cycle, count, repeat,
    groupby, islice, product, 
    permutations, combinations, zip_longest,
)

# Infinite iterators
for i in count(0):  # 0, 1, 2, ...
    if i > 10: break

for item in cycle(["a", "b"]):  # a, b, a, b, ...
    ...

# Combinations
list(combinations([1, 2, 3], 2))  # (1,2), (1,3), (2,3)
list(permutations([1, 2, 3], 2))  # (1,2), (1,3), (2,1), (2,3), (3,1), (3,2)

# Group
for key, group in groupby(sorted(data), key=lambda x: x["type"]):
    print(key, list(group))

# Chunking
def chunks(iterable, size):
    iterator = iter(iterable)
    return iter(lambda: list(islice(iterator, size)), [])
```

### 2.4 pathlib

```python
from pathlib import Path

# Path operations
path = Path("src") / "main.py"
path = Path.home() / "project" / "data.json"
path = Path.cwd() / "config.yaml"

# Common operations
path.exists()
path.is_file()
path.is_dir()
path.name         # "main.py"
path.stem         # "main"
path.suffix       # ".py"
path.parent       # Path("src")
path.resolve()    # absolute path

# Reading/writing
path.read_text()
path.write_text("content")
path.read_bytes()
path.write_bytes(b"content")

# Directory operations
for py_file in Path.cwd().rglob("*.py"):
    ...

# Create directories
path.mkdir(parents=True, exist_ok=True)
```

### 2.5 typing

```python
from typing import (
    TypeVar, Generic, Protocol,
    Literal, Final, TypedDict,
    ParamSpec, Self, overload,
)

# TypeVar
T = TypeVar("T")
K = TypeVar("K", int, str)

# Generic
class Stack(Generic[T]):
    def push(self, item: T) -> None: ...
    def pop(self) -> T: ...

# Protocol (structural typing)
class Drawable(Protocol):
    def draw(self) -> None: ...

# Literal
def set_mode(mode: Literal["read", "write"]) -> None: ...

# TypedDict
class Movie(TypedDict):
    title: str
    year: int
    rating: NotRequired[float]

# Self (Python 3.11+)
class Builder:
    def set_name(self, name: str) -> Self: ...
```

### 2.6 dataclasses

```python
from dataclasses import dataclass, field, asdict, astuple

@dataclass(frozen=True, order=True, slots=True)
class User:
    id: int
    name: str = field(compare=False)
    email: str = field(repr=False)
    tags: list[str] = field(default_factory=list)
    
    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("Name required")

# Operations
user = User(1, "Alice", "alice@test.com")
data = asdict(user)  # dict
tup = astuple(user)  # tuple
```

### 2.7 asyncio

```python
import asyncio

# Create task
task = asyncio.create_task(coro())

# Gather
results = await asyncio.gather(coro1(), coro2(), return_exceptions=True)

# TaskGroup (3.11+)
async with asyncio.TaskGroup() as tg:
    t1 = tg.create_task(coro1())
    t2 = tg.create_task(coro2())

# Timeout
async with asyncio.timeout(5.0):
    result = await slow_operation()

# Queue
queue = asyncio.Queue(maxsize=100)
await queue.put(item)
item = await queue.get()

# Synchronization
lock = asyncio.Lock()
event = asyncio.Event()
sem = asyncio.Semaphore(10)
```

## 3. String Methods

```python
# Basic
s = "hello world"
s.upper()        # "HELLO WORLD"
s.lower()        # "hello world"
s.title()        # "Hello World"
s.capitalize()   # "Hello world"
s.strip()        # remove whitespace
s.lstrip()       # left strip
s.rstrip()       # right strip

# Search
s.startswith("hello")
s.endswith("world")
s.find("world")    # index or -1
s.index("world")   # index or ValueError
s.count("o")       # 2
"hello" in s       # True

# Split/Join
s.split()          # ["hello", "world"]
s.split(",")       # by separator
", ".join(["a", "b"])  # "a, b"
s.partition(" ")   # ("hello", " ", "world")

# Replace
s.replace("world", "Python")
s.translate(str.maketrans({"o": "0", "l": "1"}))

# Check
s.isalpha()   # all letters
s.isdigit()   # all digits
s.isalnum()   # letters + digits
s.isspace()   # whitespace

# Format
f"Hello {name}"
"Hello {}".format(name)
"%(name)s" % {"name": "Alice"}
```

## 4. File I/O

```python
# Text
with open("file.txt", "r", encoding="utf-8") as f:
    content = f.read()           # whole file
    line = f.readline()          # one line
    lines = f.readlines()        # list of lines
    for line in f:               # iterator
        process(line)

# Binary
with open("file.bin", "rb") as f:
    data = f.read(1024)  # read 1KB

# Write
with open("file.txt", "w") as f:
    f.write("content")
    f.writelines(["line1\n", "line2\n"])

# JSON
import json
with open("data.json") as f:
    data = json.load(f)
with open("data.json", "w") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

# CSV
import csv
with open("data.csv", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(row["name"])
```

## 5. Exception Handling

```python
# Basic
try:
    result = risky_operation()
except ValueError as e:
    logger.error("Value error: %s", e)
except (IOError, OSError) as e:
    logger.error("IO error: %s", e)
except Exception:
    logger.exception("Unexpected error")
    raise
else:
    print("No error occurred")
finally:
    cleanup()

# Custom exceptions
class AppError(Exception):
    def __init__(self, message: str, code: str = "ERROR"):
        self.message = message
        self.code = code
        super().__init__(self.message)

# Raising with cause
try:
    external_call()
except ConnectionError as e:
    raise ServiceError("External service unavailable") from e

# Suppress
from contextlib import suppress
with suppress(FileNotFoundError):
    os.remove("temp.txt")
```

## 6. Regular Expressions

```python
import re

# Matching
pattern = r"\d{3}-\d{2}-\d{4}"
match = re.search(pattern, text)
match = re.match(pattern, text)  # from start
matches = re.findall(pattern, text)  # all matches
matches = re.finditer(pattern, text)  # iterator of matches

# Groups
pattern = r"(\d{3})-(\d{2})-(\d{4})"
match = re.search(pattern, text)
if match:
    area = match.group(1)
    prefix = match.group(2)
    number = match.group(3)

# Named groups
pattern = r"(?P<area>\d{3})-(?P<num>\d{7})"
match = re.search(pattern, text)
area = match.group("area")

# Replace
result = re.sub(r"\s+", " ", text)  # normalize whitespace
result = re.sub(r"\d{3}-\d{4}", "XXX-XXXX", text)  # mask

# Compile (for reuse)
phone_pattern = re.compile(r"\d{3}-\d{2}-\d{4}")
matches = phone_pattern.findall(large_text)

# Common patterns
email = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
url = r"https?://[^\s/$.?#].[^\s]*"
ipv4 = r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"
date = r"\d{4}-\d{2}-\d{2}"
phone = r"\+?1?\d{10,11}"
```

## 7. Common Algorithms

### Binary Search
```python
def binary_search(arr: list[int], target: int) -> int:
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1
```

### Quick Sort
```python
def quicksort(arr: list[int]) -> list[int]:
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quicksort(left) + middle + quicksort(right)
```

### Merge Sort
```python
def merge_sort(arr: list[int]) -> list[int]:
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left: list[int], right: list[int]) -> list[int]:
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result
```

### Dijkstra (Shortest Path)
```python
import heapq

def dijkstra(graph: dict[int, dict[int, int]], start: int) -> dict[int, float]:
    distances = {node: float("inf") for node in graph}
    distances[start] = 0
    pq = [(0, start)]
    
    while pq:
        current_dist, current = heapq.heappop(pq)
        if current_dist > distances[current]:
            continue
        for neighbor, weight in graph[current].items():
            distance = current_dist + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(pq, (distance, neighbor))
    
    return distances
```

### LRU Cache
```python
from collections import OrderedDict

class LRUCache:
    def __init__(self, capacity: int):
        self._cache = OrderedDict()
        self._capacity = capacity
    
    def get(self, key: str) -> Any:
        if key not in self._cache:
            return -1
        self._cache.move_to_end(key)
        return self._cache[key]
    
    def put(self, key: str, value: Any) -> None:
        if key in self._cache:
            self._cache.move_to_end(key)
        self._cache[key] = value
        if len(self._cache) > self._capacity:
            self._cache.popitem(last=False)
```

## 8. OS and System

```python
import os, sys, platform

# Environment
os.environ.get("DATABASE_URL", "default")
os.environ["PATH"] = "/usr/local/bin:" + os.environ["PATH"]

# Filesystem
os.listdir(".")
os.makedirs("path/to/dir", exist_ok=True)
os.remove("file.txt")
os.rename("old.txt", "new.txt")

# Process
os.getpid()
os.getcwd()
os.chdir("/tmp")
sys.argv  # command line args
sys.exit(0)  # exit code

# Platform
platform.system()     # Linux, Darwin, Windows
platform.release()    # kernel version
sys.platform          # linux, darwin, win32
```

## 9. JSON and Serialization

```python
import json, pickle, msgpack

# JSON
data = json.dumps(obj, indent=2, ensure_ascii=False, default=str)
obj = json.loads(data)

# Custom encoder
class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

data = json.dumps(obj, cls=DateTimeEncoder)

# Pickle (Python only, faster)
data = pickle.dumps(obj, protocol=5)
obj = pickle.loads(data)

# msgpack (compact binary)
import msgpack
data = msgpack.packb(obj)
obj = msgpack.unpackb(data)
```

## 10. Networking

```python
import socket, urllib.request

# TCP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect(("example.com", 80))
sock.send(b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
response = sock.recv(4096)
sock.close()

# urllib (simple HTTP)
with urllib.request.urlopen("https://api.example.com") as resp:
    data = resp.read()
    headers = resp.headers

# IP address
import ipaddress
net = ipaddress.IPv4Network("192.168.1.0/24")
for ip in net.hosts():
    ...
```

## 11. Date and Time

```python
from datetime import datetime, date, time, timedelta, timezone

# Current time
now = datetime.now(timezone.utc)
today = date.today()

# Formatting
now.isoformat()  # 2024-01-15T10:30:00+00:00
now.strftime("%Y-%m-%d %H:%M:%S")

# Parsing
dt = datetime.fromisoformat("2024-01-15T10:30:00+00:00")
dt = datetime.strptime("2024-01-15", "%Y-%m-%d")

# Arithmetic
tomorrow = today + timedelta(days=1)
yesterday = today - timedelta(days=1)
next_week = today + timedelta(weeks=1)

# Timezone
from zoneinfo import ZoneInfo  # Python 3.9+
moscow = now.astimezone(ZoneInfo("Europe/Moscow"))
ny = now.astimezone(ZoneInfo("America/New_York"))

# Timestamps
ts = now.timestamp()
dt = datetime.fromtimestamp(ts, tz=timezone.utc)
```

## 12. Hashing and Encryption

```python
import hashlib, hmac, secrets

# Hashing
hashlib.md5(b"data").hexdigest()
hashlib.sha256(b"data").hexdigest()
hashlib.sha512(b"data").hexdigest()

# HMAC (signed hash)
h = hmac.new(b"key", b"message", hashlib.sha256)
signature = h.hexdigest()

# Secure random
token = secrets.token_hex(32)  # 64 character hex string
secret = secrets.token_urlsafe(32)  # URL-safe string
password = secrets.token_bytes(32)  # raw bytes

# Password hashing
import bcrypt
hashed = bcrypt.hashpw(b"password", bcrypt.gensalt())
bcrypt.checkpw(b"password", hashed)

# UUID
import uuid
uuid.uuid4()  # random UUID
uuid.uuid5(uuid.NAMESPACE_DNS, "example.com")  # deterministic
```
