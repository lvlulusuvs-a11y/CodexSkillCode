# Security Best Practices

**Безопасность Python-приложений. От SQL injection до dependency scanning.**

---

## 1. SQL Injection Prevention

```python
# ❌ Никогда: f-строка с пользовательским вводом
query = f"SELECT * FROM users WHERE id = {user_input}"  # SQL injection!

# ✅ Всегда: параметризированные запросы
await conn.execute("SELECT * FROM users WHERE id = $1", user_input)

# SQLAlchemy — безопасен по умолчанию
stmt = select(User).where(User.id == user_input)  # безопасно
```

## 2. XSS Prevention

```python
import html

# ❌ Опасно: неэкранированный вывод
template = f"<div>{user_input}</div>"

# ✅ Безопасно: экранирование HTML
safe = html.escape(user_input)
template = f"<div>{safe}</div>"
```

## 3. Command Injection

```python
import subprocess

# ❌ Опасно
result = subprocess.run(f"ping {user_input}", shell=True)

# ✅ Безопасно
result = subprocess.run(["ping", user_input], capture_output=True, text=True)

# ✅ Ещё безопаснее — использовать shlex.quote
import shlex
result = subprocess.run(f"ping {shlex.quote(user_input)}", shell=True)
```

## 4. Secret Management

```python
# ❌ Хардкод
API_KEY = "sk-1234567890abcdef"

# ✅ Переменные окружения / .env
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    api_key: str  # берётся из окружения или .env
    db_password: str
    
    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}

settings = Settings()

# ✅ Vault / AWS Secrets Manager
import boto3
client = boto3.client("secretsmanager")
secret = client.get_secret_value(SecretId="prod/api-key")
```

## 5. Authentication

```python
# JWT tokens
import jwt
from datetime import datetime, timedelta, timezone

def create_token(user_id: int) -> str:
    payload = {
        "user_id": user_id,
        "exp": datetime.now(timezone.utc) + timedelta(hours=24),
        "iat": datetime.now(timezone.utc),
        "type": "access",
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def verify_token(token: str) -> dict:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
```

## 6. Rate Limiting

```python
from fastapi import Request, HTTPException
from datetime import datetime, timedelta

rate_limits: dict[str, list[datetime]] = {}

def check_rate_limit(request: Request, max_requests: int = 100, window: int = 60) -> None:
    client_ip = request.client.host
    now = datetime.now()
    
    if client_ip not in rate_limits:
        rate_limits[client_ip] = []
    
    # Очистить старые
    rate_limits[client_ip] = [t for t in rate_limits[client_ip] if t > now - timedelta(seconds=window)]
    
    if len(rate_limits[client_ip]) >= max_requests:
        raise HTTPException(status_code=429, detail="Too many requests")
    
    rate_limits[client_ip].append(now)
```

## 7. Input Validation

```python
from pydantic import BaseModel, Field, EmailStr, field_validator

class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(ge=0, le=150)
    bio: str = Field(default="", max_length=1000)
    
    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if any(c in v for c in "<>\"'%&;/"):
            raise ValueError("Invalid characters")
        return v.strip()
```

## 8. CORS Configuration

```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://myapp.com"],  # не "*" в проде!
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
    allow_credentials=True,
)
```

## 9. Dependency Scanning

```bash
# pip-audit — проверка уязвимостей в зависимостях
pip install pip-audit
pip-audit

# Safety — альтернатива
pip install safety
safety check

# Bandit — статический анализ безопасности
pip install bandit
bandit -r src/
```

## 10. Secure Headers

```python
from fastapi.responses import Response

def secure_headers(response: Response) -> None:
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'self'"
```
