# Python Packaging Guide

## pyproject.toml
```toml
[build-system]
requires = ["setuptools>=75", "wheel"]
build-backend = "setuptools.backends._legacy:_Backend"

[project]
name = "mypackage"
version = "0.1.0"
description = "My awesome package"
readme = "README.md"
requires-python = ">=3.10"
license = { text = "MIT" }
authors = [
    { name = "Author", email = "author@example.com" },
]
keywords = ["python", "tool"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]

dependencies = [
    "httpx>=0.27",
    "pydantic>=2.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8",
    "pytest-cov>=5",
    "ruff>=0.4",
    "mypy>=1.9",
]
prod = [
    "uvicorn[standard]",
    "gunicorn",
]

[project.urls]
Homepage = "https://github.com/user/mypackage"
Documentation = "https://mypackage.readthedocs.io"
Source = "https://github.com/user/mypackage"

[project.scripts]
mycli = "mypackage.cli:main"

[tool.setuptools.packages.find]
where = ["src"]
include = ["mypackage*"]
```

## Publishing to PyPI
```bash
# Установка
pip install build twine

# Сборка
python -m build

# Загрузка в TestPyPI
twine upload --repository-url https://test.pypi.org/legacy/ dist/*

# Загрузка в PyPI
twine upload dist/*
```

## Versioning (SemVer)
```
MAJOR.MINOR.PATCH
  ↑     ↑     ↑
  │     │     └── bug fix (backward compatible)
  │     └──────── new feature (backward compatible)
  └────────────── breaking changes
```

## .gitignore for packages
```
__pycache__/
*.py[cod]
*.egg-info/
dist/
build/
.venv/
venv/
*.so
```
