# Debugging & Troubleshooting

**Как находить и исправлять проблемы в Python-приложениях.**

---

## 1. Debugging Tools

```bash
# pdb (встроенный)
python -m pdb my_script.py
# В коде: import pdb; pdb.set_trace()

# ipdb (лучше pdb)
pip install ipdb
# В коде: import ipdb; ipdb.set_trace()

# breakpoint() (Python 3.7+, использует PYTHONBREAKPOINT)
breakpoint()  # в коде

# Удалённый дебаг (для серверов)
pip install debugpy
# python -m debugpy --listen 0.0.0.0:5678 --wait-for-client my_script.py
```

## 2. Common Errors & Solutions

### ModuleNotFoundError
```bash
# Проверить установку
pip list | grep mypackage

# Проверить PYTHONPATH
python -c "import sys; print('\n'.join(sys.path))"

# Виртуальное окружение
which python
python -m site

# Циклические импорты
# Разделить на module.py → types.py, logic.py
```

### ImportError
```python
# Relative imports вне пакета
# ❌ from . import module  # ImportError: attempted relative import with no known parent package
# ✅ python -m package.module (а не python module.py)
```

### SQLAlchemy Errors
```python
# DetachedInstanceError (объект вне сессии)
user = await session.get(User, 1)
await session.close()
print(user.name)  # ❌ DetachedInstanceError

# Решение: expire_on_commit=False
session = AsyncSession(engine, expire_on_commit=False)

# Или загрузить снова
user = await session.get(User, 1)
```

### Asyncio Errors
```python
# RuntimeError: Task <Task pending> got Future <Future pending>
# Причина: корутина не запущена
async def my_func(): ...
coro = my_func()  # ❌ не запущена
# await coro  # ✅

# RuntimeError: asyncio.run() cannot be called from a running event loop
# Решение: использовать asyncio.create_task() или await
async def main():
    await some_func()  # ✅
    # asyncio.run(other())  # ❌
```

### Memory Errors
```python
# MemoryError: не хватает памяти
# Решение 1: генераторы вместо списков
# ❌ all_data = [process(x) for x in huge_data]
# ✅ for x in huge_data: process(x)  # лениво

# Решение 2: __slots__
class Point:
    __slots__ = ("x", "y")
    ...

# Решение 3: gc.collect()
import gc
gc.collect()  # принудительная сборка мусора
```

### Deadlocks
```python
# asyncio deadlock: await внутри lock, который уже захвачен
async def example():
    async with lock:
        await another_func()  # ❌ если another_func тоже захватит lock — deadlock

# Решение: определить порядок блокировок
# Или использовать asyncio.Lock с таймаутом
try:
    await asyncio.wait_for(lock.acquire(), timeout=5.0)
except TimeoutError:
    logger.error("Deadlock detected!")
```

## 3. Performance Debugging

```bash
# CPU profile
python -m cProfile -s cumulative my_script.py | head -30

# Flamegraph
pip install py-spy
py-spy record -o flame.svg -- python my_script.py

# Memory
pip install memory_profiler
python -m memory_profiler my_script.py

# Line profiler
pip install line_profiler
kernprof -l -v my_script.py
```

## 4. Network Debugging

```bash
# Проверить DNS
nslookup api.example.com
dig api.example.com

# Проверить порт
nc -zv api.example.com 443
curl -v https://api.example.com/health

# TCP dump
tcpdump -i any port 80 -nn

# Трассировка
traceroute api.example.com

# HTTP запрос
curl -X POST https://api.example.com/data \
  -H "Content-Type: application/json" \
  -d '{"key":"value"}' \
  -v
```

## 5. Database Debugging

```sql
-- PostgreSQL
-- Текущие запросы
SELECT pid, now() - pg_stat_activity.query_start AS duration, query, state
FROM pg_stat_activity
WHERE state != 'idle'
ORDER BY duration DESC;

-- Медленные запросы (если pg_stat_statements включён)
SELECT query, calls, total_time, mean_time
FROM pg_stat_statements
ORDER BY total_time DESC
LIMIT 10;

-- Блокировки
SELECT blocked_locks.pid AS blocked_pid,
       blocking_locks.pid AS blocking_pid
FROM pg_locks blocked_locks
JOIN pg_locks blocking_locks ON blocked_locks.locktype = blocking_locks.locktype;

-- Размер таблиц
SELECT tablename, pg_size_pretty(pg_total_relation_size(relid)) AS size
FROM pg_catalog.pg_statio_user_tables
ORDER BY pg_total_relation_size(relid) DESC;
```

## 6. Docker Debugging

```bash
# Логи
docker logs --tail=100 -f container_name

# Войти в контейнер
docker exec -it container_name /bin/bash

# Ресурсы
docker stats

# Inspect
docker inspect container_name

# Copy файлы
docker cp container_name:/app/logs.txt ./logs.txt

# Сеть
docker network ls
docker network inspect bridge
```

## 7. Git Debugging

```bash
# Кто изменил строку
git blame -L 42,50 src/main.py

# Когда появился баг
git bisect start
git bisect bad HEAD
git bisect good v1.0
# Git переключает коммиты, проверяй баг → git bisect good/bad
git bisect reset

# Найти удалённый код
git log -p -S "deleted_function" -- src/

# Посмотреть что изменилось в коммите
git show abc1234
```

## 8. Monitoring Debugging

```python
# Health check endpoint
@app.get("/health")
async def health():
    db_ok = await check_db()
    redis_ok = await check_redis()
    return {
        "status": "healthy" if db_ok and redis_ok else "degraded",
        "checks": {
            "database": "ok" if db_ok else "failed",
            "redis": "ok" if redis_ok else "failed",
        },
    }

# Пошаговое логирование
async def process_order(order_id: int) -> None:
    logger.debug("Starting order processing", order_id=order_id)
    
    order = await get_order(order_id)
    logger.debug("Order fetched", order_id=order_id, status=order.status)
    
    await validate_payment(order)
    logger.debug("Payment validated", order_id=order_id)
```

## 9. Python Debugging Snippets

```python
# Смотреть типы и атрибуты
print(type(obj))
print(dir(obj))
print(vars(obj))

# Смотреть стек вызовов
import traceback
traceback.print_stack()

# Смотреть, сколько времени заняло
from time import perf_counter
start = perf_counter()
result = func()
print(f"Took {perf_counter() - start:.3f}s")

# Смотреть, сколько объектов
import sys
print(sys.getsizeof(large_list))
print(len(large_list))

# Смотреть ID объекта
print(id(obj))
print(obj is other)  # сравнение по ID
```

## 10. Когда всё остальное не помогает

```python
# 1. Проверь окружение
python --version
pip list | grep mypackage
echo $PYTHONPATH

# 2. Проверь права
ls -la /var/log/
whoami

# 3. Перезапусти
# Иногда помогает: systemctl restart myapp

# 4. Проверь логи
tail -f /var/log/app.log

# 5. Упрости воспроизведение
# Минимальный пример, который воспроизводит баг

# 6. Обнови зависимости
pip install --upgrade mypackage

# 7. Создай чистое окружение
python -m venv fresh_venv
source fresh_venv/bin/activate
pip install -r requirements.txt
```
