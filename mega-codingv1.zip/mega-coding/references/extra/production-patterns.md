# Production Patterns

**Боевые паттерны Python для продакшена. Не теория — код, который работает под нагрузкой.**

---

## 1. Connection Pool

```python
"""Пул соединений с автоматическим восстановлением."""
from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, TypeVar

T = TypeVar("T")

@dataclass
class Pool(AsyncIterator[T]):
    factory: Any  # Callable[[], Awaitable[T]]
    min_size: int = 2
    max_size: int = 10
    max_idle: float = 60.0  # секунд бездействия до закрытия
    
    _sem: asyncio.Semaphore = field(init=False)
    _idle: list[T] = field(default_factory=list, init=False)
    _used: set[T] = field(default_factory=set, init=False)
    _closed: bool = False
    
    def __post_init__(self) -> None:
        self._sem = asyncio.Semaphore(self.max_size)
    
    async def __aenter__(self) -> Pool[T]:
        # Создать минимальное количество соединений
        for _ in range(self.min_size):
            conn = await self.factory()
            self._idle.append(conn)
        return self
    
    async def __aexit__(self, *args: Any) -> None:
        self._closed = True
        for conn in self._idle:
            await self._close_conn(conn)
        for conn in self._used:
            await self._close_conn(conn)
        self._idle.clear()
        self._used.clear()
    
    async def _close_conn(self, conn: T) -> None:
        if hasattr(conn, "close"):
            await conn.close()
    
    @asynccontextmanager
    async def acquire(self) -> AsyncIterator[T]:
        async with self._sem:
            conn = await self._get()
            try:
                yield conn
            except Exception:
                # Закрыть сбойное соединение, создать новое
                await self._close_conn(conn)
                self._used.discard(conn)
                raise
            finally:
                if conn in self._used:
                    self._used.remove(conn)
                    self._idle.append(conn)
    
    async def _get(self) -> T:
        if self._idle:
            return self._idle.pop()
        conn = await self.factory()
        self._used.add(conn)
        return conn
    
    async def __anext__(self) -> T:
        raise StopAsyncIteration

# Использование:
# pool = Pool(factory=lambda: asyncpg.connect(DSN))
# async with pool:
#     async with pool.acquire() as conn:
#         await conn.fetch("SELECT 1")
```

## 2. Retry with Circuit Breaker

```python
"""Retry + Circuit Breaker для внешних вызовов."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import Enum, auto
from functools import wraps
from typing import Any, Callable

class CircuitState(Enum):
    CLOSED = auto()     # Работает нормально
    OPEN = auto()       # Сломан, пропускаем
    HALF_OPEN = auto()  # Проверяем, починился ли

@dataclass
class CircuitBreaker:
    failure_threshold: int = 5
    recovery_timeout: float = 30.0
    
    _failures: int = 0
    _state: CircuitState = CircuitState.CLOSED
    _last_failure_time: float = 0.0
    
    async def call(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        if self._state is CircuitState.OPEN:
            if asyncio.get_event_loop().time() - self._last_failure_time > self.recovery_timeout:
                self._state = CircuitState.HALF_OPEN
            else:
                raise CircuitBreakerOpenError("Circuit breaker is open")
        
        try:
            result = await func(*args, **kwargs)
        except Exception as e:
            self._failures += 1
            self._last_failure_time = asyncio.get_event_loop().time()
            if self._failures >= self.failure_threshold:
                self._state = CircuitState.OPEN
            raise
        
        # Успех в HALF_OPEN → CLOSED
        if self._state is CircuitState.HALF_OPEN:
            self._state = CircuitState.CLOSED
            self._failures = 0
        
        return result

class CircuitBreakerOpenError(Exception):
    """Запрос не выполнен: circuit breaker open."""

def with_retry_and_circuit_breaker(
    max_retries: int = 3,
    base_delay: float = 1.0,
    circuit_breaker: CircuitBreaker | None = None,
) -> Callable:
    """Декоратор: retry + circuit breaker."""
    cb = circuit_breaker or CircuitBreaker()
    
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_error = None
            for attempt in range(max_retries):
                try:
                    return await cb.call(func, *args, **kwargs)
                except (ConnectionError, TimeoutError, CircuitBreakerOpenError) as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        await asyncio.sleep(base_delay * (2 ** attempt))  # exponential backoff
                    continue
            raise last_error  # type: ignore
        return wrapper
    return decorator
```

## 3. Caching with TTL and Invalidation

```python
"""Кэш с TTL, инвалидацией по тегам и защитой от cache stampede."""
from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar

K = TypeVar("K")
V = TypeVar("V")

@dataclass
class CacheEntry(Generic[V]):
    value: V
    expires_at: float
    tags: set[str] = field(default_factory=set)

@dataclass
class SmartCache(Generic[K, V]):
    """Кэш с TTL, тегами и защитой от stampede."""
    default_ttl: float = 300.0  # 5 минут
    
    _data: dict[K, CacheEntry[V]] = field(default_factory=dict, init=False)
    _locks: dict[K, asyncio.Lock] = field(default_factory=dict, init=False)
    _tag_index: dict[str, set[K]] = field(default_factory=dict, init=False)
    
    async def get_or_compute(
        self,
        key: K,
        factory: Callable[[], Any],
        ttl: float | None = None,
        tags: list[str] | None = None,
    ) -> V:
        """Получить из кэша или вычислить. Защита от stampede."""
        # Быстрый путь: есть в кэше
        if entry := self._data.get(key):
            if entry.expires_at > time.monotonic():
                return entry.value
        
        # Медленный путь: блокировка, чтобы только один вычислял
        if key not in self._locks:
            self._locks[key] = asyncio.Lock()
        
        async with self._locks[key]:
            # Double-check: мог уже появиться
            if entry := self._data.get(key):
                if entry.expires_at > time.monotonic():
                    return entry.value
            
            # Вычислить
            value = await factory() if asyncio.iscoroutinefunction(factory) else factory()
            entry_ttl = ttl or self.default_ttl
            entry_tags = set(tags or [])
            
            self._data[key] = CacheEntry(
                value=value,
                expires_at=time.monotonic() + entry_ttl,
                tags=entry_tags,
            )
            
            # Индексировать по тегам
            for tag in entry_tags:
                if tag not in self._tag_index:
                    self._tag_index[tag] = set()
                self._tag_index[tag].add(key)
            
            return value
    
    def invalidate(self, key: K) -> None:
        """Инвалидировать один ключ."""
        if entry := self._data.pop(key, None):
            for tag in entry.tags:
                if tag in self._tag_index:
                    self._tag_index[tag].discard(key)
    
    def invalidate_tag(self, tag: str) -> None:
        """Инвалидировать все ключи с тегом."""
        for key in self._tag_index.pop(tag, set()):
            self._data.pop(key, None)
    
    def invalidate_all(self) -> None:
        """Полная инвалидация."""
        self._data.clear()
        self._tag_index.clear()

# Использование:
# cache = SmartCache[str, dict]()
# users = await cache.get_or_compute(
#     key="users:active",
#     factory=lambda: db.fetch("SELECT * FROM users WHERE active=true"),
#     ttl=60,
#     tags=["users", "active"],
# )
# cache.invalidate_tag("users")  # Когда пользователь изменился
```

## 4. Structured Logging with Context

```python
"""Структурированное логирование с контекстом запроса."""
from __future__ import annotations

import contextvars
import logging
import uuid
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any

# Контекст запроса (thread-safe, asyncio-safe)
_request_id: contextvars.ContextVar[str] = contextvars.ContextVar("request_id", default="")
_user_id: contextvars.ContextVar[int | None] = contextvars.ContextVar("user_id", default=None)

def get_request_id() -> str:
    if not (rid := _request_id.get()):
        rid = uuid.uuid4().hex[:12]
        _request_id.set(rid)
    return rid

class StructLogger:
    """Структурированный логгер с автоматическим контекстом."""
    
    def __init__(self, name: str) -> None:
        self._logger = logging.getLogger(name)
    
    def _log(self, level: int, msg: str, **extra: Any) -> None:
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": logging.getLevelName(level).lower(),
            "logger": self._logger.name,
            "msg": msg,
            "request_id": get_request_id(),
        }
        if uid := _user_id.get():
            record["user_id"] = uid
        record.update(extra)
        self._logger.log(level, json.dumps(record, default=str))
    
    def info(self, msg: str, **kw: Any) -> None:
        self._log(logging.INFO, msg, **kw)
    
    def error(self, msg: str, **kw: Any) -> None:
        self._log(logging.ERROR, msg, **kw)
    
    def warning(self, msg: str, **kw: Any) -> None:
        self._log(logging.WARNING, msg, **kw)

logger = StructLogger("myapp")

# Middleware для установки контекста
async def request_middleware(request: Any, call_next: Callable) -> Any:
    _request_id.set(uuid.uuid4().hex[:12])
    if user := getattr(request, "user", None):
        _user_id.set(user.id)
    logger.info("request_start", method=request.method, path=str(request.url))
    try:
        response = await call_next(request)
        logger.info("request_end", status=response.status_code)
        return response
    except Exception:
        logger.error("request_error")
        raise
```

## 5. Background Task Manager

```python
"""Фоновые задачи с контролем жизненного цикла."""
from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

@dataclass
class TaskManager:
    """Управление фоновыми задачами."""
    
    _tasks: dict[str, asyncio.Task[Any]] = field(default_factory=dict, init=False)
    _loop: asyncio.AbstractEventLoop | None = None
    
    def __post_init__(self) -> None:
        self._loop = asyncio.get_event_loop()
    
    def create(self, name: str, coro: Awaitable[Any]) -> asyncio.Task[Any]:
        """Создать фоновую задачу."""
        task = self._loop.create_task(coro, name=name)
        task.add_done_callback(lambda t: self._on_done(name, t))
        self._tasks[name] = task
        return task
    
    def _on_done(self, name: str, task: asyncio.Task[Any]) -> None:
        self._tasks.pop(name, None)
        if exc := task.exception():
            logger.error("background_task_failed", task=name, error=str(exc))
    
    async def cancel(self, name: str) -> None:
        """Отменить задачу по имени."""
        if task := self._tasks.get(name):
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
    
    async def cancel_all(self) -> None:
        """Отменить все фоновые задачи."""
        for name in list(self._tasks):
            await self.cancel(name)
    
    @property
    def active_count(self) -> int:
        return len(self._tasks)

# Использование:
# tm = TaskManager()
# tm.create("polling", poll_forever())
# await tm.cancel("polling")
```

## 6. Batch Processor

```python
"""Пакетная обработка с контролем скорости."""
from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar

T = TypeVar("T")
R = TypeVar("R")

@dataclass
class BatchProcessor(Generic[T, R]):
    """Обрабатывает элементы пачками с контролем скорости."""
    handler: Callable[[list[T]], Any]  # Обрабатывает пачку
    batch_size: int = 100
    max_concurrency: int = 5
    flush_interval: float = 1.0  # Максимум ждать перед принудительным flush
    
    _queue: asyncio.Queue[T] = field(default_factory=asyncio.Queue, init=False)
    _sem: asyncio.Semaphore = field(init=False)
    _results: list[R] = field(default_factory=list, init=False)
    
    def __post_init__(self) -> None:
        self._sem = asyncio.Semaphore(self.max_concurrency)
    
    async def add(self, item: T) -> None:
        """Добавить элемент в очередь обработки."""
        await self._queue.put(item)
    
    async def stream(self) -> AsyncIterator[list[R]]:
        """Поток обработанных пачек."""
        while True:
            batch = await self._collect_batch()
            if not batch:
                break
            async with self._sem:
                results = await self.handler(batch)
                yield results
    
    async def _collect_batch(self) -> list[T]:
        """Собрать пачку элементов (ожидая до flush_interval)."""
        batch: list[T] = []
        try:
            first = await asyncio.wait_for(self._queue.get(), timeout=self.flush_interval)
            batch.append(first)
        except TimeoutError:
            return batch
        
        # Забрать остальные (без ожидания)
        while len(batch) < self.batch_size:
            try:
                item = self._queue.get_nowait()
                batch.append(item)
            except asyncio.QueueEmpty:
                break
        
        return batch

# Использование:
# processor = BatchProcessor[int, int](
#     handler=lambda batch: [x * 2 async for x in batch_processor(batch)],
#     batch_size=50,
# )
# for batch_results in processor.stream():
#     print(batch_results)
```

## 7. Event Bus (in-process)

```python
"""In-process event bus для слабой связанности."""
from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

type EventHandler = Callable[..., Any]

@dataclass
class EventBus:
    """Простая шина событий в процессе."""
    
    _handlers: dict[str, list[EventHandler]] = field(default_factory=dict, init=False)
    
    def on(self, event: str) -> Callable:
        """Декоратор для подписки на событие."""
        def decorator(handler: EventHandler) -> EventHandler:
            if event not in self._handlers:
                self._handlers[event] = []
            self._handlers[event].append(handler)
            return handler
        return decorator
    
    async def emit(self, event: str, **data: Any) -> None:
        """Отправить событие всем подписчикам."""
        if handlers := self._handlers.get(event):
            results = await asyncio.gather(
                *(h(**data) for h in handlers),
                return_exceptions=True,
            )
            for handler, result in zip(handlers, results):
                if isinstance(result, Exception):
                    logger.error("event_handler_failed", event=event, handler=handler.__name__, error=str(result))
    
    def emit_sync(self, event: str, **data: Any) -> None:
        """Синхронная отправка (для скриптов/CLI)."""
        if handlers := self._handlers.get(event):
            for handler in handlers:
                try:
                    handler(**data)
                except Exception as e:
                    logger.error("event_handler_failed", event=event, handler=handler.__name__, error=str(e))

# Использование:
# bus = EventBus()
#
# @bus.on("user.created")
# async def send_welcome_email(user_id: int, email: str) -> None:
#     await email_service.send(email, "Welcome!")
#
# @bus.on("user.created")
# async def log_new_user(user_id: int, **kw: Any) -> None:
#     logger.info("new_user", user_id=user_id)
#
# await bus.emit("user.created", user_id=42, email="user@example.com")
```

## 8. Idempotency Guard

```python
"""Защита от повторной обработки (идемпотентность)."""
from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

@dataclass
class IdempotencyGuard:
    """Гарантирует, что операция выполнится только один раз."""
    storage: Any  # Redis / dict store
    ttl: float = 86400  # 24 часа
    
    def key(self, operation: str, *args: Any, **kwargs: Any) -> str:
        """Создать ключ идемпотентности."""
        raw = json.dumps({"op": operation, "args": args, "kwargs": kwargs}, sort_keys=True, default=str)
        return f"idempotency:{hashlib.sha256(raw.encode()).hexdigest()[:16]}"
    
    async def execute(self, operation: str, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Выполнить с идемпотентностью."""
        id_key = self.key(operation, *args, **kwargs)
        
        # Уже было?
        if cached := await self.storage.get(id_key):
            return json.loads(cached)["result"]
        
        # Выполнить
        result = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
        
        # Сохранить результат
        await self.storage.setex(id_key, self.ttl, json.dumps({"result": result}, default=str))
        
        return result

# Использование:
# guard = IdempotencyGuard(storage=redis_client)
# result = await guard.execute("charge", charge_user, user_id=42, amount=100)
```

## 9. State Machine

```python
"""Finit state machine для бизнес-процессов."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Self

class OrderState(Enum):
    PENDING = auto()
    CONFIRMED = auto()
    PROCESSING = auto()
    SHIPPED = auto()
    DELIVERED = auto()
    CANCELLED = auto()

@dataclass
class StateMachine:
    """Простая state machine."""
    
    transitions: dict[Enum, dict[Enum, bool]] = field(default_factory=dict)
    
    def allow(self, from_state: Enum, to_state: Enum) -> Self:
        if from_state not in self.transitions:
            self.transitions[from_state] = {}
        if to_state not in self.transitions.get(from_state, {}):
            self.transitions[from_state][to_state] = True
        return self
    
    def can(self, current: Enum, target: Enum) -> bool:
        return self.transitions.get(current, {}).get(target, False)
    
    def validate(self, current: Enum, target: Enum) -> None:
        if not self.can(current, target):
            raise ValueError(f"Transition {current.name} → {target.name} not allowed")

# Определение transitions
order_sm = (StateMachine()
    .allow(OrderState.PENDING, OrderState.CONFIRMED)
    .allow(OrderState.PENDING, OrderState.CANCELLED)
    .allow(OrderState.CONFIRMED, OrderState.PROCESSING)
    .allow(OrderState.CONFIRMED, OrderState.CANCELLED)
    .allow(OrderState.PROCESSING, OrderState.SHIPPED)
    .allow(OrderState.PROCESSING, OrderState.CANCELLED)
    .allow(OrderState.SHIPPED, OrderState.DELIVERED)
)

# Использование:
# order_sm.validate(order.state, OrderState.SHIPPED)
# order.state = OrderState.SHIPPED
```

## 10. Query Object (instead of raw SQL everywhere)

```python
"""Типизированные запросы вместо raw SQL."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Self

@dataclass
class Query:
    """Построитель запросов с типизацией."""
    
    filters: list[tuple[str, str, Any]] | None = None
    sort: tuple[str, bool] | None = None  # (field, asc)
    limit: int | None = None
    offset: int = 0
    
    def where(self, field: str, op: str = "=", value: Any = None) -> Self:
        if self.filters is None:
            self.filters = []
        self.filters.append((field, op, value))
        return self
    
    def order_by(self, field: str, asc: bool = True) -> Self:
        self.sort = (field, asc)
        return self
    
    def with_limit(self, limit: int) -> Self:
        self.limit = limit
        return self
    
    def with_offset(self, offset: int) -> Self:
        self.offset = offset
        return self

# Repository использует Query
class UserRepository:
    async def find(self, query: Query) -> list[User]:
        stmt = select(User)
        if query.filters:
            stmt = stmt.where(*(getattr(User, f) == v for f, op, v in query.filters if op == "="))
        if query.sort:
            col = getattr(User, query.sort[0])
            stmt = stmt.order_by(col.asc() if query.sort[1] else col.desc())
        if query.limit:
            stmt = stmt.limit(query.limit).offset(query.offset)
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

# Использование:
# users = await repo.find(
#     Query()
#     .where("is_active", "=", True)
#     .order_by("created_at", asc=False)
#     .with_limit(20)
#     .with_offset(0)
# )
```
