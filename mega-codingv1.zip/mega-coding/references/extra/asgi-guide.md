# ASGI Guide

## Что такое ASGI
ASGI — Asynchronous Server Gateway Interface, преемник WSGI для async Python.

## Базовая ASGI-аппка
```python
async def app(scope, receive, send):
    assert scope["type"] == "http"

    await send({
        "type": "http.response.start",
        "status": 200,
        "headers": [(b"content-type", b"text/plain")],
    })
    await send({
        "type": "http.response.body",
        "body": b"Hello, ASGI!",
    })
```

## ASGI Middleware
```python
class TimingMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        import time
        start = time.perf_counter()

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                elapsed = time.perf_counter() - start
                print(f"Request took {elapsed:.3f}s")
            await send(message)

        await self.app(scope, receive, send_wrapper)
```

## WebSocket через ASGI
```python
async def websocket_app(scope, receive, send):
    assert scope["type"] == "websocket"

    await send({"type": "websocket.accept"})

    while True:
        event = await receive()
        if event["type"] == "websocket.receive":
            await send({
                "type": "websocket.send",
                "text": f"Echo: {event['text']}",
            })
        elif event["type"] == "websocket.disconnect":
            break
```

## Lifespan
```python
async def lifespan_app(scope, receive, send):
    assert scope["type"] == "lifespan"

    while True:
        event = await receive()
        if event["type"] == "lifespan.startup":
            print("Starting up...")
            await send({"type": "lifespan.startup.complete"})
        elif event["type"] == "lifespan.shutdown":
            print("Shutting down...")
            await send({"type": "lifespan.shutdown.complete"})
            break
```

## Популярные ASGI-фреймворки
- **FastAPI** — современный, с Pydantic
- **Starlette** — лёгкий, гибкий
- **Django Channels** — для Django
- **Quart** — Flask-совместимый async

## Запуск
```bash
# uvicorn
uvicorn app:app --reload --host 0.0.0.0 --port 8000 --workers 4

# hypercorn (поддерживает HTTP/2)
hypercorn app:app --worker-class uvloop --bind 0.0.0.0:8000
```

## Сравнение WSGI vs ASGI
| WSGI | ASGI |
|------|------|
| Синхронный | Асинхронный |
| Только HTTP | HTTP + WebSocket + другие протоколы |
| Один запрос = один поток | Один запрос = одна корутина |
| Не поддерживает long-poll | Поддерживает |
| Gunicorn/uWSGI | Uvicorn/Hypercorn/Daphne |
