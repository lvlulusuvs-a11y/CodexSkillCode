# Caching Patterns

**Полный справочник по кэшированию в Python.**

---

## 1. In-Memory Caching

```python
from functools import lru_cache
from datetime import datetime, timedelta

# Simple function cache
@lru_cache(maxsize=128)
def get_user(user_id: int) -> dict:
    return db.query(f"SELECT * FROM users WHERE id = {user_id}")

# Time-based cache
cache: dict[str, tuple[datetime, Any]] = {}

def cached(ttl: int = 300):
    def decorator(func):
        def wrapper(*args, **kwargs):
            key = f"{func.__name__}:{args}:{kwargs}"
            if key in cache:
                created, value = cache[key]
                if datetime.now() - created < timedelta(seconds=ttl):
                    return value
            result = func(*args, **kwargs)
            cache[key] = (datetime.now(), result)
            return result
        return wrapper
    return decorator
```

## 2. Redis Cache Patterns

```python
import redis.asyncio as aioredis
import json

# Cache-Aside
async def get_user_cached(user_id: int) -> dict:
    key = f"user:{user_id}"
    
    # Try cache
    if cached := await redis.get(key):
        return json.loads(cached)
    
    # Miss → DB
    user = await get_user_from_db(user_id)
    
    # Fill cache
    await redis.setex(key, 300, json.dumps(user))
    
    return user
```

## 3. Multi-Level Cache

```python
class MultiLevelCache:
    def __init__(self):
        self._local: dict[str, Any] = {}  # L1
        self._redis: aioredis.Redis = None  # L2
    
    async def get(self, key: str) -> Any:
        # L1: local memory
        if key in self._local:
            return self._local[key]
        
        # L2: Redis
        if self._redis:
            if cached := await self._redis.get(key):
                self._local[key] = json.loads(cached)
                return self._local[key]
        
        return None
    
    async def set(self, key: str, value: Any, ttl: int = 300):
        self._local[key] = value
        if self._redis:
            await self._redis.setex(key, ttl, json.dumps(value))
```

## 4. Cache Invalidation Strategies

```python
# TTL-based (simplest)
await redis.setex(key, 300, value)

# Write-Through (always fresh)
await db.update(user)
await redis.setex(key, 300, json.dumps(user))

# Write-Behind (async)
await redis.setex(key, 300, json.dumps(data))
await queue.put(("update_db", data))

# Event-based
async def on_user_updated(event):
    await redis.delete(f"user:{event.user_id}")
    await redis.delete(f"user:orders:{event.user_id}")
```

## 5. Cache Stampede Protection

```python
import asyncio
import random

async def get_or_compute(key: str, factory, ttl: int = 300):
    # Early expiration (recompute before TTL expires)
    early_ttl = ttl * 0.8
    
    cached = await redis.get(key)
    if cached:
        data = json.loads(cached)
        # Check if we should early recompute
        remaining = await redis.ttl(key)
        if remaining < ttl * 0.2:
            # Probabilistic early recomputation
            if random.random() < 0.1:
                asyncio.create_task(_recompute(key, factory, ttl))
        return data
    
    return await _recompute(key, factory, ttl)

async def _recompute(key: str, factory, ttl: int):
    value = await factory()
    await redis.setex(key, ttl, json.dumps(value))
    return value
```
