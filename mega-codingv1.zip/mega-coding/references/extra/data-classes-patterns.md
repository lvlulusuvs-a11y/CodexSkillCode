# Data Classes Deep Dive

## Frozen dataclasses (immutable)
```python
from dataclasses import dataclass

@dataclass(frozen=True)
class Point:
    x: float
    y: float

p = Point(1, 2)
# p.x = 3  # FrozenInstanceError!
```

## Inheritance
```python
@dataclass
class Base:
    id: int
    created_at: str = ""

@dataclass
class User(Base):
    name: str
    email: str
    active: bool = True

# Поля: id, created_at, name, email, active
user = User(id=1, name="Alice", email="a@test.com")
```

## Slots (3.10+)
```python
@dataclass(slots=True)
class FastPoint:
    x: float
    y: float
    z: float

# Экономия памяти: нет __dict__
```

## Field customization
```python
from dataclasses import field
from typing import Any

@dataclass
class Config:
    name: str
    host: str = "localhost"
    port: int = field(default=8080, repr=False)
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict, compare=False)
```

## __post_init__
```python
@dataclass
class User:
    id: int
    name: str
    name_upper: str = field(init=False)

    def __post_init__(self):
        self.name_upper = self.name.upper()

user = User(id=1, name="Alice")
assert user.name_upper == "ALICE"
```

## asdict и astuple
```python
from dataclasses import asdict, astuple, replace

@dataclass
class User:
    id: int
    name: str

u = User(1, "Alice")
d = asdict(u)      # {"id": 1, "name": "Alice"}
t = astuple(u)     # (1, "Alice")
u2 = replace(u, name="Bob")  # User(1, "Bob")
```

## Dataclass JSON serialization
```python
from dataclasses import dataclass, asdict
import json

@dataclass
class Address:
    city: str
    street: str

@dataclass
class Person:
    name: str
    age: int
    address: Address

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, ensure_ascii=False)

    @classmethod
    def from_json(cls, data: str) -> "Person":
        raw = json.loads(data)
        raw["address"] = Address(**raw["address"])
        return cls(**raw)

p = Person("Alice", 30, Address("Moscow", "Tverskaya"))
print(p.to_json())
p2 = Person.from_json(p.to_json())
assert p == p2
```

## Dataclass vs NamedTuple
```python
from typing import NamedTuple

class PointNT(NamedTuple):
    x: float
    y: float

# NamedTuple: immutable, iterable, hashable
# dataclass: mutable by default, more features

# Когда выбирать:
# NamedTuple — простые неизменяемые структуры
# dataclass — сложные объекты с логикой
```
