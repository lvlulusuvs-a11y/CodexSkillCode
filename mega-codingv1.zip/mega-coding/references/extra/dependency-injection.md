# Dependency Injection in Python

**Паттерны DI без фреймворков.**

---

## 1. Простой DI через конструктор

```python
class UserService:
    def __init__(self, repo: UserRepository, email_service: EmailService) -> None:
        self._repo = repo
        self._email = email_service
    
    async def register(self, email: str, name: str) -> User:
        if await self._repo.get_by_email(email):
            raise ConflictError("Email exists")
        user = await self._repo.create(email=email, name=name)
        await self._email.send_welcome(user)
        return user
```

## 2. DI через FastAPI Depends

```python
from fastapi import Depends

def get_user_repo(db: AsyncSession = Depends(get_db)) -> UserRepository:
    return UserRepository(db)

def get_email_service() -> EmailService:
    return EmailService(settings.SMTP_URL)

def get_user_service(
    repo: UserRepository = Depends(get_user_repo),
    email: EmailService = Depends(get_email_service),
) -> UserService:
    return UserService(repo, email)

@router.post("/users")
async def create_user(
    data: UserCreate,
    service: UserService = Depends(get_user_service),
) -> User:
    return await service.register(data.email, data.name)
```

## 3. DI через контейнер (для тестов)

```python
from dataclasses import dataclass, field
from typing import Any

class DIContainer:
    """Простой DI контейнер."""
    
    def __init__(self) -> None:
        self._services: dict[type, Any] = {}
        self._factories: dict[type, Any] = {}
    
    def register(self, type_: type, instance: Any = None) -> None:
        if instance:
            self._services[type_] = instance
        else:
            self._factories[type_] = type_
    
    def resolve(self, type_: type) -> Any:
        if type_ in self._services:
            return self._services[type_]
        if type_ in self._factories:
            instance = self._factories[type_]()
            self._services[type_] = instance
            return instance
        raise KeyError(f"No registration for {type_}")

# Использование
container = DIContainer()
container.register(Database, Database("sqlite:///:memory:"))
container.register(UserRepository)
db = container.resolve(Database)
```

## 4. DI через functools.lru_cache (синглтоны)

```python
from functools import lru_cache

@lru_cache
def get_settings() -> Settings:
    return Settings()

@lru_cache
def get_db() -> Database:
    return Database(get_settings().DATABASE_URL)

@lru_cache
def get_user_repo() -> UserRepository:
    return UserRepository(get_db())
```

## 5. DI для тестов

```python
# Переопределение зависимостей
@pytest.fixture
def mock_email():
    return AsyncMock()

@pytest.fixture
def user_service(mock_email):
    repo = FakeUserRepository()
    return UserService(repo, mock_email)

@pytest.mark.asyncio
async def test_register(user_service, mock_email):
    user = await user_service.register("test@test.com", "Test")
    assert user.email == "test@test.com"
    mock_email.send_welcome.assert_called_once()
```
