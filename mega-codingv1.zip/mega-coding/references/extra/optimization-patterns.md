# Optimization Patterns

**Конкретные приёмы оптимизации Python-кода. Не преждевременная оптимизация — измеренная и целенаправленная.**

---

## Правило: сначала измерь

```python
from time import perf_counter
from functools import wraps

def benchmark(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = perf_counter()
        result = func(*args, **kwargs)
        elapsed = perf_counter() - start
        print(f"{func.__name__}: {elapsed*1000:.2f}ms")
        return result
    return wrapper

# Или используй scripts/benchmark.py
# python scripts/benchmark.py
```

## ⚡ Fast Paths (горячие пути)

### 1. Local variable binding (локальные переменные быстрее)

```python
# ❌ Медленно: global lookup каждый раз
def slow(items: list[int]) -> list[int]:
    return [x * 2 for x in items if x > 0]

# ✅ Быстрее: local aliases
def fast(items: list[int]) -> list[int]:
    double = lambda x: x * 2  # local
    return [double(x) for x in items if x > 0]

# ✅ Самый быстрый: comprehension без лишних вызовов
def fastest(items: list[int]) -> list[int]:
    return [x * 2 for x in items if x > 0]  # встроенные операции
```

### 2. Avoid dot lookups в циклах

```python
# ❌ Медленно: dot lookup на каждой итерации
def slow(items: list[str]) -> list[str]:
    result = []
    for item in items:
        result.append(item.strip().lower())
    return result

# ✅ Быстрее: local reference
def fast(items: list[str]) -> list[str]:
    result = []
    append = result.append
    strip = str.strip
    lower = str.lower
    for item in items:
        append(strip(item).lower())  # нет dot lookup
    return result
```

### 3. Use built-in functions (встроенные быстрее)

```python
# ❌ Медленно
total = 0
for x in range(1000000):
    total += x

# ✅ Быстро (C-level)
total = sum(range(1000000))

# ❌ Медленно
squared = []
for x in range(100):
    squared.append(x * x)

# ✅ Быстро
squared = [x * x for x in range(100)]

# ❌ Медленно
doubled = list(map(lambda x: x * 2, items))

# ✅ Быстро
doubled = [x * 2 for x in items]
```

### 4. Generator expressions (ленивость)

```python
# ❌ Выделяет всю память сразу
all_data = [process(item) for item in huge_list]
result = sum(all_data)

# ✅ Лениво, не выделяет память
result = sum(process(item) for item in huge_list)
```

## 🧠 Data Structure Selection

| Операция | List | Set | Dict | Deque |
|----------|------|-----|------|-------|
| Поиск | O(n) | O(1) | O(1) | O(n) |
| Вставка в конец | O(1) | O(1) | O(1)* | O(1) |
| Вставка в начало | O(n) | - | - | O(1) |
| Удаление | O(n) | O(1) | O(1) | O(n) |

*В среднем; худший случай O(n) при коллизиях.

```python
# Для поиска — set/dict, не list
# ❌ O(n)
if x in big_list: ...

# ✅ O(1)
if x in big_set: ...

# Для очереди — deque, не list
# ❌ O(n) pop(0)
queue = list
queue.pop(0)

# ✅ O(1) popleft
from collections import deque
queue = deque()
queue.popleft()
```

## 🗄️ String Optimization

```python
# Конкатенация строк
# ❌ O(n²) — создаёт новую строку на каждой итерации
s = ""
for part in parts:
    s += part

# ✅ O(n) — собирает в список, join один раз
s = "".join(parts)

# Форматирование
name = "Alice"; age = 30
# ❌ Старые способы
s = "Name: " + name + ", Age: " + str(age)
s = "Name: %s, Age: %d" % (name, age)

# ✅ Быстро и читаемо
s = f"Name: {name}, Age: {age}"
```

## 📦 Memory Optimization

### __slots__ для тысяч объектов

```python
# Без __slots__: каждый объект имеет __dict__ (~500 bytes overhead)
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

# С __slots__: фиксированные атрибуты (~56 bytes overhead, ~90% экономии)
class Point:
    __slots__ = ("x", "y")
    def __init__(self, x, y):
        self.x = x
        self.y = y
```

### Array vs list для чисел

```python
# list: хранит Python-объекты (~28 bytes/int + указатель)
numbers = [1, 2, 3, 4, 5]

# array: хранит C-значения (~4 bytes/int)
from array import array
numbers = array("i", [1, 2, 3, 4, 5])  # в 7 раз меньше памяти

# numpy: для больших массивов
import numpy as np
numbers = np.array([1, 2, 3, 4, 5], dtype=np.int32)
```

### Generator вместо list

```python
# Список: вся память сразу
def get_data() -> list[int]:
    return [fetch(x) for x in range(1_000_000)]

# Генератор: лениво, по одному
def get_data() -> Iterator[int]:
    return (fetch(x) for x in range(1_000_000))
```

## ⚙️ Async I/O

```python
# Параллельные запросы
# ❌ Последовательно: total = N * latency
for url in urls:
    data = await fetch(url)

# ✅ Параллельно: total = max(latency)
tasks = [fetch(url) for url in urls]
results = await asyncio.gather(*tasks)

# С контролем параллелизма
sem = asyncio.Semaphore(10)
async def bounded_fetch(url):
    async with sem:
        return await fetch(url)

results = await asyncio.gather(*[bounded_fetch(url) for url in urls])
```

## 🔍 Profiling (как найти узкое место)

```python
# Basic: time module
start = perf_counter()
result = expensive_function()
print(f"Took {perf_counter() - start:.3f}s")

# cProfile (встроенный)
# python -m cProfile -s cumulative my_script.py

# py-spy (без остановки кода)
# pip install py-spy
# py-spy record -o profile.svg -- python my_script.py

# memory_profiler
# @profile
# def my_func(): ...

# line_profiler (построчно)
# @profile
# def slow_function():
#     ...
# kernprof -l -v my_script.py
```

## 🏗️ Architectural Optimization

### Ленивая инициализация

```python
class Config:
    @property
    def database(self) -> Database:
        """Лениво: БД создаётся только при первом обращении."""
        if not hasattr(self, "_db"):
            self._db = Database(self.db_url)
        return self._db

# Или через functools.cached_property
from functools import cached_property

class Service:
    @cached_property
    def client(self) -> Client:
        """Вычисляется один раз, кэшируется."""
        return Client(self.config.api_url)
```

### Кэширование результатов

```python
from functools import lru_cache

# Для чистых функций
@lru_cache(maxsize=128)
def fibonacci(n: int) -> int:
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

# Для асинхронных
from functools import lru_cache

@lru_cache(maxsize=256)
async def fetch_user(user_id: int) -> dict:
    async with aiohttp.ClientSession() as session:
        async with session.get(f"/users/{user_id}") as resp:
            return await resp.json()
```

### Batch Processing (пакетная обработка)

```python
# ❌ N запросов
for item in items:
    await db.save(item)

# ✅ 1 запрос
await db.save_all(items)

# ❌ N маленьких транзакций
for item in items:
    async with db.transaction():
        await db.save(item)

# ✅ 1 большая транзакция
async with db.transaction():
    for item in items:
        await db.save(item)
```

### Connection Pooling

```python
# Всегда используй пул соединений
engine = create_async_engine(
    DATABASE_URL,
    pool_size=5,        # постоянные соединения
    max_overflow=10,     # доп. при нагрузке
    pool_pre_ping=True,  # проверка здоровья
)
```

## 📊 Quick Reference

| Ситуация | Что делать | Ожидаемый выигрыш |
|----------|-----------|------------------|
| Много конкатенации строк | `"".join(list)` | 10-100x |
| Поиск в большой коллекции | list→set | 100-1000x |
| Много объектов с атрибутами | `__slots__` | 5-10x память |
| CPU-bound вычисления | multiprocessing / numba | N-cores x |
| I/O-bound операции | asyncio + gather | N-connections x |
| Тяжёлые вычисления | кэш результатов | Зависит от hit rate |
| Dot в цикле | local reference | 2-5x |
| Большие списки чисел | array / numpy | 7x память + 10x скорость |
