# FastAPI Best Practices

**Как писать FastAPI приложения для продакшена.**

---

## 1. Project Structure

```
project/
├── src/
│   ├── main.py              # FastAPI app
│   ├── config.py            # pydantic-settings
│   ├── database.py          # engine + session
│   ├── routers/             # API routes
│   │   ├── __init__.py
│   │   └── users.py
│   ├── models/              # SQLAlchemy models
│   ├── schemas/             # Pydantic schemas
│   ├── services/            # Business logic
│   ├── repositories/        # DB queries
│   └── dependencies.py      # FastAPI dependencies
├── tests/
├── .env
├── Dockerfile
└── pyproject.toml
```

## 2. Application Factory

```python
from fastapi import FastAPI
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: init DB, Redis, etc.
    await database.connect()
    yield
    # Shutdown: close connections
    await database.disconnect()

def create_app() -> FastAPI:
    app = FastAPI(
        title="MyApp",
        version="1.0.0",
        lifespan=lifespan,
        docs_url="/docs" if settings.DEBUG else None,
    )
    
    # Middleware
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
    
    # Routers
    app.include_router(users.router, prefix="/api/v1/users", tags=["users"])
    app.include_router(health.router, prefix="/api/v1", tags=["health"])
    
    # Exception handlers
    register_exception_handlers(app)
    
    return app

app = create_app()
```

## 3. Dependency Injection

```python
from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

# DB session
async def get_db() -> AsyncIterator[AsyncSession]:
    async with SessionLocal() as session:
        yield session

# Current user
async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    payload = verify_token(token)
    user = await user_repo.get(db, payload["user_id"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

# Router
@router.get("/me")
async def get_me(user: User = Depends(get_current_user)):
    return user
```

## 4. Pydantic Schemas

```python
from pydantic import BaseModel, EmailStr, Field, field_validator

class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(ge=0, le=150)
    
    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if any(c in v for c in "<>\"'%"):
            raise ValueError("Invalid characters")
        return v.strip()

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    created_at: datetime
    
    model_config = {"from_attributes": True}  # ORM mode
```

## 5. Error Handling

```python
from fastapi import Request
from fastapi.responses import JSONResponse

class AppError(Exception):
    def __init__(self, message: str, code: str = "ERROR", status: int = 400):
        self.message = message
        self.code = code
        self.status = status

@app.exception_handler(AppError)
async def app_error_handler(request: Request, exc: AppError):
    return JSONResponse(
        status_code=exc.status,
        content={"error": exc.code, "message": exc.message},
    )

@app.exception_handler(Exception)
async def general_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error")
    return JSONResponse(
        status_code=500,
        content={"error": "INTERNAL_ERROR", "message": "Internal server error"},
    )
```

## 6. Logging

```python
import structlog

logger = structlog.get_logger()

@app.middleware("http")
async def log_requests(request: Request, call_next):
    structlog.contextvars.bind_contextvars(
        request_id=uuid.uuid4().hex[:8],
        method=request.method,
        path=str(request.url),
    )
    start = time.perf_counter()
    
    response = await call_next(request)
    
    duration = time.perf_counter() - start
    logger.info("request_completed", status=response.status_code, duration_ms=f"{duration*1000:.0f}")
    
    return response
```

## 7. Pagination

```python
from fastapi import Query

@router.get("/users")
async def list_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db),
):
    users = await user_repo.list(db, skip, limit)
    total = await user_repo.count(db)
    return {
        "data": users,
        "total": total,
        "skip": skip,
        "limit": limit,
    }
```

## 8. Testing

```python
# conftest.py
@pytest_asyncio.fixture
async def client():
    app = create_app()
    async with AsyncClient(app=app, base_url="http://test") as ac:
        yield ac

@pytest.mark.asyncio
async def test_create_user(client):
    response = await client.post("/api/v1/users", json={
        "name": "Alice",
        "email": "alice@test.com",
        "age": 25,
    })
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Alice"
```
