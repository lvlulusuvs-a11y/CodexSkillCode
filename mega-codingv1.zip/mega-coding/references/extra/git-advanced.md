# Advanced Git

**Git команды, которые нужны каждый день. От отладки до recovery.**

---

## 1. Поиск в истории

```bash
# Найти, когда появился или исчез текст
git log -p -S "function_name" -- src/
git log -p -G "regex_pattern" -- src/

# Найти коммиты по сообщению
git log --all --oneline --grep="fix crash"
git log --all --oneline --grep="JIRA-123"

# Кто изменил строку
git blame -L 10,20 src/main.py

# История файла (включая переименования)
git log --oneline --follow -- src/moved_file.py
```

## 2. Работа с коммитами

```bash
# Amend последнего коммита
git commit --amend -m "new message"
git commit --amend --no-edit  # изменить файлы, не меняя сообщение

# Interactive rebase (последние 3 коммита)
git rebase -i HEAD~3
# Commands: pick, reword, edit, squash, fixup, drop

# Отменить последний коммит (сохранить изменения)
git reset --soft HEAD~1

# Отменить последний коммит (удалить изменения)
git reset --hard HEAD~1

# Взять конкретный файл из другого коммита
git checkout abc1234 -- src/file.py

# Отменить изменения в конкретном файле
git checkout -- src/file.py
```

## 3. Stash

```bash
# Спрятать изменения
git stash -u  # включая новые файлы
git stash push -m "work in progress"

# Посмотреть stash
git stash list
git stash show -p stash@{0}

# Вернуть stash
git stash pop     # вернуть и удалить
git stash apply   # вернуть, не удаляя

# Удалить stash
git stash drop stash@{0}
git stash clear   # все
```

## 4. Branch management

```bash
# Удалить локальные ветки, которых нет на remote
git remote prune origin

# Удалить смерженные ветки
git branch --merged | grep -v "main\|master" | xargs git branch -d

# Показать граф
git log --all --oneline --graph --decorate

# Сравнить ветки (только свои коммиты)
git log --oneline main..feature
git diff main..feature -- src/

# Ветка от конкретного коммита
git branch feature abc1234
```

## 5. Cherry-pick

```bash
# Взять коммит из другой ветки
git cherry-pick abc1234

# Взять несколько коммитов
git cherry-pick abc1234..def5678

# С опцией --no-commit (применить, но не коммитить)
git cherry-pick -n abc1234
```

## 6. Fix conflicts

```bash
# После merge конфликта:
git mergetool  # визуальное разрешение
# Или вручную: Accept theirs / Accept ours

# Принять "их" версию для всего файла
git checkout --theirs -- src/file.py
# Принять "свою" версию
git checkout --ours -- src/file.py

# После разрешения
git add src/file.py
git commit --no-edit
```

## 7. Recovery

```bash
# Восстановить удалённый файл
git checkout abc1234^ -- src/deleted_file.py

# Найти потерянные коммиты (после reset --hard)
git reflog
git checkout HEAD@{2}

# Восстановить ветку
git branch recovered-branch HEAD@{2}

# Отменить rebase (всё ещё в reflog)
git reset --hard ORIG_HEAD
```

## 8. Bisect (поиск бага)

```bash
# Начать поиск коммита, который ввёл баг
git bisect start
git bisect bad        # текущий коммит — баг
git bisect good v1.0  # v1.0 — работал

# Git будет переключаться по коммитам
# На каждом проверяй: есть баг? → git bisect bad / git bisect good

# Закончить
git bisect reset
```

## 9. Config

```bash
# Полезные настройки
git config --global alias.lg "log --oneline --graph --all --decorate"
git config --global alias.st "status -sb"
git config --global alias.df "diff --word-diff"
git config --global pull.rebase true
git config --global fetch.prune true
```

## 10. Worktrees (параллельная работа)

```bash
# Создать рабочий каталог для другой ветки
git worktree add ../project-feature feature-branch

# Не переключаясь между ветками
# cd project-feature && работа в feature-branch
# cd project && продолжение работы в main

# Список worktrees
git worktree list

# Удалить
git worktree remove ../project-feature
```
