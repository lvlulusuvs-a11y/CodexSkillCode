# SOLID Principles in Python

## S — Single Responsibility
```python
# ❌ Плохо: класс делает всё
class UserManager:
    def create_user(self, data): ...
    def send_email(self, user): ...
    def generate_report(self): ...

# ✅ Хорошо: разделено
class UserService:
    def create_user(self, data): ...

class EmailService:
    def send(self, to: str, msg: str): ...

class ReportService:
    def generate(self): ...
```

## O — Open/Closed
```python
from abc import ABC, abstractmethod

class PaymentProcessor(ABC):
    @abstractmethod
    def process(self, amount: float) -> bool: ...

class CardPayment(PaymentProcessor):
    def process(self, amount: float) -> bool:
        print(f"Card: {amount}")
        return True

class CryptoPayment(PaymentProcessor):
    def process(self, amount: float) -> bool:
        print(f"Crypto: {amount}")
        return True

# Новая реализация — без изменения клиентского кода
class ApplePayPayment(PaymentProcessor):
    def process(self, amount: float) -> bool:
        print(f"ApplePay: {amount}")
        return True
```

## L — Liskov Substitution
```python
class Rectangle:
    def __init__(self, w, h):
        self.w = w
        self.h = h
    def area(self):
        return self.w * self.h

class Square(Rectangle):
    def __init__(self, side):
        super().__init__(side, side)

# ✅ Square можно использовать вместо Rectangle без сюрпризов
def print_area(shape: Rectangle):
    print(shape.area())

print_area(Rectangle(2, 3))  # 6
print_area(Square(4))        # 16
```

## I — Interface Segregation
```python
# ❌ Плохо: толстый интерфейс
class Worker(ABC):
    @abstractmethod
    def work(self): ...
    @abstractmethod
    def eat(self): ...
    @abstractmethod
    def sleep(self): ...

class Robot(Worker):
    def work(self): ...
    def eat(self): pass    # не нужно
    def sleep(self): pass  # не нужно

# ✅ Хорошо: тонкие интерфейсы
class Workable(ABC):
    def work(self): ...

class Eatable(ABC):
    def eat(self): ...

class Human(Workable, Eatable): ...
class Robot(Workable): ...
```

## D — Dependency Inversion
```python
# ❌ Плохо: зависит от конкретной реализации
class PostgresDB:
    def query(self, sql): ...

class UserService:
    def __init__(self):
        self.db = PostgresDB()  # жёсткая связь

# ✅ Хорошо: зависит от абстракции
class Database(ABC):
    def query(self, sql: str) -> list[dict]: ...

class UserService:
    def __init__(self, db: Database):
        self._db = db  # можно подменить

class PostgresDB(Database):
    def query(self, sql):
        return [{"id": 1}]

class MockDB(Database):
    def query(self, sql):
        return [{"id": 1, "test": True}]
```
