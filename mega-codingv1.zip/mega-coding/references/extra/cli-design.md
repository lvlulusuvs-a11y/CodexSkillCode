# CLI Design Patterns

**Как проектировать хорошие CLI-инструменты.**

---

## 1. Выбор библиотеки

```python
# argparse — встроенный, всё есть
# click — декларативный, удобный
# typer — click на type hints (FastAPI-style)
# rich — красивый вывод

# Для серьёзных CLI: click или typer
```

## 2. Typer (современно)

```python
import typer
from typing import Optional
from pathlib import Path

app = typer.Typer()

@app.command()
def init(name: str, directory: Optional[Path] = None, force: bool = False):
    """Initialize a new project."""
    target = (directory or Path.cwd()) / name
    if target.exists() and not force:
        typer.echo(f"Error: {target} exists", err=True)
        raise typer.Exit(code=1)
    target.mkdir(parents=True)
    typer.echo(f"Created {target}")

@app.command()
def build(config: Path = typer.Option("pyproject.toml", "--config", "-c")):
    """Build the project."""
    if not config.exists():
        typer.echo(f"Config not found: {config}", err=True)
        raise typer.Exit(code=1)
    typer.echo("Building...")

if __name__ == "__main__":
    app()
```

## 3. Click (классика)

```python
import click

@click.group()
def cli():
    pass

@cli.command()
@click.argument("name")
@click.option("--dir", "-d", type=click.Path(), default=".")
@click.option("--verbose", "-v", is_flag=True)
def init(name, dir, verbose):
    """Initialize project."""
    click.echo(f"Init {name} in {dir}")

@cli.command()
@click.option("--config", "-c", default="pyproject.toml")
def build(config):
    """Build project."""
    click.echo(f"Build with {config}")

if __name__ == "__main__":
    cli()
```

## 4. Rich вывод

```python
from rich.console import Console
from rich.table import Table
from rich.progress import Progress

console = Console()

# Таблица
table = Table(title="Users")
table.add_column("ID", style="cyan")
table.add_column("Name", style="green")
table.add_column("Status")
table.add_row("1", "Alice", "✅ Active")
table.add_row("2", "Bob", "❌ Inactive")
console.print(table)

# Прогресс
with Progress() as progress:
    task = progress.add_task("Processing...", total=100)
    for i in range(100):
        progress.update(task, advance=1)
```

## 5. Обработка ошибок

```python
import sys

def main():
    try:
        result = process()
        if result.success:
            print(f"✅ {result.message}")
            sys.exit(0)
        else:
            print(f"❌ {result.message}", file=sys.stderr)
            sys.exit(1)
    except ValueError as e:
        print(f"❌ Invalid input: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"❌ Unexpected error: {e}", file=sys.stderr)
        sys.exit(3)
```
