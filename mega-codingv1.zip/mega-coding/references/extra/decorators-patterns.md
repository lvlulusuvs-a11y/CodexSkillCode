# Decorator Patterns (37KB) 

## Basic decorator
```python
from functools import wraps
from typing import Any, Callable

def log(func: Callable) -> Callable:
    @wraps(func)
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__}")
        result = func(*args, **kwargs)
        print(f"Done {func.__name__}: {result}")
        return result
    return wrapper

@log
def add(a, b):
    return a + b
```

## Decorator with args
```python
def repeat(n: int):
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            for _ in range(n):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(n=3)
def greet(name: str):
    print(f"Hello {name}")
```

## Class-based decorator
```python
class CountCalls:
    def __init__(self, func: Callable):
        self.func = func
        self.count = 0

    def __call__(self, *args, **kwargs):
        self.count += 1
        print(f"Call #{self.count} of {self.func.__name__}")
        return self.func(*args, **kwargs)

@CountCalls
def hello():
    print("Hello!")
```

## Async decorator
```python
import asyncio
from functools import wraps

def async_retry(max_retries: int = 3, delay: float = 0.1):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    await asyncio.sleep(delay * (attempt + 1))
            return None
        return wrapper
    return decorator

@async_retry(max_retries=3, delay=0.5)
async def fetch_data(url: str):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            return await resp.json()
```

## Property + cache
```python
from functools import cached_property

class ExpensiveObject:
    @cached_property
    def heavy_data(self) -> list[dict]:
        print("Computing...")
        return [{"id": i, "value": i**2} for i in range(10000)]

obj = ExpensiveObject()
print(len(obj.heavy_data))  # Computing... 10000
print(len(obj.heavy_data))  # 10000 (cached, no compute)
```

## Decorator with state
```python
def cache(func: Callable) -> Callable:
    _cache: dict[str, Any] = {}

    @wraps(func)
    def wrapper(*args, **kwargs):
        key = str((args, sorted(kwargs.items())))
        if key not in _cache:
            _cache[key] = func(*args, **kwargs)
        return _cache[key]
    return wrapper

@cache
def expensive(n: int) -> int:
    print(f"Computing {n}...")
    return n * n

print(expensive(5))  # Computing 5... 25
print(expensive(5))  # 25 (cached)
```
