# Web Development Patterns

**Проверенные паттерны веб-разработки на Python.**

---

## 1. Session Management

```python
from typing import Any
from datetime import datetime, timedelta, timezone
import json, uuid

class SessionStore:
    def __init__(self, redis):
        self._redis = redis
    
    async def create(self, user_id: int, data: dict[str, Any] | None = None) -> str:
        session_id = uuid.uuid4().hex
        session = {
            "user_id": user_id,
            "data": data or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        await self._redis.setex(f"session:{session_id}", 86400, json.dumps(session))
        return session_id
    
    async def get(self, session_id: str) -> dict[str, Any] | None:
        data = await self._redis.get(f"session:{session_id}")
        return json.loads(data) if data else None
    
    async def delete(self, session_id: str) -> None:
        await self._redis.delete(f"session:{session_id}")
```

## 2. CSRF Protection

```python
import secrets
from fastapi import Request, HTTPException

def generate_csrf_token() -> str:
    return secrets.token_urlsafe(32)

async def validate_csrf(request: Request):
    token = request.headers.get("X-CSRF-Token")
    cookie = request.cookies.get("csrf_token")
    if not token or not cookie or token != cookie:
        raise HTTPException(status_code=403, detail="CSRF validation failed")
```

## 3. File Upload

```python
from fastapi import UploadFile, HTTPException
import aiofiles

async def save_upload(file: UploadFile, max_size: int = 10 * 1024 * 1024) -> str:
    if file.size and file.size > max_size:
        raise HTTPException(400, "File too large")
    
    allowed_types = {"image/jpeg", "image/png", "application/pdf"}
    if file.content_type not in allowed_types:
        raise HTTPException(400, "Invalid file type")
    
    ext = file.filename.rsplit(".", 1)[-1] if "." in file.filename else "bin"
    path = f"uploads/{uuid.uuid4().hex}.{ext}"
    
    async with aiofiles.open(path, "wb") as f:
        content = await file.read()
        await f.write(content)
    
    return path
```

## 4. Background Tasks

```python
from fastapi import BackgroundTasks

async def send_welcome_email(user_id: int):
    user = await get_user(user_id)
    await email_service.send(user.email, "Welcome!")

@router.post("/users")
async def create_user(data: UserCreate, background_tasks: BackgroundTasks):
    user = await user_service.create(data)
    background_tasks.add_task(send_welcome_email, user.id)
    return user
```

## 5. WebSocket

```python
from fastapi import WebSocket, WebSocketDisconnect

class ConnectionManager:
    def __init__(self):
        self.active: dict[str, WebSocket] = {}
    
    async def connect(self, user_id: str, ws: WebSocket):
        await ws.accept()
        self.active[user_id] = ws
    
    def disconnect(self, user_id: str):
        self.active.pop(user_id, None)
    
    async def send_to(self, user_id: str, message: dict):
        if ws := self.active.get(user_id):
            await ws.send_json(message)

manager = ConnectionManager()

@router.websocket("/ws/{user_id}")
async def websocket_endpoint(ws: WebSocket, user_id: str):
    await manager.connect(user_id, ws)
    try:
        while True:
            data = await ws.receive_json()
            await manager.send_to(data["target"], data)
    except WebSocketDisconnect:
        manager.disconnect(user_id)
```
