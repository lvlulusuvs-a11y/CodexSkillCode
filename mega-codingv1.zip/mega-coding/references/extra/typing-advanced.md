# Advanced Type Hints

**Продвинутые приёмы типизации в Python.**

---

## 1. TypeVar + Generic

```python
from typing import TypeVar, Generic

T = TypeVar("T")
K = TypeVar("K")
V = TypeVar("V")

class Repository(Generic[T]):
    def get(self, id: int) -> T | None: ...
    def list(self) -> list[T]: ...

# Ограниченные TypeVar
Number = TypeVar("Number", int, float, complex)
class Vector(Generic[Number]):
    def __init__(self, x: Number, y: Number) -> None: ...

# Bound (подтипы)
ModelType = TypeVar("ModelType", bound=BaseModel)
```

## 2. ParamSpec (для декораторов)

```python
from typing import ParamSpec, TypeVar
from functools import wraps

P = ParamSpec("P")
T = TypeVar("T")

def retry(max_attempts: int = 3) -> Callable[[Callable[P, Awaitable[T]]], Callable[P, Awaitable[T]]]:
    """Декоратор с сохранением сигнатуры."""
    def decorator(func: Callable[P, Awaitable[T]]) -> Callable[P, Awaitable[T]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            for _ in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except Exception:
                    pass
            raise RuntimeError
        return wrapper
    return decorator
```

## 3. TypedDict

```python
from typing import TypedDict, NotRequired

class UserDict(TypedDict):
    id: int
    name: str
    email: str
    age: NotRequired[int]  # необязательное поле

user: UserDict = {"id": 1, "name": "Alice", "email": "alice@test.com"}
```

## 4. Literal + Final

```python
from typing import Literal, Final

# Literal: конкретные значения
def set_mode(mode: Literal["read", "write", "append"]) -> None: ...

# Final: константы
MAX_RETRIES: Final = 3
DEFAULT_TIMEOUT: Final[float] = 30.0

# TypeAlias (Python 3.10+)
type JSON = dict[str, "JSON"] | list["JSON"] | str | int | float | bool | None
type Callback = Callable[..., Any]
```

## 5. Protocol (duck typing)

```python
from typing import Protocol, runtime_checkable

@runtime_checkable
class Stream(Protocol):
    def read(self, size: int) -> bytes: ...
    def write(self, data: bytes) -> int: ...

class FileStream:
    def read(self, size: int) -> bytes: ...
    def write(self, data: bytes) -> int: ...

def process(stream: Stream) -> None:  # любой объект с read/write
    data = stream.read(1024)
```
