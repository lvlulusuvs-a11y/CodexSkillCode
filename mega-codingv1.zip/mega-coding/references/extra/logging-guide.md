# Logging Guide

**Как настроить логирование в Python-проекте. От print до структурированных логов.**

---

## 1. Базовое логирование

```python
import logging

# Простая настройка
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

logger = logging.getLogger(__name__)

# Уровни: DEBUG < INFO < WARNING < ERROR < CRITICAL
logger.debug("Debug info")        # Для разработки
logger.info("User registered")    # Штатные события
logger.warning("Disk 80% full")   # Подозрительно
logger.error("DB connection failed", exc_info=True)  # Сбой
logger.critical("System halted!")  # Система падает
```

## 2. Structured Logging (JSON)

```python
import json
import logging
from datetime import datetime, timezone

class JSONFormatter(logging.Formatter):
    """Форматтер логов в JSON."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        
        if hasattr(record, "extra"):
            log_entry.update(record.extra)
        
        return json.dumps(log_entry, default=str)

# Использование
handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())
logger.addHandler(handler)

logger.info("user_action", extra={"user_id": 42, "action": "login"})
```

## 3. Логирование в файлы

```python
import logging
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler

# Ротация по размеру
file_handler = RotatingFileHandler(
    "logs/app.log",
    maxBytes=10_485_760,  # 10MB
    backupCount=5,        # 5 файлов
    encoding="utf-8",
)

# Ротация по времени
time_handler = TimedRotatingFileHandler(
    "logs/app.log",
    when="midnight",    # каждый день
    backupCount=30,     # хранить 30 дней
    encoding="utf-8",
)

logging.basicConfig(
    level=logging.INFO,
    handlers=[file_handler, logging.StreamHandler()],
)
```

## 4. Контекстное логирование

```python
import logging
from contextvars import ContextVar

request_id: ContextVar[str] = ContextVar("request_id", default="")

class ContextLogger:
    """Логгер с автоматическим добавлением контекста."""
    
    def __init__(self, name: str):
        self._logger = logging.getLogger(name)
    
    def _log(self, level: int, msg: str, **extra):
        rid = request_id.get()
        if rid:
            extra["request_id"] = rid
        self._logger.log(level, msg, extra={"extra": extra})
    
    def info(self, msg: str, **kw): self._log(logging.INFO, msg, **kw)
    def error(self, msg: str, **kw): self._log(logging.ERROR, msg, **kw)
    def warning(self, msg: str, **kw): self._log(logging.WARNING, msg, **kw)

# Middleware для установки контекста
async def logging_middleware(request, call_next):
    request_id.set(uuid.uuid4().hex[:8])
    response = await call_next(request)
    return response
```

## 5. Логирование запросов (FastAPI)

```python
import time
from fastapi import Request

@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.perf_counter()
    
    response = await call_next(request)
    
    duration = time.perf_counter() - start
    logger.info(
        "request",
        method=request.method,
        path=str(request.url),
        status=response.status_code,
        duration_ms=f"{duration*1000:.0f}",
    )
    
    return response
```

## 6. Что НЕ логировать

```python
# ❌ Никогда не логируй:
# - Пароли
# - Токены, API keys
# - Номера кредитных карт
# - Passport/SSN numbers
# - Полные email адреса (только хэш/маску)

# ✅ Маскируй чувствительные данные
def mask_email(email: str) -> str:
    local, domain = email.split("@")
    return f"{local[:2]}***@{domain}"

# ✅ Маскируй пароли
def mask_password(password: str) -> str:
    return "***" + password[-2:] if len(password) > 2 else "***"
```
