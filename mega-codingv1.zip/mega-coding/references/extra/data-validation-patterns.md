# Data Validation Patterns

**Проверенные паттерны валидации данных в Python.**

---

## 1. Pydantic Validation

```python
from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(ge=0, le=150)
    password: str = Field(min_length=8)
    password_confirm: str
    
    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if any(c in v for c in "<>\"'"):
            raise ValueError("Invalid characters in name")
        return v.strip()
    
    @model_validator(mode="after")
    def passwords_match(self) -> "UserCreate":
        if self.password != self.password_confirm:
            raise ValueError("Passwords do not match")
        return self
```

## 2. Marshmallow Validation

```python
from marshmallow import Schema, fields, validate, ValidationError, post_load

class UserSchema(Schema):
    name = fields.String(required=True, validate=validate.Length(min=1, max=100))
    email = fields.Email(required=True)
    age = fields.Integer(validate=validate.Range(min=0, max=150))
    
    @post_load
    def strip_name(self, data, **kwargs):
        data["name"] = data["name"].strip()
        return data
```

## 3. Dataclass Validation

```python
from dataclasses import dataclass, field

@dataclass
class User:
    name: str
    email: str
    age: int
    
    def __post_init__(self):
        if not self.name.strip():
            raise ValueError("Name cannot be empty")
        if "@" not in self.email:
            raise ValueError("Invalid email")
        if not 0 <= self.age <= 150:
            raise ValueError("Invalid age")
```

## 4. Type Validation

```python
from typing import get_type_hints, get_origin, get_args

def validate_types(obj):
    """Runtime type validation using type hints."""
    hints = get_type_hints(obj.__class__)
    for attr, expected_type in hints.items():
        value = getattr(obj, attr, None)
        if value is None:
            continue
        if get_origin(expected_type) is list:
            if not isinstance(value, list):
                raise TypeError(f"{attr} must be list")
        elif get_origin(expected_type) is dict:
            if not isinstance(value, dict):
                raise TypeError(f"{attr} must be dict")
        elif not isinstance(value, expected_type):
            raise TypeError(f"{attr} must be {expected_type.__name__}")
```
