# Performance Tips Quick Reference

**Конкретные приёмы ускорения Python-кода. От простого к сложному.**

---

## Быстрые победы (5 минут на внедрение)

### 1. Local variable bindings
```python
# ❌ Глобальный lookup на каждой итерации
for item in items:
    process(item)

# ✅ Local reference
process_func = process  # bound once
for item in items:
    process_func(item)

# ✅ Для методов — ещё важнее
append = result.append
for item in items:
    append(item)  # вместо result.append(item)
```

### 2. Set вместо list для поиска
```python
# ❌ O(n) поиск
if x in huge_list: ...

# ✅ O(1) поиск
huge_set = set(huge_list)
if x in huge_set: ...
```

### 3. Join вместо конкатенации
```python
# ❌ O(n²) — создаёт новую строку на каждую итерацию
s = ""
for part in parts:
    s += part

# ✅ O(n) — одна аллокация
s = "".join(parts)
```

### 4. Generator вместо list
```python
# ❌ list: вся память сразу
all_data = [process(x) for x in huge_data]
result = sum(all_data)

# ✅ generator: лениво
result = sum(process(x) for x in huge_data)
```

## Средние улучшения (30 минут)

### 5. Caching
```python
from functools import lru_cache

@lru_cache(maxsize=256)
def expensive_calc(x: int) -> int:
    return complex_computation(x)

# cache_clear() при необходимости
expensive_calc.cache_clear()
```

### 6. Batch processing
```python
# ❌ N запросов к БД
for item in items:
    await db.save(item)

# ✅ 1 запрос
await db.save_all(items)
```

### 7. Connection pooling
```python
engine = create_async_engine(
    DATABASE_URL,
    pool_size=10,       # 10 постоянных соединений
    pool_pre_ping=True, # проверка здоровья
)
```

## Продвинутые техники (2+ часа)

### 8. NumPy для численных данных
```python
import numpy as np

# Python loop: ~0.5s для 10M элементов
total = sum(x * x for x in range(10_000_000))

# NumPy: ~0.02s для 10M элементов
total = np.sum(np.arange(10_000_000) ** 2)
```

### 9. __slots__ для тысяч объектов
```python
class Point:
    __slots__ = ("x", "y")  # -50% памяти
    def __init__(self, x, y):
        self.x = x
        self.y = y
```

### 10. Правильный алгоритм
```python
# ❌ O(n²) — пузырьковая сортировка
for i in range(len(items)):
    for j in range(i, len(items)):
        if items[i] > items[j]:
            items[i], items[j] = items[j], items[i]

# ✅ O(n log n) — встроенная
items.sort()

# ❌ O(n²) — ручной поиск
def find(items, target):
    for i, item in enumerate(items):
        if item == target:
            return i
    return -1

# ✅ O(log n) — бинарный поиск
import bisect
idx = bisect.bisect_left(sorted_items, target)
```

## Инструменты профилирования

```bash
# CPU
python -m cProfile -s time my_script.py | head -20  # встроенный
pip install py-spy && py-spy record -o profile.svg -- python my_script.py  # flamegraph

# Memory
pip install memory_profiler
python -m memory_profiler my_script.py

# Line-by-line
pip install line_profiler
kernprof -l -v my_script.py  # требует @profile декоратор
```

## Шпаргалка: что оптимизировать

| Симптом | Причина | Решение |
|---------|---------|---------|
| Долгий цикл с dot | Global lookup | Local reference |
| Много аллокаций строк | String += | join() |
| Много аллокаций list | Comprehension | Generator |
| Большой список поиск | O(n) в list | set / dict |
| Много объектов | __dict__ | __slots__ |
| Много запросов к БД | N+1 | batch / join |
| Медленный map/sort | Python loop | NumPy / builtins |
| Cache miss | Без кэша | lru_cache / Redis |
| CPU 100% в 1 ядре | GIL | multiprocessing / numba |
| Память растёт | Циклы ссылок | weakref / gc |
