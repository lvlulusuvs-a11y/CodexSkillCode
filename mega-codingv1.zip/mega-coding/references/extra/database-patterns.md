# Database Patterns

**Проверенные паттерны работы с БД в Python.**

---

## 1. Connection Management

```python
# Connection pool (обязательно)
from sqlalchemy.ext.asyncio import create_async_engine

engine = create_async_engine(
    DATABASE_URL,
    pool_size=10,           # постоянные соединения
    max_overflow=20,        # доп. при пике
    pool_pre_ping=True,     # проверка здоровья
    pool_recycle=3600,      # пересоздавать каждый час
    echo=False,             # SQL логи в dev
)
```

## 2. Repository Pattern

```python
from typing import Any, TypeVar, Generic

T = TypeVar("T")

class BaseRepository(Generic[T]):
    """CRUD с типизацией."""
    
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
    
    async def get(self, id: Any) -> T | None:
        return await self._session.get(self._model, id)
    
    async def list(self, skip: int = 0, limit: int = 100) -> Sequence[T]:
        stmt = select(self._model).offset(skip).limit(limit)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def add(self, entity: T) -> T:
        self._session.add(entity)
        await self._session.flush()
        return entity
    
    async def delete(self, entity: T) -> None:
        await self._session.delete(entity)
        await self._session.flush()
```

## 3. Unit of Work (Transaction)

```python
from contextlib import asynccontextmanager

class UnitOfWork:
    """Управление транзакциями."""
    
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
    
    @asynccontextmanager
    async def __call__(self) -> AsyncIterator[AsyncSession]:
        try:
            async with self._session.begin():
                yield self._session
        except Exception:
            await self._session.rollback()
            raise
```

## 4. Cursor Pagination

```python
# Для таблиц >100K записей — cursor, не offset
async def list_users(cursor: str | None = None, limit: int = 100) -> dict:
    stmt = select(User).order_by(User.id).limit(limit + 1)
    
    if cursor:
        stmt = stmt.where(User.id > cursor)
    
    result = await session.execute(stmt)
    users = result.scalars().all()
    
    has_more = len(users) > limit
    next_cursor = users[-2].id if has_more else None
    
    return {
        "data": [u.to_dict() for u in users[:limit]],
        "next_cursor": next_cursor,
        "has_more": has_more,
    }
```

## 5. N+1 Prevention

```python
# N+1: slow query
users = await db.execute(select(User))
for user in users.scalars():
    print(user.orders)  # ❌ N доп. запросов

# Fix: eager loading
from sqlalchemy.orm import selectinload

stmt = select(User).options(selectinload(User.orders))
users = await db.execute(stmt)
for user in users.scalars():
    print(user.orders)  # ✅ 1 запрос
```

## 6. Soft Delete

```python
class SoftDeleteMixin:
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    
    def soft_delete(self) -> None:
        self.is_deleted = True
        self.deleted_at = datetime.now(timezone.utc)
```

## 7. Audit Log

```python
class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), onupdate=func.now()
    )
```

## 8. Query Optimization

```python
# Только нужные поля
stmt = select(User.id, User.name, User.email)  # ❌ не select(User)

# Пагинация
stmt = stmt.limit(limit).offset(offset)

# Индексы
class User(Base):
    __tablename__ = "users"
    __table_args__ = (
        Index("ix_users_email", "email"),  # для поиска по email
        Index("ix_users_created", "created_at"),  # для сортировки
    )
```

## 9. Read Replicas

```python
# Разделение чтения и записи
writer = create_async_engine(PRIMARY_URL)
reader = create_async_engine(REPLICA_URL)

class Router(Session):
    def get_bind(self, *args, **kwargs):
        if self._flushing or self.info.get("write"):
            return writer.sync_engine
        return reader.sync_engine
```
