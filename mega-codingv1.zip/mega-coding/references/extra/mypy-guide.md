# Mypy Guide: Type Checking in Python

## Настройка
```toml
[tool.mypy]
strict = true
python_version = "3.12"
warn_unused_configs = true
warn_redundant_casts = true
warn_unused_ignores = true
disallow_any_unimported = true
disallow_untyped_defs = true
disallow_incomplete_defs = true
check_untyped_defs = true
no_implicit_optional = true
warn_return_any = true
warn_unreachable = true

[[tool.mypy.overrides]]
module = "tests.*"
ignore_errors = true
```

## Базовые типы
```python
from collections.abc import Sequence, Mapping, Callable
from typing import Any, TypeVar, Generic, Protocol, overload

# Вместо typing.List → list
def process(items: list[int]) -> list[str]:
    return [str(x) for x in items]

# Вместо typing.Dict → dict
def lookup(data: dict[str, int], key: str) -> int | None:
    return data.get(key)

# Callable
def run_callback(cb: Callable[[int, str], bool]) -> None:
    cb(1, "test")
```

## Generic
```python
T = TypeVar("T")

class Stack(Generic[T]):
    def __init__(self) -> None:
        self._items: list[T] = []

    def push(self, item: T) -> None:
        self._items.append(item)

    def pop(self) -> T:
        return self._items.pop()

# Использование
stack = Stack[int]()
stack.push(1)
stack.push("hello")  # mypy error!
```

## Protocol (structural typing)
```python
from typing import Protocol

class Drawable(Protocol):
    def draw(self) -> None: ...

def render(obj: Drawable) -> None:
    obj.draw()

class Circle:
    def draw(self) -> None:
        print("○")

class Square:
    def draw(self) -> None:
        print("□")

render(Circle())  # OK
render(Square())  # OK
render("hello")   # mypy error!
```

## Literal и overload
```python
from typing import Literal, overload

@overload
def parse(data: str) -> dict[str, Any]: ...
@overload
def parse(data: bytes) -> list[int]: ...
def parse(data: str | bytes) -> dict | list:
    if isinstance(data, str):
        return {"type": "str", "value": data}
    return list(data)

# Literal
def set_mode(mode: Literal["read", "write", "append"]) -> None:
    print(f"Mode: {mode}")

set_mode("read")    # OK
set_mode("delete")  # mypy error!
```

## Type narrowing
```python
def process(value: str | int | None) -> str:
    if value is None:
        return "empty"
    if isinstance(value, int):
        return f"number: {value}"
    return f"string: {value}"

# TypeGuard
from typing import TypeGuard

def is_str_list(items: list[Any]) -> TypeGuard[list[str]]:
    return all(isinstance(i, str) for i in items)

def handle(items: list[Any]) -> None:
    if is_str_list(items):
        print(" ".join(items))  # mypy знает что это list[str]
```
