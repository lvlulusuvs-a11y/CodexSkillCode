# SQLAlchemy 2.0 Patterns

**Проверенные паттерны работы с SQLAlchemy 2.0 async. Реальные продакшен-приёмы.**

---

## 1. Engine + Session (asyncio)

```python
from sqlalchemy.ext.asyncio import (
    create_async_engine, 
    AsyncSession, 
    async_sessionmaker,
)

# Engine — один на весь проект
engine = create_async_engine(
    "postgresql+asyncpg://user:pass@localhost:5432/db",
    pool_size=10,           # постоянных соединений
    max_overflow=20,        # доп. при нагрузке
    pool_pre_ping=True,     # проверка здоровья
    echo=False,             # SQL логи (только dev)
)

# SessionFactory — один на весь проект
AsyncSessionLocal = async_sessionmaker(
    engine,
    expire_on_commit=False,  # доступ к объектам после commit
    class_=AsyncSession,
)
```

## 2. Repository Pattern

```python
from collections.abc import Sequence
from typing import Any, TypeVar

T = TypeVar("T")

class BaseRepository(Generic[T]):
    """Базовый репозиторий с CRUD."""
    
    def __init__(self, session: AsyncSession) -> None:
        self._session = session
    
    async def get(self, id: Any) -> T | None:
        return await self._session.get(self._model, id)
    
    async def list(self, skip: int = 0, limit: int = 100) -> Sequence[T]:
        stmt = select(self._model).offset(skip).limit(limit)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def add(self, entity: T) -> T:
        self._session.add(entity)
        await self._session.flush()
        return entity
    
    async def delete(self, entity: T) -> None:
        await self._session.delete(entity)
        await self._session.flush()

# Конкретный репозиторий
class UserRepository(BaseRepository[User]):
    _model = User
    
    async def get_by_email(self, email: str) -> User | None:
        stmt = select(User).where(User.email == email)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
    
    async def get_active(self, limit: int = 100) -> Sequence[User]:
        stmt = select(User).where(User.is_active == True).limit(limit)
        result = await self._session.execute(stmt)
        return result.scalars().all()
    
    async def count_active(self) -> int:
        stmt = select(func.count(User.id)).where(User.is_active == True)
        result = await self._session.execute(stmt)
        return result.scalar() or 0
```

## 3. Unit of Work (Transaction Management)

```python
from contextlib import asynccontextmanager

class UnitOfWork:
    """Управление транзакциями с DI."""
    
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._factory = session_factory
    
    @asynccontextmanager
    async def __call__(self) -> AsyncIterator[AsyncSession]:
        async with self._factory() as session:
            try:
                async with session.begin():
                    yield session
                # session.commit() вызывается автоматически при выходе из session.begin()
            except Exception:
                # session.rollback() вызывается автоматически
                raise

# Использование:
uow = UnitOfWork(AsyncSessionLocal)

@asynccontextmanager
async def get_db() -> AsyncIterator[AsyncSession]:
    """Dependency injection для FastAPI."""
    async with uow() as session:
        yield session
```

## 4. Pagination (Cursor vs Offset)

```python
# Offset пагинация (простая)
@app.get("/users")
async def list_users(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
) -> list[User]:
    stmt = select(User).offset(skip).limit(limit).order_by(User.id)
    result = await db.execute(stmt)
    return result.scalars().all()

# Cursor пагинация (для больших таблиц)
@app.get("/users/cursor")
async def list_users_cursor(
    cursor: int | None = None,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
) -> dict:
    stmt = select(User)
    if cursor:
        stmt = stmt.where(User.id > cursor)
    stmt = stmt.order_by(User.id).limit(limit + 1)
    
    result = await db.execute(stmt)
    users = result.scalars().all()
    
    has_more = len(users) > limit
    next_cursor = users[-2].id if has_more else None
    
    return {
        "data": users[:limit],
        "next_cursor": next_cursor,
        "has_more": has_more,
    }
```

## 5. Eager Loading (N+1 prevention)

```python
from sqlalchemy.orm import selectinload, joinedload

# ❌ N+1: для каждого user отдельный запрос к orders
users = await db.execute(select(User))
for user in users.scalars():
    print(user.orders)  # N дополнительных запросов

# ✅ selectinload: один запрос на всех
stmt = select(User).options(selectinload(User.orders))
users = await db.execute(stmt)
for user in users.scalars():
    print(user.orders)  # нет доп. запросов

# joinedload: JOIN в одном запросе (для многих-к-одному)
stmt = select(Order).options(joinedload(Order.user))
orders = await db.execute(stmt)
for order in orders.scalars():
    print(order.user.name)  # уже загружен
```

## 6. Soft Delete

```python
from sqlalchemy import event

class SoftDeleteMixin:
    """Mixin для soft delete (логическое удаление)."""
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    
    def soft_delete(self) -> None:
        self.is_deleted = True
        self.deleted_at = datetime.now(timezone.utc)

class User(Base, SoftDeleteMixin):
    __tablename__ = "users"
    __table_args__ = (
        Index("ix_users_not_deleted", "is_deleted", postgresql_where=not_(text("is_deleted"))),
    )

# Фильтр по умолчанию
@event.listens_for(select(User), "before_compile", retval=True)
def _add_filter(query: Any) -> Any:
    # Автоматически добавлять WHERE NOT is_deleted
    for desc in query.column_descriptions:
        entity = desc["entity"]
        if hasattr(entity, "is_deleted"):
            query = query.where(entity.is_deleted == False)
    return query
```

## 7. Audit Log (CUD события)

```python
class Auditable:
    """Mixin для аудита изменений."""
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), 
        server_default=func.now(),
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        onupdate=func.now(),
    )
    created_by: Mapped[int | None] = mapped_column(Integer, nullable=True)
    updated_by: Mapped[int | None] = mapped_column(Integer, nullable=True)

class Product(Base, Auditable):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str]
    price: Mapped[float]
```

## 8. JSON/JSONB fields

```python
# PostgreSQL JSONB (с индексами)
class Event(Base):
    __tablename__ = "events"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[str]
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)
    metadata: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    
    __table_args__ = (
        Index("ix_events_payload", payload, postgresql_using="gin"),
    )

# Запросы к JSONB
stmt = select(Event).where(Event.payload["user_id"].as_integer() == 42)
stmt = select(Event).where(Event.payload.has_key("email"))
```

## 9. Database migrations (Alembic)

```python
# alembic init migrations
# alembic revision --autogenerate -m "add users"
# alembic upgrade head

# Важные команды:
# alembic history        — история миграций
# alembic current        — текущая версия
# alembic downgrade -1   — откатить на 1 шаг
# alembic merge heads    — слить конфликтующие миграции
```

## 10. Async Session Mixin

```python
class AsyncSessionMixin:
    """Упрощает работу с async session в тестах."""
    
    @pytest_asyncio.fixture
    async def db_session(self) -> AsyncIterator[AsyncSession]:
        engine = create_async_engine("sqlite+aiosqlite://")
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        
        async with AsyncSession(engine, expire_on_commit=False) as session:
            yield session
        
        await engine.dispose()
    
    @pytest_asyncio.fixture
    async def user_repo(self, db_session) -> UserRepository:
        return UserRepository(db_session)
```
