# REST API Design

**Правила и паттерны проектирования REST API.**

---

## 1. Resource Naming

```python
# ✅ Правильно
GET    /users                    # список
POST   /users                    # создать
GET    /users/{id}               # один
PUT    /users/{id}               # заменить
PATCH  /users/{id}               # частично обновить
DELETE /users/{id}               # удалить

# Вложенные ресурсы
GET    /users/{id}/orders        # заказы пользователя
GET    /users/{id}/orders/{oid}  # конкретный заказ

# ❌ Неправильно
GET    /getUsers                 # глагол
POST   /createUser               # глагол
GET    /users/list               / избыточно
GET    /user                     # единственное число
```

## 2. Status Codes

```python
# 2xx — Успех
200 OK          # GET, PUT, PATCH
201 Created     # POST
202 Accepted    # Асинхронная операция
204 No Content  # DELETE

# 3xx — Перенаправление
301 Moved Permanently
302 Found (temporary)
304 Not Modified (кэш)

# 4xx — Ошибка клиента
400 Bad Request      # невалидный JSON
401 Unauthorized     # не аутентифицирован
403 Forbidden        # нет прав
404 Not Found        # ресурс не найден
409 Conflict         # конфликт (дубликат)
422 Unprocessable    # валидация не прошла
429 Too Many         # rate limit

# 5xx — Ошибка сервера
500 Internal Server Error
502 Bad Gateway
503 Service Unavailable
504 Gateway Timeout
```

## 3. Pagination

```python
# Offset-based
GET /users?skip=0&limit=100
Response:
{
    "data": [...],
    "total": 1000,
    "skip": 0,
    "limit": 100
}

# Cursor-based (для больших таблиц)
GET /users?cursor=abc123&limit=100
Response:
{
    "data": [...],
    "next_cursor": "xyz789",
    "has_more": true
}
```

## 4. Filtering, Sorting, Searching

```python
GET /users?status=active&role=admin          # фильтрация
GET /users?sort=-created_at                  # сортировка (- = desc)
GET /users?fields=id,name,email              # выбор полей
GET /users?search=alice                      # поиск
GET /users?created_at[gte]=2024-01-01        # диапазон
```

## 5. Error Response Format

```python
# Стандартный формат (RFC 7807 Problem Details)
{
    "type": "https://api.example.com/errors/user-not-found",
    "title": "User Not Found",
    "status": 404,
    "detail": "User with id 42 not found",
    "instance": "/users/42",
    "errors": {
        "user_id": ["User 42 not found"]
    }
}

# Pydantic schema
class ErrorResponse(BaseModel):
    type: str = "about:blank"
    title: str
    status: int
    detail: str
    instance: str = ""
    errors: dict[str, list[str]] = {}
```

## 6. Versioning

```python
# Через URL (проще)
GET /api/v1/users

# Через заголовок (чище)
GET /users
Accept: application/vnd.myapp.v1+json
```

## 7. Idempotency

```python
# POST /payments — идемпотентность через Idempotency-Key
@router.post("/payments")
async def create_payment(
    data: PaymentCreate,
    request: Request,
    idempotency_key: str = Header(None),
):
    if not idempotency_key:
        raise HTTPException(400, "Idempotency-Key required")
    
    # Проверяем, не было ли уже
    if existing := await redis.get(f"idempotency:{idempotency_key}"):
        return json.loads(existing)
    
    # Выполняем
    result = await payment_service.charge(data)
    
    # Сохраняем результат
    await redis.setex(f"idempotency:{idempotency_key}", 86400, json.dumps(result))
    
    return result
```

## 8. HATEOAS (Hypermedia)

```python
# Ответ содержит ссылки на связанные ресурсы
{
    "id": 1,
    "name": "Alice",
    "_links": {
        "self": {"href": "/users/1"},
        "orders": {"href": "/users/1/orders"},
        "profile": {"href": "/users/1/profile"}
    }
}
```
