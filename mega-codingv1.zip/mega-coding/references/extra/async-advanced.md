# Advanced Async/Await Patterns

**Продвинутые паттерны asyncio для продакшена. Не туториал — реальные приёмы.**

---

## 1. Async Context Manager с таймаутом

```python
from contextlib import asynccontextmanager
from typing import AsyncIterator

@asynccontextmanager
async def timeout_context(timeout: float) -> AsyncIterator[None]:
    """Контекстный менеджер с таймаутом."""
    try:
        async with asyncio.timeout(timeout):
            yield
    except TimeoutError:
        logger.warning("Operation timed out after %.2fs", timeout)
        raise

# Использование
async with timeout_context(5.0):
    result = await slow_operation()
```

## 2. Async Pool (Worker Pool)

```python
class AsyncPool:
    """Пул воркеров для параллельной обработки."""
    
    def __init__(self, workers: int = 10):
        self._workers = workers
        self._queue: asyncio.Queue[tuple[int, Callable]] = asyncio.Queue()
        self._results: dict[int, Any] = {}
    
    async def run(self, tasks: list[Callable]) -> list[Any]:
        """Запустить задачи параллельно."""
        n = len(tasks)
        for i, task in enumerate(tasks):
            await self._queue.put((i, task))
        
        workers = [asyncio.create_task(self._worker()) for _ in range(min(self._workers, n))]
        await self._queue.join()
        
        for w in workers:
            w.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        
        return [self._results[i] for i in range(n)]
    
    async def _worker(self) -> None:
        while True:
            try:
                idx, task = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                self._results[idx] = await task()
                self._queue.task_done()
            except TimeoutError:
                break
            except Exception as e:
                self._results[idx] = e
                self._queue.task_done()
```

## 3. Async Iterator с backpressure

```python
class AsyncPaginatedIterator:
    """Асинхронный итератор с контролем скорости."""
    
    def __init__(self, fetcher: Callable, page_size: int = 100, max_concurrent: int = 3):
        self._fetcher = fetcher
        self._page_size = page_size
        self._sem = asyncio.Semaphore(max_concurrent)
        self._buffer: asyncio.Queue = asyncio.Queue(maxsize=max_concurrent * page_size)
        self._done = False
    
    async def __aiter__(self) -> AsyncIterator:
        return self
    
    async def __anext__(self) -> Any:
        if self._buffer.empty() and not self._done:
            await self._fill_buffer()
        
        try:
            return await asyncio.wait_for(self._buffer.get(), timeout=30.0)
        except TimeoutError:
            raise StopAsyncIteration
    
    async def _fill_buffer(self) -> None:
        """Prefetch следующих страниц."""
        async def fetch_page(page: int) -> None:
            async with self._sem:
                items = await self._fetcher(page=page, size=self._page_size)
                for item in items:
                    await self._buffer.put(item)
        
        tasks = [fetch_page(i) for i in range(1, 4)]
        await asyncio.gather(*tasks, return_exceptions=True)
```

## 4. Async Lock with Priority

```python
class PriorityLock:
    """Асинхронный lock с поддержкой приоритетов."""
    
    def __init__(self) -> None:
        self._locked = False
        self._waiters: dict[int, list[asyncio.Future]] = {0: [], 1: [], 2: []}  # low, normal, high
    
    async def acquire(self, priority: int = 1) -> asyncio.Lock:
        if not self._locked:
            self._locked = True
            return
        
        fut = asyncio.get_event_loop().create_future()
        self._waiters.setdefault(priority, []).append(fut)
        await fut
    
    def release(self) -> None:
        if not self._locked:
            raise RuntimeError("Lock not held")
        
        # Отдаём ожидающим с наивысшим приоритетом
        for priority in (2, 1, 0):  # high → normal → low
            if self._waiters[priority]:
                waiter = self._waiters[priority].pop(0)
                waiter.set_result(True)
                return
        
        self._locked = False
    
    async def __aenter__(self) -> "PriorityLock":
        await self.acquire()
        return self
    
    async def __aexit__(self, *args: Any) -> None:
        self.release()
```

## 5. Async Event Emitter

```python
class AsyncEventEmitter:
    """Шина событий с асинхронными подписчиками."""
    
    def __init__(self) -> None:
        self._handlers: dict[str, list[Callable]] = {}
    
    def on(self, event: str, handler: Callable) -> None:
        self._handlers.setdefault(event, []).append(handler)
    
    def off(self, event: str, handler: Callable) -> None:
        if handlers := self._handlers.get(event):
            handlers.remove(handler)
    
    async def emit(self, event: str, *args: Any, **kwargs: Any) -> list[Any]:
        """Отправить событие и дождаться всех обработчиков."""
        results: list[Any] = []
        for handler in self._handlers.get(event, []):
            try:
                if asyncio.iscoroutinefunction(handler):
                    result = await handler(*args, **kwargs)
                else:
                    result = handler(*args, **kwargs)
                results.append(result)
            except Exception as e:
                logger.exception("Handler failed for %s: %s", event, e)
                results.append(e)
        return results
```

## 6. Async Queue with Priority and TTL

```python
@dataclass(order=True)
class PrioritizedItem:
    priority: int
    ttl: float
    created_at: float = field(default_factory=time.monotonic)
    data: Any = field(compare=False)
    
    @property
    def expired(self) -> bool:
        return time.monotonic() - self.created_at > self.ttl

class PriorityQueue:
    """Очередь с приоритетом и TTL."""
    
    def __init__(self, maxsize: int = 0) -> None:
        self._heap: list[PrioritizedItem] = []
        self._maxsize = maxsize
        self._event = asyncio.Event()
    
    async def put(self, item: Any, priority: int = 0, ttl: float = 300.0) -> None:
        if self._maxsize and len(self._heap) >= self._maxsize:
            raise asyncio.QueueFull
        
        heapq.heappush(self._heap, PrioritizedItem(priority=priority, ttl=ttl, data=item))
        self._event.set()
    
    async def get(self) -> Any:
        while True:
            # Очистить просроченные
            while self._heap and self._heap[0].expired:
                heapq.heappop(self._heap)
            
            if self._heap:
                return heapq.heappop(self._heap).data
            
            self._event.clear()
            await self._event.wait()
    
    def qsize(self) -> int:
        # Очистить просроченные перед подсчётом
        while self._heap and self._heap[0].expired:
            heapq.heappop(self._heap)
        return len(self._heap)
```

## 7. Coroutine Supervisor (супервизор для фоновых задач)

```python
class Supervisor:
    """Супервизор фоновых задач: автоперезапуск, мониторинг."""
    
    def __init__(self) -> None:
        self._tasks: dict[str, asyncio.Task] = {}
        self._restart_counts: dict[str, int] = {}
        self._max_restarts = 5
    
    async def supervise(self, name: str, coro: Callable, *args: Any, **kwargs: Any) -> None:
        """Запустить задачу под супервизором."""
        if name in self._tasks and not self._tasks[name].done():
            logger.warning("Task %s already running", name)
            return
        
        while self._restart_counts.get(name, 0) < self._max_restarts:
            try:
                self._tasks[name] = asyncio.create_task(coro(*args, **kwargs), name=name)
                await self._tasks[name]
                break  # Завершилась успешно
            except asyncio.CancelledError:
                logger.info("Task %s cancelled", name)
                break
            except Exception as e:
                self._restart_counts[name] = self._restart_counts.get(name, 0) + 1
                delay = min(2 ** self._restart_counts[name], 60)  # exponential backoff
                logger.error("Task %s failed (attempt %d): %s. Restart in %ds",
                           name, self._restart_counts[name], e, delay)
                await asyncio.sleep(delay)
        
        if self._restart_counts.get(name, 0) >= self._max_restarts:
            logger.critical("Task %s exceeded max restarts", name)
    
    async def cancel(self, name: str) -> None:
        if task := self._tasks.get(name):
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
    
    async def cancel_all(self) -> None:
        for name in list(self._tasks):
            await self.cancel(name)
```

## 8. Async Barrier (синхронизация N задач)

```python
class AsyncBarrier:
    """Барьер: ждёт, пока N задач не достигнут точки синхронизации."""
    
    def __init__(self, n: int) -> None:
        self._n = n
        self._count = 0
        self._event = asyncio.Event()
    
    async def wait(self) -> None:
        self._count += 1
        if self._count >= self._n:
            self._event.set()
        await self._event.wait()
```

## 9. Async Retry с джиттером

```python
import random

async def retry_with_jitter(
    func: Callable,
    max_attempts: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    jitter: float = 0.1,
) -> Any:
    """Retry с экспоненциальным backoff и jitter (случайная задержка)."""
    for attempt in range(max_attempts):
        try:
            return await func()
        except (ConnectionError, TimeoutError, aiohttp.ClientError) as e:
            if attempt == max_attempts - 1:
                raise
            
            delay = min(base_delay * (2 ** attempt), max_delay)
            delay += random.uniform(0, delay * jitter)  # jitter: ±10%
            
            logger.warning("Attempt %d failed: %s. Retry in %.2fs", attempt + 1, e, delay)
            await asyncio.sleep(delay)
```

## 10. Async Semaphore with Timeout

```python
class TimedSemaphore:
    """Семафор с таймаутом на ожидание."""
    
    def __init__(self, value: int = 1) -> None:
        self._sem = asyncio.Semaphore(value)
    
    async def acquire(self, timeout: float = 5.0) -> bool:
        """Попробовать захватить семафор с таймаутом."""
        try:
            await asyncio.wait_for(self._sem.acquire(), timeout=timeout)
            return True
        except TimeoutError:
            return False
    
    def release(self) -> None:
        self._sem.release()
    
    async def __aenter__(self) -> bool:
        return await self.acquire()
    
    async def __aexit__(self, *args: Any) -> None:
        self.release()
```
