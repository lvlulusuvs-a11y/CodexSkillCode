# Task Scheduling Patterns

**Паттерны планирования задач в Python.**

---

## 1. APScheduler Basic

```python
from apscheduler.schedulers.asyncio import AsyncIOScheduler

scheduler = AsyncIOScheduler()

@scheduler.scheduled_job("interval", minutes=30)
async def check_health():
    """Check system health every 30 minutes."""
    await health_check()

@scheduler.scheduled_job("cron", hour=3, minute=0)
async def nightly_report():
    """Generate report at 3 AM."""
    await generate_report()

@scheduler.scheduled_job("date", run_date="2024-12-31 23:59:00")
async def new_year():
    """Run once on specific date."""
    await celebrate()

scheduler.start()

# Graceful shutdown
import atexit
atexit.register(lambda: scheduler.shutdown(wait=False))
```

## 2. Schedule Library

```python
import schedule
import time

def job():
    print("Running job...")

schedule.every(10).minutes.do(job)
schedule.every().hour.do(job)
schedule.every().day.at("10:30").do(job)
schedule.every().monday.do(job)
schedule.every().wednesday.at("13:15").do(job)

while True:
    schedule.run_pending()
    time.sleep(1)
```

## 3. Celery Periodic Tasks

```python
from celery import Celery
from celery.schedules import crontab

app = Celery("tasks", broker="redis://localhost:6379/0")

@app.task
def send_newsletter():
    """Weekly newsletter."""
    pass

@app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(3600, send_healthcheck.s(), name="hourly health")
    sender.add_periodic_task(
        crontab(hour=7, minute=30, day_of_week=1),
        send_weekly_report.s(),
        name="weekly report",
    )
```
