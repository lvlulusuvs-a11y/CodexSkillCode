# Python patterns

## Структура модуля
```python
"""Module docstring."""

from __future__ import annotations

import logging
from typing import override

logger = logging.getLogger(__name__)


class MyClass:
    """Public class."""
    ...
```

## Обработка ошибок
```python
class AppError(Exception):
    """Base exception for the app."""

class NotFoundError(AppError):
    """Resource not found."""

def get_user(user_id: int) -> User:
    if not (user := db.query(User).get(user_id)):
        raise NotFoundError(f"User {user_id} not found")
    return user
```

## Тесты с pytest
```python
import pytest
from unittest.mock import Mock

def test_something():
    result = my_func("input")
    assert result == "expected"
    assert mock_dep.call_count == 1
```

## CLI с argparse
```python
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("file", help="Input file")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()
    ...
```
