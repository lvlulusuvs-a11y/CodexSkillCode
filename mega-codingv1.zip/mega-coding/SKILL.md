# 🚀 Mega-Coding

**Кодируй как senior. Быстро, чисто, надёжно.**

## ⚡ Speed Mode

### Задача → Действие → Бойлерплейт

| Ситуация | Что делать | Шаблон |
|----------|-----------|--------|
| **Новый проект** | `scripts/codex-project-init.py` или ручной шаблон | `templates/` или `assets/boilerplate-*` |
| **Новая фича** | Понять → Найти похожий паттерн → Написать тест → Код | Копировать стиль проекта |
| **Баг** | `git log -S "функция"` → `git blame` → тест, воспроизводящий баг → фикс | Сначала тест, потом код |
| **Рефакторинг** | Изолировать → Тесты → Маленькие шаги → `git diff` после каждого | `references/extra/refactoring-recipes.md` |
| **Оптимизация** | Профилировать (`cProfile` / `py-spy`) → Измерить → Оптимизировать узкое место | `references/extra/performance-patterns.md` |

### Принцип трёх касаний
1. **Понять** — `rg`, `fd`, `git log`, `git blame` (макс 30с)
2. **Спроектировать** — 1 мысль: простота > читаемость > производительность (макс 10с)  
3. **Написать** — тест → код → прогнать тесты (макс 5 мин на функцию)

### Что писать сразу (без раздумий)

```python
# Импорты: stdlib → third-party → local
from __future__ import annotations
import logging
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Self

logger = logging.getLogger(__name__)
```

## 🧠 Senior-Level Principles

### Критерии хорошего кода (в порядке важности)
1. **Работает** — решает задачу без багов
2. **Читается** — через месяц ты или другой разработчик поймёт за 5 секунд
3. **Меняется** — добавить новое поведение без переписывания всего
4. **Производителен** — достаточно быстро для задачи (не быстрее)

### Когда нарушать правила
- **DRY**: нарушить, когда абстракция сложнее дублирования (правило трёх)
- **SOLID**: ISP и DIP — всегда; SRP и OCP — часто; LSP — редко, только для иерархий
- **YAGNI**: отличное правило — не писать код, который не нужен сейчас
- **Type hints**: не обязательно для внутренних функций/скриптов, обязательно для публичного API

### Что senior-разработчик знает, а junior — нет
- **Fail fast** — упади сразу с понятной ошибкой, а не в трёх стеках от причины
- **Parse, don't validate** — превращай сырые данные в типы на границе системы
- **Make illegal states unrepresentable** — используй типы, чтобы невозможные состояния были невозможны
- **Tell, don't ask** — объект сам решает, что делать со своими данными
- **Law of Demeter** — не разговаривай с незнакомцами (`a.b.c.d` — запах)
- **Command-Query Separation** — функция либо делает (команда), либо отвечает (запрос), но не оба
- **Robustness Principle** — будь либерален в том, что принимаешь, и консервативен в том, что отдаёшь

### Пирамида решений

```
СЛОЖНОСТЬ →
  │
  ├─ Простая логика → if/elif/else, match/case, comprehension  
  ├─ Средняя → Strategy, Factory, Builder, Adapter
  ├─ Сложная → Композиция сервисов, CQRS, Event Sourcing
  └─ Очень сложная → Модули, плагины, message queue
```

Не усложняй: простое решение для простой задачи > "правильное" решение для воображаемой сложности.

## 🏗 Production Patterns (Python)

### Dataclass + Validation

```python
from dataclasses import dataclass
from typing import Self

@dataclass(frozen=True, slots=True)
class User:
    id: int
    name: str
    email: str
    
    def __post_init__(self: Self) -> None:
        if not self.name.strip():
            raise ValueError("name must not be empty")
        if "@" not in self.email:
            raise ValueError(f"invalid email: {self.email}")
```

### Result Type (вместо исключений для ожидаемых ошибок)

```python
from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")
E = TypeVar("E")

@dataclass(frozen=True)
class Ok(Generic[T]):
    value: T

@dataclass(frozen=True)  
class Err(Generic[E]):
    error: E

type Result[T, E] = Ok[T] | Err[E]

# Использование
def divide(a: int, b: int) -> Result[float, str]:
    if b == 0:
        return Err("division by zero")
    return Ok(a / b)

match divide(10, 0):
    case Ok(value): print(value)
    case Err(error): print(f"Error: {error}")
```

### Repository Pattern (БД)

```python
from collections.abc import Sequence
from dataclasses import dataclass, field

@dataclass
class UserRepository:
    _db: Any = field(repr=False)
    
    async def get_by_id(self, user_id: int) -> User | None: ...
    async def get_by_email(self, email: str) -> User | None: ...
    async def list_active(self, limit: int = 100) -> Sequence[User]: ...
    async def save(self, user: User) -> User: ...
    async def delete(self, user_id: int) -> bool: ...
```

### Dependency Injection (простой DI)

```python
from functools import lru_cache

@lru_cache
def get_db() -> Database:
    return Database(url=settings.db_url)

@lru_cache
def get_user_repo() -> UserRepository:
    return UserRepository(db=get_db())

# В хендлерах/контроллерах:
user_repo = get_user_repo()
```

### Middleware Pattern

```python
from collections.abc import Callable, Awaitable
from typing import Any

Handler = Callable[..., Awaitable[Any]]
Middleware = Callable[[Handler], Handler]

def chain(middlewares: list[Middleware], handler: Handler) -> Handler:
    for m in reversed(middlewares):
        handler = m(handler)
    return handler

# Пример middleware
def logging_middleware(next_handler: Handler) -> Handler:
    async def wrapped(*args: Any, **kwargs: Any) -> Any:
        logger.debug("before: %s", args)
        try:
            result = await next_handler(*args, **kwargs)
            logger.debug("after: success")
            return result
        except Exception as e:
            logger.error("error: %s", e)
            raise
    return wrapped
```

### Async Worker

```python
import asyncio
from collections.abc import Callable, Coroutine
from typing import Any

WorkerTask = Callable[[Any], Coroutine[None, None, None]]

class WorkerPool:
    def __init__(self, workers: int = 4) -> None:
        self._workers = workers
        self._queue: asyncio.Queue[Any] = asyncio.Queue()
    
    async def start(self, handler: WorkerTask) -> None:
        async with asyncio.TaskGroup() as tg:
            for _ in range(self._workers):
                tg.create_task(self._run(handler))
    
    async def _run(self, handler: WorkerTask) -> None:
        while task := await self._queue.get():
            await handler(task)
            self._queue.task_done()
    
    async def push(self, task: Any) -> None:
        await self._queue.put(task)
```

## 🔍 Быстрые решения для частых задач

### REST API (FastAPI)
```python
# router → service → repository
from fastapi import APIRouter, Depends, HTTPException, status

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/{user_id}")
async def get_user(
    user_id: int,
    repo: UserRepository = Depends(get_user_repo),
) -> User:
    if user := await repo.get_by_id(user_id):
        return user
    raise HTTPException(status_code=404, detail="User not found")
```

### CLI (argparse)
```python
import argparse, sys
from pathlib import Path

def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="...")
    parser.add_argument("input", type=Path, help="Input file")
    parser.add_argument("--output", "-o", type=Path, default=None)
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args(argv)
    
    if not args.input.exists():
        parser.error(f"File not found: {args.input}")
    
    result = process(args.input)
    output = args.output or Path("output.txt")
    output.write_text(result)

if __name__ == "__main__":
    main()
```

### Telegram Bot (aiogram 3)
```python
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import Message
from aiogram.filters import Command

router = Router()

@router.message(Command("start"))
async def cmd_start(msg: Message) -> None:
    await msg.answer(f"Привет, {msg.from_user.first_name}!")

@router.message(F.text)
async def echo(msg: Message) -> None:
    await msg.answer(msg.text)

async def main() -> None:
    bot = Bot(token="TOKEN")
    dp = Dispatcher()
    dp.include_router(router)
    await dp.start_polling(bot)
```

### Database (SQLAlchemy 2.0)
```python
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

async def get_active_users(session: AsyncSession) -> list[User]:
    stmt = select(User).where(User.is_active == True).limit(100)
    result = await session.execute(stmt)
    return list(result.scalars().all())
```

## 🛠 Скрипты

| Команда | Что делает |
|---------|-----------|
| `python scripts/check-quality.py src/` | Полный quality check |
| `python scripts/lint-runner.py` | Ruff → mypy → bandit |
| `python scripts/benchmark.py` | Замер производительности |
| `python scripts/security-check.py` | Поиск уязвимостей |
| `python scripts/codex-project-init.py --type fastapi` | Создать проект |

## 📦 Все ресурсы скилла

### Шаблоны проектов (`templates/`)
- `fastapi/` — готовый FastAPI проект
- `cli/` — CLI-инструмент с argparse+click
- `bot/` — Telegram bot (aiogram 3)
- `lib/` — Python библиотека

### Бойлерплейты (`assets/`)
- `boilerplate-aiogram.md` — хендлеры, FSM, админка, инлайн, платежи, вебхук
- `boilerplate-fastapi.md` — CRUD, auth, pagination, middleware
- `boilerplate-cli.md` — argparse, click, typer
- `boilerplate-sqlalchemy.md` — async/синхронный SQLAlchemy 2.0
- `boilerplate-async-bot.md` — очередь, retry, rate limit
- `boilerplate-celery.md` — воркеры, планировщик, мониторинг
- `boilerplate-websocket.md` — async WebSocket сервер
- `boilerplate-pagination.md` — курсорная и offset-пагинация
- `boilerplate-middleware.md` — цепочка middleware
- `boilerplate-redis-cache.md` — кэширование через Redis
- `boilerplate-docker-compose.md` — compose для разработки
- `boilerplate-factory.md` — Factory Method и Abstract Factory
- `boilerplate-strategy.md` — Strategy Pattern
- `boilerplate-testing-async.md` — тесты асинхронного кода

### Гайды (`references/extra/`)
- `senior-dev-wisdom.md` — ★ мудрость 5-летнего опыта
- `refactoring-recipes.md` — ★ пошаговый рефакторинг
- `production-patterns.md` — ★ боевые паттерны
- `testing-strategies.md` — ★ стратегии реального тестирования
- `design-patterns-deep-dive.md` — ★ все GoF паттерны
- `system-design-reference.md` — ★ проектирование систем
- `production-python.md` — ★ Python для продакшена
- `python-developer-reference.md` — ★ полный справочник Python
- `testing-guide.md` — ★ полное руководство по тестированию
- `database-cookbook.md` — ★ рецепты SQL и БД
- `algorithms-reference.md` — ★ справочник алгоритмов
- `ci-cd-patterns.md` — ★ CI/CD и деплой
- `asyncio-deep-dive.md` — ★ asyncio в деталях
- `async-advanced.md` — ★ продвинутые async паттерны
- `speed-optimization.md` — ★ оптимизация скорости
- `python-internals.md` — ★ устройство CPython
- `data-structures-guide.md` — ★ структуры данных
- `design-patterns.md` — GoF паттерны в Python
- `idiomatic-python.md` — идиоматичный Python
- `async-patterns.md` — async/await паттерны
- `optimization-patterns.md` — оптимизация производительности
- `error-handling.md` — обработка ошибок
- `sqlalchemy-patterns.md` — SQLAlchemy 2.0
- `redis-patterns.md` — Redis паттерны
- `django-like-architecture.md` — архитектура как Django
- `monitoring-observability.md` — мониторинг
- `fastapi-best-practices.md` — FastAPI best practices
- `concurrency-patterns.md` — конкурентность
- `security-best-practices.md` — безопасность
- `api-design.md` — дизайн API
- `clean-code.md` — чистый код
- `logging-guide.md` — логирование
- `git-advanced.md` — продвинутый git
- `testing-advanced.md` — продвинутое тестирование
- `debugging-troubleshooting.md` — отладка
- `database-patterns.md` — паттерны БД
- И ещё 10+ гайдов — полный список в `references/extra/`

### Примеры (`examples/`)
- `quickstart.py` — быстрый старт
- `advanced-usage.py` — продвинутое использование
- `projects/fastapi-todo.py` — TODO на FastAPI
- `projects/cli-file-manager.py` — файловый менеджер CLI
- `projects/async-scraper.py` — асинхронный скрапер
- `projects/data-analyzer.py` — анализ данных
- `projects/config-manager.py` — менеджер конфигов
- `projects/etl-pipeline.py` — ETL пайплайн
- `projects/api-gateway.py` — API Gateway

### CI/CD (`.github/`)
- `workflows/ci.yml` — тесты на 3.10-3.12
- `workflows/lint.yml` — все линтеры
- `workflows/publish.yml` — публикация на PyPI
- `.pre-commit-config.yaml` — pre-commit хуки
- `Dockerfile` — контейнер
- `Makefile` — `install`, `test`, `lint`, `format`, `check`, `build`

## 🎯 Чеклисты

### Перед PR (30 секунд)
- [ ] `ruff check . && ruff format --check .`
- [ ] `python scripts/check-quality.py src/`
- [ ] Новые тесты проходят
- [ ] Нет `print()`, `# TODO`, хардкода
- [ ] type hints на публичных функциях
- [ ] `git diff` — только нужные изменения

### Код-ревью (60 секунд)
- [ ] Понимаю что делает — да/нет
- [ ] Есть ли баги/edge cases — да/нет
- [ ] Дублирование — да/нет
- [ ] Тесты покрывают — да/нет  
- [ ] Ошибки обработаны — да/нет
- [ ] Безопасность — да/нет
- [ ] Производительность — да/нет

## 📜 Правила для ИИ

См. `rulesAI/rulesai.txt` — Совет Деревьев: 6 аспектов проверки кода.
См. `rulesAI/rules.txt` — обязательные правила подписи.
