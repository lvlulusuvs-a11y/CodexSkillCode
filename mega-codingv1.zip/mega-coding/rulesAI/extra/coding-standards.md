# Coding Standards

## Обязательно
- `from __future__ import annotations` — во всех файлах
- Type hints для всех функций и методов
- Docstrings для публичного API
- Максимум 100 символов на строку
- Функции не длиннее 60 строк

## Запрещено
- `except:` без типа исключения
- `print()` в production-коде (кроме cli.py)
- Магические числа без константы
- Хардкоженные токены/пароли
- `eval()` / `exec()`

## Именование
- `snake_case` — функции, переменные
- `PascalCase` — классы
- `UPPER_CASE` — константы
- `_private` — приватные методы/переменные

## Импорты
```python
# Порядок:
# 1. Стандартная библиотека
# 2. Третьесторонние
# 3. Локальные

import os
import sys
from typing import NamedTuple

import pytest
from pydantic import BaseModel

from mypackage import core
```
