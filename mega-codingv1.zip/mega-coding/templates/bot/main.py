"""Aiogram 3 bot production template."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from aiogram import Bot, Dispatcher, Router, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from pydantic_settings import BaseSettings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)


# ── Config ─────────────────────────────────────
class Settings(BaseSettings):
    bot_token: str
    admin_ids: list[int] = []
    debug: bool = False

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}

settings = Settings()


# ── FSM States ─────────────────────────────────
class Form(StatesGroup):
    waiting_name = State()
    waiting_phone = State()
    waiting_email = State()


# ── Router ─────────────────────────────────────
router = Router()


# ── Commands ───────────────────────────────────
@router.message(CommandStart())
async def cmd_start(msg: Message) -> None:
    await msg.answer(
        f"👋 <b>Привет, {msg.from_user.first_name}!</b>\n\n"
        "Я шаблон aiogram 3 бота.\n"
        "Команды:\n"
        "/help — помощь\n"
        "/form — форма обратной связи\n"
        "/info — информация",
        parse_mode=ParseMode.HTML,
    )


@router.message(Command("help"))
async def cmd_help(msg: Message) -> None:
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📘 Документация", url="https://docs.aiogram.dev")],
            [InlineKeyboardButton(text="🐛 Сообщить о баге", callback_data="bug_report")],
        ]
    )
    await msg.answer("Помощь и ссылки:", reply_markup=kb)


@router.message(Command("info"))
async def cmd_info(msg: Message) -> None:
    await msg.answer(
        f"ID: <code>{msg.from_user.id}</code>\n"
        f"Username: @{msg.from_user.username or 'нет'}\n"
        f"Chat type: {msg.chat.type}",
        parse_mode=ParseMode.HTML,
    )


# ── FSM Form ───────────────────────────────────
@router.message(Command("form"))
async def cmd_form(msg: Message, state: FSMContext) -> None:
    await state.set_state(Form.waiting_name)
    await msg.answer("Как вас зовут?")


@router.message(Form.waiting_name, F.text)
async def form_name(msg: Message, state: FSMContext) -> None:
    await state.update_data(name=msg.text)
    await state.set_state(Form.waiting_phone)
    await msg.answer("Ваш номер телефона?")


@router.message(Form.waiting_phone, F.text)
async def form_phone(msg: Message, state: FSMContext) -> None:
    await state.update_data(phone=msg.text)
    await state.set_state(Form.waiting_email)
    await msg.answer("Ваш email?")


@router.message(Form.waiting_email, F.text)
async def form_email(msg: Message, state: FSMContext) -> None:
    data = await state.update_data(email=msg.text)
    await state.clear()

    user_info = (
        f"✅ <b>Форма заполнена!</b>\n"
        f"Имя: {data['name']}\n"
        f"Телефон: {data['phone']}\n"
        f"Email: {data['email']}"
    )
    await msg.answer(user_info, parse_mode=ParseMode.HTML)

    # Уведомить админов
    for admin_id in settings.admin_ids:
        try:
            await msg.bot.send_message(admin_id, f"Новая форма: {data}")
        except Exception as e:
            logger.warning("failed to notify admin %s: %s", admin_id, e)


# ── Callbacks ──────────────────────────────────
@router.callback_query(F.data == "bug_report")
async def cb_bug_report(cq: CallbackQuery) -> None:
    await cq.answer("Спасибо! Функция в разработке.", show_alert=True)


# ── Free text ──────────────────────────────────
@router.message(F.text)
async def echo(msg: Message) -> None:
    """Если не команда — эхо (или ignore в проде)."""
    await msg.answer(f"Вы написали: {msg.text}")


# ── Main ───────────────────────────────────────
async def main() -> None:
    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)

    logger.info("starting bot...")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
