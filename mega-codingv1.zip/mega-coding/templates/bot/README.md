# Telegram Bot Template (aiogram 3.x)

```
bot/
├── __init__.py
├── app.py             # dispatcher setup
├── handlers/          # message/callback handlers
├── keyboards/         # inline/reply keyboards
├── middlewares/       # throttle, auth, logging
├── states/            # FSM states
├── db/                # database layer
└── tests/
```

```python
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties

bot = Bot(token="TOKEN", default=DefaultBotProperties(parse_mode="HTML"))
dp = Dispatcher()
```
