# FastAPI Template

```
app/
├── __init__.py
├── main.py          # entry point
├── routers/         # endpoints
├── models/          # pydantic
├── services/        # business logic
├── db/              # database
└── tests/
```

```python
# main.py
from fastapi import FastAPI

app = FastAPI(title="My App", version="0.1.0")

@app.get("/health")
async def health():
    return {"status": "ok"}
```
