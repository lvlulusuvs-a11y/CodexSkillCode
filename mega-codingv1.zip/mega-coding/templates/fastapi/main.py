"""FastAPI production template."""
from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, EmailStr

# ── Models ────────────────────────────────────
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class UserCreate(BaseModel):
    name: str
    email: EmailStr


class UserResponse(BaseModel):
    id: int
    name: str
    email: str


class ErrorResponse(BaseModel):
    detail: str
    code: str | None = None


# ── Fake repo (заменить на SQLAlchemy) ──
class UserRepo:
    def __init__(self) -> None:
        self._users: dict[int, dict[str, Any]] = {}
        self._next_id = 1

    async def create(self, data: UserCreate) -> dict[str, Any]:
        user = {"id": self._next_id, "name": data.name, "email": data.email}
        self._users[self._next_id] = user
        self._next_id += 1
        return user

    async def get(self, user_id: int) -> dict[str, Any] | None:
        return self._users.get(user_id)

    async def list(self, skip: int = 0, limit: int = 100) -> list[dict[str, Any]]:
        return list(self._users.values())[skip : skip + limit]


repo = UserRepo()


# ── Lifespan ───────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    logger.info("starting up")
    # Тут: подключение к БД, инициализация
    yield
    logger.info("shutting down")
    # Тут: закрытие соединений


# ── App ────────────────────────────────────────
app = FastAPI(title="FastAPI Template", version="0.1.0", lifespan=lifespan)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/users", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(data: UserCreate) -> dict[str, Any]:
    user = await repo.create(data)
    logger.info("user_created", extra={"user_id": user["id"]})
    return user


@app.get("/users/{user_id}", response_model=UserResponse)
async def get_user(user_id: int) -> dict[str, Any]:
    if user := await repo.get(user_id):
        return user
    raise HTTPException(status_code=404, detail="User not found")


@app.get("/users", response_model=list[UserResponse])
async def list_users(skip: int = 0, limit: int = 100) -> list[dict[str, Any]]:
    return await repo.list(skip, limit)


# ── Error handlers ─────────────────────────────
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Any, exc: HTTPException) -> Any:
    return ErrorResponse(detail=exc.detail)
