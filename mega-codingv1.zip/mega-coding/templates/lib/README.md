# Library Package Template

```
mylib/
├── __init__.py        # public API
├── _internal/         # private implementation
├── types/             # custom types
├── utils/             # helpers
└── tests/
```

```python
# __init__.py
from ._internal.core import MyClass

__all__ = ["MyClass"]
```
