# CLI Template

```
my-cli/
├── __init__.py
├── __main__.py     # python -m my-cli
├── cli.py           # argparse/click
├── commands/        # subcommands
├── utils/           # helpers
└── tests/
```

```python
# __main__.py
from .cli import main
import sys

if __name__ == "__main__":
    sys.exit(main())
```
