#!/usr/bin/env python3
"""CLI tool template with argparse and subcommands."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def cmd_init(args: argparse.Namespace) -> int:
    """Initialize a new project."""
    name = args.name
    path = args.dir / name if args.dir else Path.cwd() / name
    path.mkdir(parents=True, exist_ok=True)
    (path / "src").mkdir(exist_ok=True)
    (path / "tests").mkdir(exist_ok=True)
    (path / "README.md").write_text(f"# {name}\n\nProject created by CLI tool.\n")
    print(f"✅ Created project {name} at {path}")
    return 0


def cmd_build(args: argparse.Namespace) -> int:
    """Build the project."""
    config = args.config or Path("pyproject.toml")
    if not config.exists():
        print(f"❌ Config not found: {config}", file=sys.stderr)
        return 1
    print(f"🔨 Building with {config}...")
    # Здесь: build logic
    print("✅ Build complete")
    return 0


def cmd_clean(args: argparse.Namespace) -> int:
    """Clean build artifacts."""
    patterns = ["__pycache__", "*.pyc", ".pytest_cache", "dist", "build", "*.egg-info"]
    for pattern in patterns:
        for p in Path.cwd().rglob(pattern):
            if p.is_dir():
                import shutil
                shutil.rmtree(p, ignore_errors=True)
                print(f"  Removed dir: {p}")
            else:
                p.unlink(missing_ok=True)
                print(f"  Removed file: {p}")
    return 0


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="CLI tool template",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    
    subparsers = parser.add_subparsers(dest="command", required=True, title="Commands")
    
    # init
    init_parser = subparsers.add_parser("init", help="Initialize a new project")
    init_parser.add_argument("name", help="Project name")
    init_parser.add_argument("--dir", "-d", type=Path, default=None, help="Parent directory")
    init_parser.set_defaults(func=cmd_init)
    
    # build
    build_parser = subparsers.add_parser("build", help="Build the project")
    build_parser.add_argument("--config", "-c", type=Path, default=None, help="Config file path")
    build_parser.set_defaults(func=cmd_build)
    
    # clean
    clean_parser = subparsers.add_parser("clean", help="Clean build artifacts")
    clean_parser.set_defaults(func=cmd_clean)
    
    # version
    subparsers.add_parser("version", help="Show version").set_defaults(
        func=lambda _: print("v0.1.0") or 0
    )
    
    args = parser.parse_args(argv)
    if hasattr(args, "func"):
        sys.exit(args.func(args))
    parser.print_help()


if __name__ == "__main__":
    main()
