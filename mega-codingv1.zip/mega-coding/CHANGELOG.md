# Changelog

## [0.2.0] — 2026-05-30
### Добавлено
- CLI: lint, check, scaffold, checklist
- 9 проверок кода (E001–E010)
- Автолинтинг после каждой команды
- Scaffold с нормальной структурой проекта
- Чеклисты: PR, review, security
- AGENTS.md с правилами для ИИ

## [0.1.0] — 2026-05-30
### Добавлено
- Первая версия checker.py
- Базовые проверки: syntax, magic numbers, logs
- pyproject.toml
- README
