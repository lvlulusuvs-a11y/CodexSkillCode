#!/usr/bin/env python3
"""Менеджер конфигураций с поддержкой JSON/YAML/TOML/ENV."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


class Config:
    def __init__(self, path: str | Path | None = None):
        self._data: dict[str, Any] = {}
        if path:
            self.load(path)

    def load(self, path: str | Path) -> None:
        p = Path(path)
        ext = p.suffix.lower()
        text = p.read_text(encoding="utf-8")

        if ext in (".json",):
            self._data = json.loads(text)
        elif ext in (".yaml", ".yml"):
            import yaml
            self._data = yaml.safe_load(text)
        elif ext in (".toml",):
            import tomllib
            self._data = tomllib.loads(text)
        elif ext in (".env",):
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, val = line.partition("=")
                self._data[key.strip()] = val.strip().strip("\"'")
        else:
            raise ValueError(f"Unsupported config format: {ext}")

    def export(self, path: str | Path, fmt: str | None = None) -> None:
        p = Path(path)
        fmt = fmt or p.suffix.lstrip(".")
        text = ""
        if fmt == "json":
            text = json.dumps(self._data, indent=2, ensure_ascii=False)
        elif fmt in ("yaml", "yml"):
            import yaml
            text = yaml.dump(self._data, default_flow_style=False)
        elif fmt == "toml":
            import tomli_w
            text = tomli_w.dumps(self._data)
        elif fmt == "env":
            text = "\n".join(f"{k}={v}" for k, v in self._data.items())
        p.write_text(text)

    def get(self, key: str, default: Any = None) -> Any:
        keys = key.split(".")
        data = self._data
        for k in keys:
            if isinstance(data, dict):
                data = data.get(k)
            else:
                return default
            if data is None:
                return default
        return data

    def set(self, key: str, value: Any) -> None:
        keys = key.split(".")
        data = self._data
        for k in keys[:-1]:
            if k not in data:
                data[k] = {}
            data = data[k]
            if not isinstance(data, dict):
                raise KeyError(f"Cannot set {key}: {k} is not a dict")
        data[keys[-1]] = value

    def __getitem__(self, key: str) -> Any:
        val = self.get(key)
        if val is None and key not in self._data:
            raise KeyError(key)
        return val

    def __setitem__(self, key: str, value: Any) -> None:
        self.set(key, value)

    def __contains__(self, key: str) -> bool:
        return self.get(key) is not None

    def __repr__(self) -> str:
        return f"Config({json.dumps(self._data, indent=2)})"


def main() -> int:
    import sys
    if len(sys.argv) < 2:
        print("Usage: config-manager.py <config-file> [key] [value]")
        return 1

    config = Config(sys.argv[1])
    if len(sys.argv) == 2:
        print(config)
    elif len(sys.argv) == 3:
        print(config.get(sys.argv[2]))
    else:
        config.set(sys.argv[2], sys.argv[3])
        config.export(sys.argv[1])
    return 0


if __name__ == "__main__":
    main()
