#!/usr/bin/env python3
"""Простой анализатор данных на Python."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path
from collections import Counter, defaultdict
from typing import Any


class DataAnalyzer:
    def __init__(self, path: Path):
        self.path = path
        self.raw: list[dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        ext = self.path.suffix.lower()
        if ext == ".csv":
            with self.path.open(newline="", encoding="utf-8") as f:
                self.raw = list(csv.DictReader(f))
        elif ext == ".json":
            self.raw = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            raise ValueError(f"Unsupported format: {ext}")

    @property
    def columns(self) -> list[str]:
        return list(self.raw[0].keys()) if self.raw else []

    @property
    def row_count(self) -> int:
        return len(self.raw)

    def value_counts(self, column: str) -> dict[str, int]:
        return dict(Counter(r.get(column, "") for r in self.raw).most_common())

    def filter(self, column: str, value: Any) -> list[dict]:
        return [r for r in self.raw if r.get(column) == value]

    def summary(self) -> dict[str, Any]:
        if not self.raw:
            return {"error": "No data"}
        result: dict[str, Any] = {
            "file": str(self.path),
            "rows": self.row_count,
            "columns": len(self.columns),
            "column_names": self.columns,
        }
        for col in self.columns:
            values = [r.get(col) for r in self.raw if r.get(col)]
            if values and all(v.replace(".", "", 1).isdigit() for v in values if v):
                nums = [float(v) for v in values]
                result[f"{col}_stats"] = {
                    "min": min(nums),
                    "max": max(nums),
                    "avg": sum(nums) / len(nums),
                }
        return result

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.raw, indent=indent, ensure_ascii=False)


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: data-analyzer.py <file.csv|file.json> [--summary]")
        return 1

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"File not found: {path}")
        return 1

    analyzer = DataAnalyzer(path)
    print(f"Loaded {analyzer.row_count} rows, {len(analyzer.columns)} columns")
    print(f"Columns: {', '.join(analyzer.columns)}")

    if "--summary" in sys.argv:
        sm = analyzer.summary()
        print(json.dumps(sm, indent=2, ensure_ascii=False))

    return 0


if __name__ == "__main__":
    sys.exit(main())
