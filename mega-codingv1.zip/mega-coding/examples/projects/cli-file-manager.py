#!/usr/bin/env python3
"""CLI файловый менеджер с аргументами."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any


class FileManager:
    def __init__(self, base: Path = Path(".")):
        self.base = base.resolve()

    def ls(self, pattern: str = "*") -> list[dict[str, Any]]:
        items = []
        for p in sorted(self.base.glob(pattern)):
            items.append({
                "name": p.name,
                "size": p.stat().st_size,
                "is_dir": p.is_dir(),
                "modified": p.stat().st_mtime,
            })
        return items

    def info(self, path: str) -> dict[str, Any]:
        p = self.base / path
        if not p.exists():
            return {"error": f"File not found: {path}"}
        return {
            "name": p.name,
            "path": str(p.relative_to(self.base)),
            "size": p.stat().st_size,
            "is_dir": p.is_dir(),
            "is_file": p.is_file(),
            "modified": p.stat().st_mtime,
            "extension": p.suffix,
        }

    def tree(self, max_depth: int = 2) -> list[str]:
        lines: list[str] = []

        def _walk(p: Path, depth: int) -> None:
            if depth > max_depth:
                return
            indent = "  " * depth
            lines.append(f"{indent}{p.name}/" if p.is_dir() else f"{indent}{p.name}")
            if p.is_dir():
                for child in sorted(p.iterdir()):
                    _walk(child, depth + 1)

        _walk(self.base, 0)
        return lines


def cmd_ls(args: argparse.Namespace) -> int:
    fm = FileManager(Path(args.path))
    items = fm.ls(args.pattern)
    for item in items:
        icon = "📁" if item["is_dir"] else "📄"
        print(f"{icon} {item['name']:30s} {item['size']:>8d} B")
    return 0


def cmd_tree(args: argparse.Namespace) -> int:
    fm = FileManager(Path(args.path))
    for line in fm.tree(args.depth):
        print(line)
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    fm = FileManager(Path(args.path))
    info = fm.info(args.file)
    for key, val in info.items():
        print(f"  {key}: {val}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="fm", description="File Manager CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_ls = sub.add_parser("ls")
    p_ls.add_argument("path", nargs="?", default=".")
    p_ls.add_argument("--pattern", default="*")
    p_ls.set_defaults(func=cmd_ls)

    p_tree = sub.add_parser("tree")
    p_tree.add_argument("path", nargs="?", default=".")
    p_tree.add_argument("--depth", type=int, default=2)
    p_tree.set_defaults(func=cmd_tree)

    p_info = sub.add_parser("info")
    p_info.add_argument("path", nargs="?", default=".")
    p_info.add_argument("file", help="File to inspect")
    p_info.set_defaults(func=cmd_info)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
