#!/usr/bin/env python3
"""Асинхронный веб-скрапер с aiohttp."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any

import aiohttp
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


@dataclass
class PageResult:
    url: str
    title: str
    status: int
    links: list[str]
    text_length: int
    error: str | None = None


class AsyncScraper:
    def __init__(self, max_concurrent: int = 10):
        self._sem = asyncio.Semaphore(max_concurrent)
        self._results: list[PageResult] = []

    async def fetch(self, session: aiohttp.ClientSession, url: str) -> PageResult:
        async with self._sem:
            try:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    text = await resp.text()
                    soup = BeautifulSoup(text, "html.parser")
                    title = soup.title.string if soup.title else "No title"
                    links = [
                        a.get("href") for a in soup.find_all("a", href=True)
                        if a.get("href", "").startswith("http")
                    ]
                    return PageResult(
                        url=url,
                        title=title.strip()[:100],
                        status=resp.status,
                        links=links[:20],
                        text_length=len(text),
                    )
            except Exception as e:
                return PageResult(
                    url=url, title="", status=0,
                    links=[], text_length=0, error=str(e),
                )

    async def scrape(self, urls: list[str]) -> list[PageResult]:
        connector = aiohttp.TCPConnector(limit=50)
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = [self.fetch(session, url) for url in urls]
            self._results = await asyncio.gather(*tasks)
        return self._results


async def main():
    logging.basicConfig(level=logging.INFO)
    urls = [
        "https://example.com",
        "https://httpbin.org/html",
        "https://invalid.url.test",
    ]
    scraper = AsyncScraper(max_concurrent=5)
    results = await scraper.scrape(urls)

    for r in results:
        status = "✓" if r.error is None else "✗"
        print(f"{status} {r.url}: {r.title} ({r.status}) [{r.text_length}b]")
        if r.error:
            print(f"   Error: {r.error}")


if __name__ == "__main__":
    asyncio.run(main())
