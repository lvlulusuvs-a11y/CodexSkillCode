#!/usr/bin/env python3
"""Пример FastAPI ToDo приложения с полным циклом."""

from __future__ import annotations

from fastapi import FastAPI, HTTPException, Depends, status
from pydantic import BaseModel, Field
from typing import Annotated
from datetime import datetime

app = FastAPI(title="ToDo API", version="0.1.0")

# ── In-memory DB ───────────────────────────────────────────────────
class TodoDB:
    def __init__(self):
        self._items: dict[int, dict] = {}
        self._counter = 0

    def create(self, title: str, description: str = "") -> dict:
        self._counter += 1
        item = {
            "id": self._counter,
            "title": title,
            "description": description,
            "done": False,
            "created_at": datetime.now().isoformat(),
        }
        self._items[self._counter] = item
        return item

    def list(self, done: bool | None = None) -> list[dict]:
        items = list(self._items.values())
        if done is not None:
            items = [i for i in items if i["done"] == done]
        return sorted(items, key=lambda x: x["id"])

    def get(self, item_id: int) -> dict | None:
        return self._items.get(item_id)

    def update(self, item_id: int, data: dict) -> dict | None:
        if item_id not in self._items:
            return None
        self._items[item_id].update(data)
        return self._items[item_id]

    def delete(self, item_id: int) -> bool:
        return self._items.pop(item_id, None) is not None


db = TodoDB()


# ── Schemas ────────────────────────────────────────────────────────
class TodoCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: str = ""
    done: bool = False


class TodoUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    done: bool | None = None


class TodoResponse(BaseModel):
    id: int
    title: str
    description: str
    done: bool
    created_at: str


# ── Endpoints ──────────────────────────────────────────────────────
@app.post("/todos", response_model=TodoResponse, status_code=status.HTTP_201_CREATED)
async def create_todo(data: TodoCreate):
    return db.create(data.title, data.description)


@app.get("/todos", response_model=list[TodoResponse])
async def list_todos(done: bool | None = None):
    return db.list(done)


@app.get("/todos/{todo_id}", response_model=TodoResponse)
async def get_todo(todo_id: int):
    item = db.get(todo_id)
    if not item:
        raise HTTPException(status_code=404, detail="Todo not found")
    return item


@app.patch("/todos/{todo_id}", response_model=TodoResponse)
async def update_todo(todo_id: int, data: TodoUpdate):
    update_data = {k: v for k, v in data.model_dump().items() if v is not None}
    item = db.update(todo_id, update_data)
    if not item:
        raise HTTPException(status_code=404, detail="Todo not found")
    return item


@app.delete("/todos/{todo_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_todo(todo_id: int):
    if not db.delete(todo_id):
        raise HTTPException(status_code=404, detail="Todo not found")
