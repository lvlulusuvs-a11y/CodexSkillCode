# Strategy Pattern Boilerplate

```python
from __future__ import annotations
from abc import ABC, abstractmethod


class SortStrategy(ABC):
    @abstractmethod
    def sort(self, items: list[int]) -> list[int]: ...


class BubbleSort(SortStrategy):
    def sort(self, items: list[int]) -> list[int]:
        arr = items.copy()
        n = len(arr)
        for i in range(n):
            for j in range(0, n - i - 1):
                if arr[j] > arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
        return arr


class QuickSort(SortStrategy):
    def sort(self, items: list[int]) -> list[int]:
        if len(items) <= 1:
            return items
        pivot = items[0]
        lesser = [x for x in items[1:] if x <= pivot]
        greater = [x for x in items[1:] if x > pivot]
        return self.sort(lesser) + [pivot] + self.sort(greater)


class Sorter:
    def __init__(self, strategy: SortStrategy):
        self._strategy = strategy

    @property
    def strategy(self) -> SortStrategy:
        return self._strategy

    @strategy.setter
    def strategy(self, strategy: SortStrategy) -> None:
        self._strategy = strategy

    def sort(self, items: list[int]) -> list[int]:
        return self._strategy.sort(items)


# Usage
items = [3, 1, 4, 1, 5, 9, 2, 6]
sorter = Sorter(QuickSort())
print(sorter.sort(items))  # [1, 1, 2, 3, 4, 5, 6, 9]
sorter.strategy = BubbleSort()
print(sorter.sort(items))
```
