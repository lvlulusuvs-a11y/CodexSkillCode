# Redis Cache Boilerplate

```python
from __future__ import annotations
import json
from typing import Any, Callable
from functools import wraps

try:
    import redis.asyncio as aioredis
except ImportError:
    aioredis = None


class Cache:
    def __init__(self, url: str = "redis://localhost:6379/0"):
        self._redis = aioredis.from_url(url) if aioredis else None

    async def get(self, key: str) -> Any | None:
        if not self._redis:
            return None
        data = await self._redis.get(key)
        return json.loads(data) if data else None

    async def set(self, key: str, value: Any, ttl: int = 300) -> None:
        if not self._redis:
            return
        await self._redis.set(key, json.dumps(value), ex=ttl)

    async def delete(self, key: str) -> None:
        if self._redis:
            await self._redis.delete(key)

    async def clear_pattern(self, pattern: str) -> None:
        if not self._redis:
            return
        keys = await self._redis.keys(pattern)
        if keys:
            await self._redis.delete(*keys)


_cache = Cache()


def cached(ttl: int = 300):
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            key = f"{func.__name__}:{args}:{kwargs}"
            cached = await _cache.get(key)
            if cached is not None:
                return cached
            result = await func(*args, **kwargs)
            await _cache.set(key, result, ttl)
            return result
        return wrapper
    return decorator
```
