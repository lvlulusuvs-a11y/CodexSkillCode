# Async Testing Boilerplate

```python
"""Async test helpers and fixtures."""

from __future__ import annotations
import asyncio
from typing import AsyncGenerator, Any
from unittest.mock import AsyncMock, patch


# --- Async context manager for temp DB ---
class TestDatabase:
    def __init__(self):
        self._tables: dict[str, list[dict]] = {}

    async def insert(self, table: str, data: dict) -> int:
        self._tables.setdefault(table, []).append(data)
        return len(self._tables[table])

    async def select(self, table: str, **filters) -> list[dict]:
        results = self._tables.get(table, [])
        for key, val in filters.items():
            results = [r for r in results if r.get(key) == val]
        return results

    async def clear(self) -> None:
        self._tables.clear()


# --- Fixtures ---
import pytest


@pytest.fixture
def event_loop():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    yield loop
    loop.close()


@pytest.fixture
async def db() -> AsyncGenerator[TestDatabase, None]:
    database = TestDatabase()
    yield database
    await database.clear()


@pytest.mark.asyncio
async def test_insert(db: TestDatabase):
    id = await db.insert("users", {"name": "Test", "email": "test@test.com"})
    assert id == 1


@pytest.mark.asyncio
async def test_select(db: TestDatabase):
    await db.insert("users", {"name": "Alice", "email": "alice@test.com"})
    await db.insert("users", {"name": "Bob", "email": "bob@test.com"})
    users = await db.select("users", name="Alice")
    assert len(users) == 1
    assert users[0]["email"] == "alice@test.com"
```
