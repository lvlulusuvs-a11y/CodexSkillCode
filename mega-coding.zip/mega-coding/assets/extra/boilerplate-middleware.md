# Middleware Patterns Boilerplate

```python
"""Middleware examples for FastAPI, aiogram, and generic apps."""

from __future__ import annotations
import time
import logging
from typing import Any, Callable, Awaitable

logger = logging.getLogger(__name__)


# --- FastAPI Middleware ---
"""
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

class TimingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = time.perf_counter() - start
        logger.info("%s %s - %.3fs", request.method, request.url.path, elapsed)
        return response
"""

# --- aiogram Middleware ---
"""
from aiogram import BaseMiddleware

class LoggingMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        logger.debug("Update: %s", event)
        result = await handler(event, data)
        return result
"""

# --- Generic Middleware Stack ---
class Middleware:
    def __init__(self, func: Callable[..., Awaitable[Any]]):
        self._func = func
        self._middlewares: list[Callable] = []

    def add(self, middleware: Callable) -> "Middleware":
        self._middlewares.append(middleware)
        return self

    async def run(self, *args: Any, **kwargs: Any) -> Any:
        async def chain(index: int, *a: Any, **kw: Any) -> Any:
            if index < len(self._middlewares):
                return await self._middlewares[index](
                    lambda *aa, **kk: chain(index + 1, *aa, **kk), *a, **kw
                )
            return await self._func(*a, **kw)
        return await chain(0, *args, **kwargs)


# Usage
async def handle(msg: str):
    return f"Handled: {msg}"

async def log_mw(next_call, msg: str):
    print(f"Before: {msg}")
    result = await next_call(msg)
    print(f"After: {result}")
    return result

async def time_mw(next_call, msg: str):
    start = time.perf_counter()
    result = await next_call(msg)
    print(f"Took: {time.perf_counter() - start:.3f}s")
    return result

mw = Middleware(handle).add(log_mw).add(time_mw)
```
