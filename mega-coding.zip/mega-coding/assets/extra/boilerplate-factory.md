# Factory Pattern Boilerplate

```python
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any


# --- Product ---
class Notifier(ABC):
    @abstractmethod
    async def send(self, to: str, message: str) -> bool: ...


class EmailNotifier(Notifier):
    async def send(self, to: str, message: str) -> bool:
        print(f"Email to {to}: {message}")
        return True


class SMSNotifier(Notifier):
    async def send(self, to: str, message: str) -> bool:
        print(f"SMS to {to}: {message}")
        return True


class TelegramNotifier(Notifier):
    async def send(self, to: str, message: str) -> bool:
        print(f"Telegram to {to}: {message}")
        return True


# --- Factory ---
class NotifierFactory:
    _notifiers: dict[str, type[Notifier]] = {
        "email": EmailNotifier,
        "sms": SMSNotifier,
        "telegram": TelegramNotifier,
    }

    @classmethod
    def register(cls, name: str, notifier: type[Notifier]) -> None:
        cls._notifiers[name] = notifier

    @classmethod
    def create(cls, kind: str, **kwargs: Any) -> Notifier:
        notifier_cls = cls._notifiers.get(kind)
        if not notifier_cls:
            raise ValueError(f"Unknown notifier: {kind}")
        return notifier_cls(**kwargs)


# --- Usage ---
async def main():
    email_svc = NotifierFactory.create("email")
    await email_svc.send("user@test.com", "Hello!")

    telegram_svc = NotifierFactory.create("telegram", chat_id=123)
    await telegram_svc.send("@user", "Hello!")
```
