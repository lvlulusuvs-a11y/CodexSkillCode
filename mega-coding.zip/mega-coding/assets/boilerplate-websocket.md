# WebSocket Boilerplate

```python
# app/ws.py
from fastapi import WebSocket, WebSocketDisconnect, APIRouter

router = APIRouter()

class ConnectionManager:
    def __init__(self):
        self._connections: dict[int, WebSocket] = {}

    async def connect(self, user_id: int, ws: WebSocket):
        await ws.accept()
        self._connections[user_id] = ws

    def disconnect(self, user_id: int):
        self._connections.pop(user_id, None)

    async def send_to(self, user_id: int, data: dict):
        ws = self._connections.get(user_id)
        if ws:
            try:
                await ws.send_json(data)
            except Exception:
                self.disconnect(user_id)

    async def broadcast(self, data: dict):
        for user_id, ws in list(self._connections.items()):
            try:
                await ws.send_json(data)
            except Exception:
                self.disconnect(user_id)

manager = ConnectionManager()

@router.websocket("/ws/{user_id}")
async def websocket_endpoint(ws: WebSocket, user_id: int):
    await manager.connect(user_id, ws)
    try:
        while True:
            data = await ws.receive_json()
            # обработка входящих сообщений
            await manager.send_to(user_id, {"echo": data})
    except WebSocketDisconnect:
        manager.disconnect(user_id)
```
