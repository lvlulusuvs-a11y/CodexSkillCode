#!/usr/bin/env python3
"""Расширенный пример использования инструментов mega-coding."""

from __future__ import annotations

import ast
import sys
from pathlib import Path
from collections import Counter


class CodeAnalyzer:
    """Анализатор Python-кода с разными метриками."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.source = path.read_text(encoding="utf-8")
        self.tree = ast.parse(self.source)
        self.lines = self.source.splitlines()

    @property
    def loc(self) -> int:
        """Строк кода (без пустых и комментариев)."""
        count = 0
        for line in self.lines:
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                count += 1
        return count

    @property
    def function_count(self) -> int:
        """Количество функций."""
        return sum(1 for n in ast.walk(self.tree)
                   if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))

    @property
    def class_count(self) -> int:
        """Количество классов."""
        return sum(1 for n in ast.walk(self.tree)
                   if isinstance(n, ast.ClassDef))

    @property
    def import_count(self) -> int:
        """Количество импортов."""
        return sum(1 for n in ast.walk(self.tree)
                   if isinstance(n, (ast.Import, ast.ImportFrom)))

    @property
    def avg_function_length(self) -> float:
        """Средняя длина функции."""
        lengths = []
        for node in ast.walk(self.tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if hasattr(node, 'end_lineno') and node.end_lineno:
                    lengths.append(node.end_lineno - node.lineno + 1)
        return sum(lengths) / len(lengths) if lengths else 0

    def report(self) -> str:
        lines = [
            f"📊 {self.path.name}",
            f"    LOC: {self.loc}",
            f"    Функций: {self.function_count}",
            f"    Классов: {self.class_count}",
            f"    Импортов: {self.import_count}",
            f"    Средняя длина функции: {self.avg_function_length:.1f} строк",
        ]
        return "\n".join(lines)


def main() -> int:
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    if path.is_file():
        analyzer = CodeAnalyzer(path)
        print(analyzer.report())
    else:
        for pyfile in sorted(path.rglob("*.py")):
            if any(p.startswith(".") or p == "__pycache__" for p in pyfile.parts):
                continue
            analyzer = CodeAnalyzer(pyfile)
            print(analyzer.report())
            print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
