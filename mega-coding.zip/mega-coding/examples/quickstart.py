#!/usr/bin/env python3
"""Пример быстрого старта с mega-coding."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def greet(name: str, repeat: int = 1) -> str:
    """Вернуть приветствие."""
    return "\n".join(f"Hello, {name}!" for _ in range(repeat))


def analyze_file(path: Path) -> dict:
    """Простой анализ Python-файла."""
    source = path.read_text(encoding="utf-8")
    lines = source.splitlines()
    return {
        "file": str(path),
        "lines": len(lines),
        "chars": len(source),
        "has_type_hints": "->" in source,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="mega-coding quickstart")
    parser.add_argument("file", nargs="?", help="Python file to analyze")
    args = parser.parse_args()

    if args.file:
        result = analyze_file(Path(args.file))
        for key, val in result.items():
            print(f"  {key}: {val}")
    else:
        print(greet("mega-coder", 3))

    return 0


if __name__ == "__main__":
    sys.exit(main())
