# Idiomatic Python

## List Comprehensions
```python
# ❌ Плохо
result = []
for i in range(100):
    if i % 2 == 0:
        result.append(i * 2)

# ✅ Хорошо
result = [i * 2 for i in range(100) if i % 2 == 0]
```

## Dict Comprehensions
```python
# ❌ Плохо
squares = {}
for i in range(10):
    squares[i] = i * i

# ✅ Хорошо
squares = {i: i * i for i in range(10)}
```

## Enumerate вместо range(len())
```python
# ❌ Плохо
for i in range(len(items)):
    print(i, items[i])

# ✅ Хорошо
for i, item in enumerate(items):
    print(i, item)
```

## zip для параллельных списков
```python
names = ["Alice", "Bob", "Charlie"]
ages = [25, 30, 35]

for name, age in zip(names, ages, strict=True):
    print(f"{name} is {age} years old")
```

## Unpacking
```python
# ❌ Плохо
first = items[0]
rest = items[1:]

# ✅ Хорошо
first, *rest = items

# Для словарей
defaults = {"host": "localhost", "port": 8080}
config = {**defaults, "port": 9090}  # переопределение
```

## Walrus Operator (:=)
```python
# ❌ Плохо
data = api.get_data()
if data:
    process(data)

# ✅ Хорошо
if data := api.get_data():
    process(data)

# В списках
results = [y for x in range(10) if (y := x * 2) > 5]
```

## Context Managers
```python
# ❌ Плохо
f = open("file.txt")
try:
    data = f.read()
finally:
    f.close()

# ✅ Хорошо
with open("file.txt") as f:
    data = f.read()
```

## Pathlib вместо os.path
```python
# ❌ Плохо
import os
path = os.path.join("dir", "file.txt")
if os.path.exists(path):
    with open(path) as f:
        pass

# ✅ Хорошо
from pathlib import Path
path = Path("dir") / "file.txt"
if path.exists():
    content = path.read_text()
```

## F-strings
```python
# ❌ Плохо
name = "Alice"
age = 30
print("Name: " + name + ", Age: " + str(age))
print("Name: %s, Age: %d" % (name, age))
print("Name: {}, Age: {}".format(name, age))

# ✅ Хорошо
print(f"Name: {name}, Age: {age}")
```

## Defaultdict
```python
from collections import defaultdict

# ❌ Плохо
groups = {}
for item in items:
    if item.key not in groups:
        groups[item.key] = []
    groups[item.key].append(item)

# ✅ Хорошо
groups = defaultdict(list)
for item in items:
    groups[item.key].append(item)
```

## dataclasses
```python
from dataclasses import dataclass

# ❌ Плохо
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

# ✅ Хорошо
@dataclass
class Point:
    x: float
    y: float
```

## any/all
```python
# ❌ Плохо
found = False
for item in items:
    if condition(item):
        found = True
        break

# ✅ Хорошо
found = any(condition(item) for item in items)
all_valid = all(is_valid(item) for item in items)
```
