# Python Internals & Performance

## Python object model
```python
# Всё — объект
print(type(1))             # <class 'int'>
print(type(type))          # <class 'type'>
print(type(object))        # <class 'type'>

# id — адрес в памяти
a = 42
b = 42
print(id(a) == id(b))  # True (small ints cached)

# __slots__ — экономия памяти
class Point:
    __slots__ = ("x", "y")  # нет __dict__
    def __init__(self, x, y):
        self.x, self.y = x, y
```

## GIL и многопоточность
- GIL — Global Interpreter Lock
- CPU-bound → multiprocessing
- IO-bound → threading (GIL отпускается)
- async/await — кооперативная многозадачность

## list vs tuple
```python
# list — mutable, тяжелее
lst = [1, 2, 3]

# tuple — immutable, легче (кэшируется)
tpl = (1, 2, 3)

# tuple быстрее при создании и итерации (на ~10-20%)
```

## dict — compact (3.6+)
```python
# С 3.6 dict сохраняет порядок вставки
# С 3.7 это часть спецификации
# С 3.12 — ещё более компактный

d = {"a": 1, "b": 2}
# Занимает ~72 байта + элементы
```

## f-string (3.12+)
```python
# В 3.12 можно переиспользовать кавычки
d = {"a": 1}
print(f"{d["a"]}")  # работает!

# Вложенные f-строки
width = 10
print(f"{f"{'hi':>{width}}":^{width*2}}")
```

## match-case (3.10+)
```python
def process(value) -> str:
    match value:
        case 0 | 1:
            return "binary"
        case int() as n if n > 0:
            return f"positive {n}"
        case {"key": str() as k}:
            return f"dict with key={k}"
        case _:
            return "other"
```

## Типизация (3.10+)
```python
# Union → |
str | int | None

# Optional → |
def get() -> str | None: ...

# TypeAlias
type Vector = list[float]

# TypeVar с ограничениями
type Num = int | float
T = TypeVar("T", bound=Num)

# Self (3.11+)
from typing import Self

class Builder:
    def set_name(self, name: str) -> Self:
        self.name = name
        return self
```

## Сборщик мусора
```python
import gc

# Включить отладку
gc.set_debug(gc.DEBUG_LEAK)

# Принудительно
gc.collect()

# Циклические ссылки
import weakref

class Node:
    def __init__(self):
        self.ref = None

a = Node()
b = Node()
a.ref = b
b.ref = a  # цикл! GC соберёт
```
