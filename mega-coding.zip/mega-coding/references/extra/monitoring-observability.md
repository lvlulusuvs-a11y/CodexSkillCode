# Monitoring & Observability

## Structured Logging
```python
import structlog

structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer(),
    ],
)

logger = structlog.get_logger()
logger.info("user_action", user_id=42, action="login", ip="192.168.1.1")
```

## Metrics (Prometheus)
```python
from prometheus_client import Counter, Histogram, Gauge, generate_latest

requests_total = Counter("http_requests_total", "Total HTTP requests")
request_duration = Histogram("http_request_duration_seconds", "Request duration")
active_users = Gauge("active_users", "Currently active users")

@app.middleware("http")
async def metrics_middleware(request, call_next):
    requests_total.inc()
    with request_duration.time():
        response = await call_next(request)
    return response

@app.get("/metrics")
async def metrics():
    return Response(content=generate_latest(), media_type="text/plain")
```

## Health Checks
```python
from fastapi import APIRouter
import redis.asyncio as aioredis

router = APIRouter(prefix="/health", tags=["health"])

@router.get("/")
async def health():
    return {"status": "ok", "version": __version__}

@router.get("/ready")
async def readiness():
    # Проверка зависимостей
    db_ok = await check_db()
    redis_ok = await check_redis()
    return {
        "database": "ok" if db_ok else "error",
        "redis": "ok" if redis_ok else "error",
    }
```

## Distributed Tracing (OpenTelemetry)
```python
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

provider = TracerProvider()
processor = BatchSpanProcessor(OTLPSpanExporter())
provider.add_span_processor(processor)
trace.set_tracer_provider(provider)

tracer = trace.get_tracer(__name__)

with tracer.start_as_current_span("process_request") as span:
    span.set_attribute("user_id", user_id)
    result = process(user_id)
```
