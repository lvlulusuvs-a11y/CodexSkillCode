# SQLAlchemy 2.0 Patterns

## Declarative Models
```python
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Integer, ForeignKey, DateTime, func
import datetime

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    email: Mapped[str] = mapped_column(String(255), unique=True)
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    posts: Mapped[list["Post"]] = relationship(back_populates="author")

class Post(Base):
    __tablename__ = "posts"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(String(5000))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    author: Mapped["User"] = relationship(back_populates="posts")
```

## Async Session
```python
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

engine = create_async_engine("postgresql+asyncpg://user:pass@localhost/db")
session_factory = async_sessionmaker(engine, expire_on_commit=False)

async def get_user(user_id: int) -> User | None:
    async with session_factory() as session:
        return await session.get(User, user_id)
```

## Eager Loading
```python
from sqlalchemy import select
from sqlalchemy.orm import selectinload, joinedload

# N+1 проблема
users = await session.execute(select(User))
for user in users.scalars():
    print(user.posts)  # N+1 запросов!

# Решение: selectinload
stmt = select(User).options(selectinload(User.posts))
users = await session.execute(stmt)
```

## Repository + Unit of Work
```python
class UserRepository:
    def __init__(self, session):
        self._session = session
    
    async def add(self, user: User) -> None:
        self._session.add(user)
    
    async def get(self, user_id: int) -> User | None:
        return await self._session.get(User, user_id)
    
    async def find_by_email(self, email: str) -> User | None:
        stmt = select(User).where(User.email == email)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
```
