# Redis Patterns for Python

## Подключение
```python
import redis.asyncio as aioredis

redis = aioredis.from_url(
    "redis://localhost:6379/0",
    decode_responses=True,
    max_connections=20,
)

await redis.set("key", "value")
value = await redis.get("key")  # "value"
```

## Кэширование
```python
async def get_user_cached(user_id: int) -> dict | None:
    # Попытка из кэша
    cached = await redis.get(f"user:{user_id}")
    if cached:
        import json
        return json.loads(cached)

    # Из БД
    user = await db.fetch_user(user_id)
    if user:
        await redis.setex(
            f"user:{user_id}",
            300,  # TTL 5 минут
            json.dumps(user.to_dict()),
        )
    return user
```

## Rate Limiting
```python
import time

async def check_rate_limit(
    key: str,
    max_requests: int = 60,
    window: int = 60,
) -> bool:
    now = int(time.time())
    pipeline = redis.pipeline()
    pipeline.zadd(f"ratelimit:{key}", {now: now})
    pipeline.zremrangebyscore(f"ratelimit:{key}", 0, now - window)
    pipeline.zcard(f"ratelimit:{key}")
    pipeline.expire(f"ratelimit:{key}", window)
    _, _, count, _ = await pipeline.execute()
    return count <= max_requests
```

## Pub/Sub
```python
async def publisher():
    for i in range(10):
        await redis.publish("channel", f"Message {i}")
        await asyncio.sleep(1)

async def subscriber():
    pubsub = redis.pubsub()
    await pubsub.subscribe("channel")
    async for message in pubsub.listen():
        if message["type"] == "message":
            print(f"Got: {message['data']}")

async def main():
    await asyncio.gather(publisher(), subscriber())
```

## Distributed Locks
```python
import uuid

async def acquire_lock(lock_name: str, ttl: int = 10) -> str | None:
    lock_id = str(uuid.uuid4())
    acquired = await redis.setnx(f"lock:{lock_name}", lock_id)
    if acquired:
        await redis.expire(f"lock:{lock_name}", ttl)
        return lock_id
    return None

async def release_lock(lock_name: str, lock_id: str) -> bool:
    # Только владелец может отпустить
    script = """
    if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
    else
        return 0
    end
    """
    return await redis.eval(script, 1, f"lock:{lock_name}", lock_id)
```
