# Performance Tips

## Измеряй, потом оптимизируй
```python
import time

start = time.perf_counter()
result = heavy_function()
elapsed = time.perf_counter() - start
print(f"took {elapsed:.3f}s")
```

## List vs Generator
```python
# list — жрёт память
squares = [x**2 for x in range(10_000_000)]

# generator — ленивый
squares = (x**2 for x in range(10_000_000))
```

## Set для поиска
```python
# O(n) — плохо
if item in long_list: ...

# O(1) — хорошо
if item in fast_set: ...
```

## f-strings быстрее %
```python
# f-string быстрее чем % и .format()
name = f"{first} {last}"
```

## Импорты
- Импортируй только то, что нужно
- Тяжёлые импорты — внутри функции если редко используются

## Бенчмарк
```python
from scripts.benchmark import compare, measure
```
