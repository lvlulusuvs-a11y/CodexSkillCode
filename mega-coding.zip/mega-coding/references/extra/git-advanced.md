# Advanced Git Workflow

## Interactive Rebase
```bash
# Исправить 3 последних коммита
git rebase -i HEAD~3

# Squash коммитов
pick abc123 feat: add login
squash def456 fix login typos  # ← объединить с предыдущим
pick ghi789 feat: add logout

# Reword сообщения
reword abc123 feat: add login  # ← изменить сообщение
```

## Cherry-pick
```bash
# Взять коммит из другой ветки
git cherry-pick abc123

# Не создавая коммит
git cherry-pick -n abc123
```

## Bisect
```bash
# Найти коммит, сломавший тест
git bisect start
git bisect bad HEAD
git bisect good v1.0
# → git checkout середину → проверить → git bisect good/bad
# → повторять пока не найдёт
git bisect reset
```

## Worktrees
```bash
# Параллельная папка с другой веткой
git worktree add ../project-feature feature-branch
# → ../project-feature/ — готовая папка с веткой
```

## Hooks
```bash
# .git/hooks/pre-push
#!/bin/bash
echo "Running tests before push..."
pytest || exit 1
```
