# Advanced Testing

## Parametrize
```python
import pytest

@pytest.mark.parametrize("input,expected", [
    (1, 2),
    (2, 4),
    (3, 6),
    (0, 0),
    (-1, -2),
])
def test_double(input: int, expected: int):
    assert input * 2 == expected
```

## Fixtures scopes
```python
@pytest.fixture(scope="session")  # один раз за сессию
def db_url():
    return "postgresql://test:test@localhost/test"

@pytest.fixture(scope="module")   # один раз за модуль
def connection(db_url):
    return create_engine(db_url)

@pytest.fixture(scope="function") # каждый тест
def session(connection):
    session = connection.session()
    yield session
    session.rollback()
```

## Async tests
```python
import pytest

@pytest.mark.asyncio
async def test_async_fetch():
    result = await fetch_data()
    assert result is not None
```

## Monkeypatch
```python
def test_get_user(monkeypatch):
    async def mock_get(user_id):
        return {"id": user_id, "name": "Test"}
    
    monkeypatch.setattr("app.api.get_user", mock_get)
    result = get_user(1)
    assert result["name"] == "Test"
```

## Test coverage
```bash
pytest --cov=src --cov-report=term --cov-report=html
# opens htmlcov/index.html
```

## Фабрики
```python
from factory import Factory, Faker

class UserFactory(Factory):
    class Meta:
        model = User
    
    name = Faker("name")
    email = Faker("email")
    age = Faker("random_int", min=18, max=99)
```
