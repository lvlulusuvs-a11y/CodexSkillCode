# Clean Code Principles

## Имена
```python
# ❌ Плохо
def proc(d):
    for i in d:
        if i[2] > 0:
            ...

# ✅ Хорошо
def process_active_users(users: list[User]) -> None:
    for user in users:
        if user.is_active:
            ...
```

## Функции — одна задача
```python
# ❌ Плохо
def process_data(data):
    validate(data)
    transform(data)
    save(data)
    send_email(data)

# ✅ Хорошо
def process_data(data):
    validated = validate(data)
    transformed = transform(validated)
    saved = save(transformed)
    notify(saved)
```

## Магические числа → константы
```python
TIMEOUT_SECONDS = 30
MAX_RETRIES = 3
DEFAULT_PAGE_SIZE = 20
```

## Ранний return
```python
def get_user(user_id: int) -> User | None:
    if user_id < 0:
        return None
    user = db.find(user_id)
    return user if user else None
```

## Error handling
```python
try:
    result = risky_operation()
except (ValueError, KeyError) as e:
    logger.warning("Invalid input: %s", e)
    return fallback
except ConnectionError:
    logger.error("DB connection failed")
    raise
```
