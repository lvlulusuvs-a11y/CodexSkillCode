# Advanced Async Patterns

## Structured Concurrency
```python
import asyncio
from contextlib import AsyncExitStack

async def main():
    # Гарантированная очистка ресурсов
    async with AsyncExitStack() as stack:
        db = await stack.enter_async_context(create_db())
        redis = await stack.enter_async_context(create_redis())
        result = await process(db, redis)
        # db и redis закроются автоматически
```

## Task Groups (3.11+)
```python
async def main():
    async with asyncio.TaskGroup() as tg:
        task1 = tg.create_task(fetch("https://api1.example.com"))
        task2 = tg.create_task(fetch("https://api2.example.com"))
        task3 = tg.create_task(fetch("https://api3.example.com"))
    # Все задачи завершены (или упали)
    results = [task1.result(), task2.result(), task3.result()]
```

## Async Generators
```python
async def read_lines(path: str) -> AsyncGenerator[str, None]:
    async with aiofiles.open(path, mode="r") as f:
        async for line in f:
            yield line.strip()

async def process():
    async for line in read_lines("data.txt"):
        if line:
            await handle(line)
```

## Async Context Managers
```python
class DatabaseConnection:
    async def __aenter__(self):
        self.conn = await create_connection()
        return self.conn

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.conn.close()

async def use_db():
    async with DatabaseConnection() as conn:
        await conn.execute("SELECT 1")
```

## Async Iterators
```python
class Counter:
    def __init__(self, limit: int):
        self.limit = limit
        self.current = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self.current >= self.limit:
            raise StopAsyncIteration
        self.current += 1
        await asyncio.sleep(0.1)
        return self.current

async def main():
    async for num in Counter(5):
        print(num)  # 1, 2, 3, 4, 5
```

## Async Queue with Priority
```python
import asyncio
from dataclasses import dataclass

@dataclass(order=True)
class PrioritizedItem:
    priority: int
    data: str = ""

async def worker(queue: asyncio.PriorityQueue):
    while True:
        item = await queue.get()
        if item.data is None:
            queue.task_done()
            break
        print(f"Processing: {item.data} (priority {item.priority})")
        queue.task_done()

async def main():
    queue = asyncio.PriorityQueue()
    await queue.put(PrioritizedItem(3, "low"))
    await queue.put(PrioritizedItem(1, "high"))
    await queue.put(PrioritizedItem(2, "medium"))
    await queue.put(PrioritizedItem(0, "critical"))
    await queue.put(PrioritizedItem(99, None))  # сигнал конца

    async with asyncio.TaskGroup() as tg:
        for _ in range(3):
            tg.create_task(worker(queue))
```
