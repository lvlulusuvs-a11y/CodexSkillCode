# Async/Await Patterns

## Основы
```python
import asyncio

async def fetch(url: str) -> str:
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            return await resp.text()
```

## Параллельный запуск
```python
# Последовательно
results = [await fetch(url) for url in urls]

# Параллельно
results = await asyncio.gather(*[fetch(url) for url in urls], return_exceptions=True)

# Семафор для ограничения
sem = asyncio.Semaphore(10)
async def bounded_fetch(url):
    async with sem:
        return await fetch(url)
```

## Тайм-ауты
```python
try:
    result = await asyncio.wait_for(fetch(url), timeout=5.0)
except asyncio.TimeoutError:
    logger.warning("Timeout on %s", url)
```

## Асинхронные генераторы
```python
async def stream_data():
    for i in range(100):
        await asyncio.sleep(0.1)
        yield i

async for item in stream_data():
    process(item)
```
