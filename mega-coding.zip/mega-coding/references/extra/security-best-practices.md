# Security Best Practices

## Input Validation
- Всегда валидируй и санитайзируй пользовательский ввод
- Используй Pydantic для схем запросов
- Никогда не доверяй данным из request/forms/headers

## SQL Injection
```python
# ❌ Плохо
cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")

# ✅ Хорошо
cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
```

## Secrets Management
- Никогда не хардкодь токены, пароли, ключи
- Используй .env + pydantic-settings
- Для production — vault / secrets manager

## Dependencies
- Регулярно обновляй зависимости
- `pip-audit` / `safety check` перед деплоем
- Не ставь пакеты без pinned versions

## Code Injection
```python
# ❌ Плохо
os.system(f"rm -rf {user_input}")
eval(user_code)

# ✅ Хорошо
import shutil
shutil.rmtree(safe_path, ignore_errors=True)
ast.literal_eval(safe_input)
```
