# API Design Guide

## RESTful
| Метод | Путь | Действие |
|-------|------|----------|
| GET | /users | список |
| POST | /users | создать |
| GET | /users/1 | получить |
| PATCH | /users/1 | обновить |
| DELETE | /users/1 | удалить |

## Статус-коды
- 200 — OK
- 201 — Created
- 204 — No Content (delete)
- 400 — Bad Request
- 401 — Unauthorized
- 403 — Forbidden
- 404 — Not Found
- 422 — Validation Error
- 429 — Too Many Requests
- 500 — Internal Server Error

## Версионирование
```python
# URL-based
/api/v1/users

# Header-based
Accept: application/vnd.api.v1+json
```

## Ошибки
```json
{
    "error": {
        "code": "VALIDATION_ERROR",
        "message": "Invalid email format",
        "details": {"field": "email"}
    }
}
```

## Пагинация
```python
GET /users?page=1&per_page=20
# Response:
{
    "data": [...],
    "meta": {"page": 1, "per_page": 20, "total": 100}
}
```
