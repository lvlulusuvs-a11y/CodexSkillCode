# Concurrency Patterns

## ThreadPoolExecutor
```python
from concurrent.futures import ThreadPoolExecutor, as_completed

with ThreadPoolExecutor(max_workers=4) as executor:
    futures = {executor.submit(process, item): item for item in items}
    for future in as_completed(futures):
        result = future.result()
        handle(result)
```

## asyncio.Queue
```python
import asyncio

async def producer(queue: asyncio.Queue, items: list):
    for item in items:
        await queue.put(item)
    await queue.put(None)  # сигнал конца

async def consumer(queue: asyncio.Queue, name: str):
    while True:
        item = await queue.get()
        if item is None:
            queue.task_done()
            break
        print(f"{name}: {item}")
        queue.task_done()

async def main():
    queue = asyncio.Queue(maxsize=10)
    producers = [producer(queue, range(100))]
    consumers = [consumer(queue, f"worker-{i}") for i in range(4)]
    await asyncio.gather(*producers, *consumers)
    await queue.join()
```

## Rate Limiting
```python
import asyncio

class RateLimiter:
    def __init__(self, max_calls: int, period: float):
        self._max = max_calls
        self._period = period
        self._calls: list[float] = []

    async def acquire(self):
        now = asyncio.get_event_loop().time()
        self._calls = [t for t in self._calls if now - t < self._period]
        if len(self._calls) >= self._max:
            wait = self._period - (now - self._calls[0])
            await asyncio.sleep(wait)
        self._calls.append(asyncio.get_event_loop().time())
```
