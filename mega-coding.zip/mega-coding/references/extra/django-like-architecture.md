# Django-like Architecture in FastAPI

## Структура
```
app/
├── apps/                  # Django-style apps
│   ├── users/
│   │   ├── __init__.py
│   │   ├── models.py      # SQLAlchemy models
│   │   ├── schemas.py     # Pydantic schemas
│   │   ├── services.py    # Business logic
│   │   ├── admin.py       # Admin interface
│   │   ├── tests.py
│   │   └── urls.py        # Routes
│   └── posts/
├── core/
│   ├── __init__.py
│   ├── config.py          # Settings
│   ├── database.py        # Engine + session
│   ├── security.py        # Auth
│   ├── permissions.py     # RBAC
│   └── exceptions.py
├── templates/
├── static/
└── tests/
```

## Admin Pattern
```python
# core/admin.py
from __future__ import annotations
from typing import Any

class ModelAdmin:
    list_display: list[str] = []
    search_fields: list[str] = []
    list_filter: list[str] = []
    ordering: list[str] = []

class AdminSite:
    def __init__(self):
        self._registry: dict[str, type[ModelAdmin]] = {}

    def register(self, model_name: str, admin: type[ModelAdmin]) -> None:
        self._registry[model_name] = admin

admin_site = AdminSite()
```

## Signals Pattern
```python
# core/signals.py
from __future__ import annotations
from typing import Any, Callable
from collections import defaultdict

class Signal:
    def __init__(self):
        self._receivers: list[Callable] = []

    def connect(self, receiver: Callable) -> None:
        self._receivers.append(receiver)

    async def send(self, sender: Any = None, **kwargs: Any) -> None:
        for receiver in self._receivers:
            await receiver(sender=sender, **kwargs)

# Global signals
user_registered = Signal()
order_created = Signal()
```

## Manager Pattern
```python
# core/managers.py
class QuerySet:
    def __init__(self, model, session):
        self._model = model
        self._session = session
        self._filters: list = []
        self._order: list = []
        self._limit_val = 0

    def filter(self, **kwargs) -> "QuerySet":
        self._filters.append(kwargs)
        return self

    def order_by(self, *fields: str) -> "QuerySet":
        self._order = list(fields)
        return self

    def limit(self, n: int) -> "QuerySet":
        self._limit_val = n
        return self

    async def all(self) -> list:
        stmt = select(self._model)
        for f in self._filters:
            for key, val in f.items():
                stmt = stmt.where(getattr(self._model, key) == val)
        result = await self._session.execute(stmt)
        return result.scalars().all()

class Manager:
    def __init__(self, model):
        self.model = model

    def get_queryset(self, session) -> QuerySet:
        return QuerySet(self.model, session)
```
