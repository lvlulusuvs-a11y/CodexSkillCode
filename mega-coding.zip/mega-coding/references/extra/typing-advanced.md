# Advanced Typing in Python

## TypeVars
```python
from typing import TypeVar, Generic, Sequence

T = TypeVar("T")
K = TypeVar("K")
V = TypeVar("V")

def first(items: Sequence[T]) -> T:
    return items[0]

def get_or_default(data: dict[K, V], key: K, default: V) -> V:
    return data.get(key, default)
```

## Generic Protocols
```python
from typing import Protocol, TypeVar

T_co = TypeVar("T_co", covariant=True)

class Comparable(Protocol[T_co]):
    def __lt__(self, other: T_co) -> bool: ...

def sort(items: list[Comparable]) -> list[Comparable]:
    return sorted(items)
```

## TypedDict
```python
from typing import TypedDict, NotRequired

class UserDict(TypedDict):
    id: int
    name: str
    email: str
    age: NotRequired[int]

user: UserDict = {"id": 1, "name": "Alice", "email": "alice@test.com"}
```

## LiteralString
```python
from typing import LiteralString

def execute(query: LiteralString, params: tuple = ()) -> None:
    # Безопасно: гарантированно строка-литерал
    cursor.execute(query, params)

execute("SELECT * FROM users WHERE id = ?", (1,))  # OK
execute(input("SQL: "))  # mypy error!
```

## Final и @final
```python
from typing import Final, final

MAX_RETRIES: Final = 3
DEFAULT_TIMEOUT: Final[float] = 30.0

@final
class BaseModel:
    pass

class UserModel(BaseModel):  # mypy error!
    pass
```

## Read-only
```python
from typing import ReadOnly
from dataclasses import dataclass

@dataclass
class Config:
    host: ReadOnly[str] = "localhost"
    port: ReadOnly[int] = 8080

cfg = Config()
cfg.port = 9090  # type error in strict mode
```

## Structural subtyping
```python
class SupportsClose(Protocol):
    def close(self) -> None: ...

def clean_up(items: list[SupportsClose]) -> None:
    for item in items:
        item.close()
```
