# FastAPI Best Practices

## Project Structure
```
app/
├── __init__.py
├── main.py                 # app creation, lifespan
├── config.py               # pydantic-settings
├── routers/                # endpoints
│   ├── __init__.py
│   ├── health.py
│   └── users.py
├── schemas/                # pydantic models
│   ├── __init__.py
│   ├── user.py
│   └── common.py
├── services/               # business logic
│   ├── __init__.py
│   └── user_service.py
├── repositories/           # DB layer
│   └── user_repo.py
├── dependencies.py         # DI
├── middleware.py           # cors, logging, auth
├── exceptions.py           # custom exceptions
└── tests/
    ├── conftest.py
    └── test_users.py
```

## Dependencies (DI)
```python
from fastapi import Depends, FastAPI
from app.services import UserService
from app.repositories import UserRepo

def get_user_service() -> UserService:
    return UserService(UserRepo())

@app.get("/users/{user_id}")
async def get_user(
    user_id: int,
    service: UserService = Depends(get_user_service),
):
    return await service.get_by_id(user_id)
```

## Error handling
```python
from fastapi import HTTPException
from app.exceptions import NotFoundError

@app.get("/users/{user_id}")
async def get_user(user_id: int):
    user = await service.get_by_id(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user
```

## Validation
```python
from pydantic import BaseModel, EmailStr, Field

class UserCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    age: int = Field(ge=0, le=150)
```

## Testing
```python
from httpx import AsyncClient, ASGITransport
from app.main import app

async def test_health():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        resp = await ac.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
```
