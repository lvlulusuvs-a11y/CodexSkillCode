# Flask Patterns

## App Factory
```python
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def create_app(config_name: str = "default") -> Flask:
    app = Flask(__name__)
    app.config.from_object(f"config.{config_name}")

    db.init_app(app)

    from app.routes import main_bp
    app.register_blueprint(main_bp)

    return app
```

## Blueprints
```python
from flask import Blueprint, jsonify, request

users_bp = Blueprint("users", __name__, url_prefix="/users")

@users_bp.route("/", methods=["GET"])
def list_users():
    users = User.query.all()
    return jsonify([u.to_dict() for u in users])

@users_bp.route("/<int:user_id>", methods=["GET"])
def get_user(user_id: int):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())
```

## Error Handlers
```python
@users_bp.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Not found"}), 404

@users_bp.errorhandler(400)
def bad_request(error):
    return jsonify({"error": str(error)}), 400

# Общий обработчик
@app.errorhandler(Exception)
def handle_error(error):
    app.logger.exception("Unhandled error")
    return jsonify({"error": "Internal server error"}), 500
```

## Request Validation
```python
from marshmallow import Schema, fields, validate

class UserSchema(Schema):
    name = fields.String(required=True, validate=validate.Length(min=1, max=100))
    email = fields.Email(required=True)
    age = fields.Integer(validate=validate.Range(min=0, max=150))

user_schema = UserSchema()

@users_bp.route("/", methods=["POST"])
def create_user():
    data = request.get_json()
    errors = user_schema.validate(data)
    if errors:
        return jsonify(errors), 400
    user = User(**data)
    db.session.add(user)
    db.session.commit()
    return jsonify(user_schema.dump(user)), 201
```

## Testing
```python
import pytest
from app import create_app, db

@pytest.fixture
def app():
    app = create_app("testing")
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()

@pytest.fixture
def client(app):
    return app.test_client()

def test_get_users(client):
    resp = client.get("/users/")
    assert resp.status_code == 200
    assert resp.is_json
```
