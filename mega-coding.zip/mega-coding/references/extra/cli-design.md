# CLI Design Patterns

## Click vs Argparse
```python
# Click
import click

@click.command()
@click.argument("name")
@click.option("--greeting", default="Hello")
@click.option("--count", default=1, type=int)
def greet(name: str, greeting: str, count: int):
    for _ in range(count):
        click.echo(f"{greeting}, {name}!")

# Argparse
import argparse

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--greeting", default="Hello")
    parser.add_argument("--count", type=int, default=1)
    args = parser.parse_args()
    for _ in range(args.count):
        print(f"{args.greeting}, {args.name}!")
    return 0
```

## Exit codes
| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error |
| 2 | Misuse of shell builtins |
| 130 | Ctrl+C |
| 137 | SIGKILL |

## Output
- stdout — только результат
- stderr — логи, ошибки, прогресс
- `--quiet` / `-q` — без вывода
- `--json` — машинный вывод

## Subcommands (argparse)
```python
sub = parser.add_subparsers(dest="command", required=True)
p1 = sub.add_parser("create")
p1.set_defaults(func=cmd_create)
```
