# Testing Guide

## Структура тестов
```
tests/
├── unit/           # изолированные тесты
├── integration/    # тесты с БД/API
└── conftest.py     # фикстуры
```

## Правила
- Один тест — одна проверка
- Тесты должны быть независимыми
- Используй factories, не хардкодь данные в каждом тесте
- `pytest -v --tb=short --cov` — минимум

## Фикстуры
```python
import pytest

@pytest.fixture
def db_session():
    session = create_session()
    yield session
    session.close()

@pytest.fixture
def sample_user(db_session):
    user = User(name="test", email="test@test.com")
    db_session.add(user)
    db_session.commit()
    return user
```

## Mock-и
```python
from unittest.mock import patch, AsyncMock

async def test_get_user():
    with patch("app.api.get_user", AsyncMock(return_value={"id": 1})):
        result = await get_user(1)
        assert result["id"] == 1
```
