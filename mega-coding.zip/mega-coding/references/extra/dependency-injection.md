# Dependency Injection

## Manual DI (без фреймворков)
```python
from dataclasses import dataclass

class Database:
    def query(self, sql: str) -> list[dict]:
        return [{"id": 1}]

class UserService:
    def __init__(self, db: Database):
        self._db = db

    def get_users(self) -> list[dict]:
        return self._db.query("SELECT * FROM users")

# Сборка зависимостей (composition root)
def create_app() -> UserService:
    db = Database()
    return UserService(db)
```

## FastAPI Depends
```python
from fastapi import Depends, FastAPI

async def get_db():
    db = Database()
    try:
        yield db
    finally:
        await db.close()

app = FastAPI()

@app.get("/users")
async def get_users(db: Database = Depends(get_db)):
    return await db.query("SELECT * FROM users")
```

## Почему DI?
- Тестируемость (легко мокать)
- Гибкость (легко менять реализации)
- Разделение ответственности
- Код слабо связан
