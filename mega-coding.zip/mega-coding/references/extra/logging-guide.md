# Logging Guide

## Настройка
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

logger = logging.getLogger(__name__)
```

## Уровни
| Уровень | Когда использовать |
|---------|-------------------|
| DEBUG | Детали для отладки |
| INFO | Подтверждение норм. работы |
| WARNING | Что-то необычное, но не критично |
| ERROR | Ошибка, но приложение живёт |
| CRITICAL | Всё упало, надо чинить |

## Лучшие практики
- Структурированные логи (JSON для prod)
- Не логируй пароли/токены!
- Используй `logger.exception()` в except блоках
- Добавляй контекст (user_id, request_id)

```python
# Хорошо
try:
    result = risky_call()
except ValueError as e:
    logger.error("Operation failed for user %s: %s", user_id, e)

# Плохо
try:
    result = risky_call()
except:
    pass
```
