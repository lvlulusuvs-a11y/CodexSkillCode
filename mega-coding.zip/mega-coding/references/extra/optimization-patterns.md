# Python Optimization Patterns

## Ленивые вычисления
```python
class LazyProperty:
    def __init__(self, func):
        self.func = func
        self.name = func.__name__

    def __get__(self, obj, type=None):
        if obj is None:
            return self
        value = self.func(obj)
        setattr(obj, self.name, value)
        return value

class DataProcessor:
    @LazyProperty
    def heavy_data(self):
        print("Computing...")
        return [i ** 2 for i in range(100000)]

dp = DataProcessor()
print(len(dp.heavy_data))  # Computing... 100000
print(len(dp.heavy_data))  # 100000 (cached)
```

## Пул объектов
```python
from queue import Queue

class ConnectionPool:
    def __init__(self, max_size: int = 10):
        self._pool: Queue = Queue(maxsize=max_size)
        self._max_size = max_size
        self._created = 0

    async def acquire(self) -> "Connection":
        try:
            return self._pool.get_nowait()
        except Exception:
            if self._created < self._max_size:
                self._created += 1
                return Connection()
            return await self._pool.get()

    async def release(self, conn: "Connection") -> None:
        self._pool.put_nowait(conn)
```

## __slots__
```python
class Point:
    __slots__ = ("x", "y", "z")

    def __init__(self, x, y, z):
        self.x, self.y, self.z = x, y, z

# Без __slots__: ~200 байт на объект
# С __slots__: ~56 байт на объект
# Особенно важно при миллионах объектов
```

## array vs list
```python
from array import array

# list — любые типы, ~28 байт на элемент
nums = [1, 2, 3, 4, 5]

# array — только один тип, ~8 байт на элемент (int)
fast_nums = array("i", [1, 2, 3, 4, 5])
```

## __match_args__ (3.10+)
```python
@dataclass
class Command:
    __match_args__ = ("action", "target")

    action: str
    target: str

def handle(cmd: Command) -> str:
    match cmd:
        case Command("delete", path):
            return f"Deleting {path}"
        case Command("create", name):
            return f"Creating {name}"
        case _:
            return "Unknown"
```

## profiling
```python
import cProfile
import pstats

def profile():
    profiler = cProfile.Profile()
    profiler.enable()
    # ваш код
    profiler.disable()
    stats = pstats.Stats(profiler)
    stats.sort_stats("cumulative")
    stats.print_stats(20)
```
