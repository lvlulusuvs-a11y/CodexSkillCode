# AsyncIO Deep Dive

## Event Loop
```python
import asyncio

# Получение цикла
loop = asyncio.get_event_loop()

# Создание задач
task = asyncio.create_task(coro())

# Ожидание нескольких
results = await asyncio.gather(coro1(), coro2(), return_exceptions=True)

# Первый завершившийся
done, pending = await asyncio.wait(
    [coro1(), coro2()],
    return_when=asyncio.FIRST_COMPLETED,
)
```

## Awaitable типы
1. **Coroutine** — `async def` функция
2. **Task** — обёртка над корутиной
3. **Future** — низкоуровневый awaitable

## Event Loop Callback Hell
```python
def _handler(future: asyncio.Future):
    try:
        result = future.result()
        print(f"Done: {result}")
    except Exception as e:
        print(f"Error: {e}")

future = loop.create_future()
future.add_done_callback(_handler)
```

## Синхронизация
```python
lock = asyncio.Lock()
event = asyncio.Event()
semaphore = asyncio.Semaphore(10)
condition = asyncio.Condition()

async with lock:
    # критическая секция
    pass
```

## Подпроцессы
```python
proc = await asyncio.create_subprocess_exec(
    "ffmpeg", "-i", "input.mp4", "output.mp3",
    stdout=asyncio.subprocess.PIPE,
    stderr=asyncio.subprocess.PIPE,
)
stdout, stderr = await proc.communicate()
```

## Отладка
```python
# Включить debug режим
asyncio.run(main(), debug=True)

# Узнать что висит
pending = asyncio.all_tasks()
for task in pending:
    print(task)
```
