# Error Handling Patterns

## Свои исключения
```python
class AppError(Exception):
    """Base application error."""
    def __init__(self, message: str, code: str = "UNKNOWN"):
        self.code = code
        super().__init__(message)

class NotFoundError(AppError):
    def __init__(self, entity: str, entity_id: int | str):
        super().__init__(
            f"{entity} with id={entity_id} not found",
            code="NOT_FOUND"
        )

class ValidationError(AppError):
    def __init__(self, field: str, reason: str):
        super().__init__(
            f"Validation failed for {field}: {reason}",
            code="VALIDATION_ERROR"
        )
```

## Result Pattern (monad-lite)
```python
from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")
E = TypeVar("E")

@dataclass
class Ok(Generic[T]):
    value: T

@dataclass
class Err(Generic[E]):
    error: E

type Result[T, E] = Ok[T] | Err[E]

def divide(a: float, b: float) -> Result[float, str]:
    if b == 0:
        return Err("Division by zero")
    return Ok(a / b)

result = divide(10, 0)
match result:
    case Ok(value):
        print(f"Result: {value}")
    case Err(error):
        print(f"Error: {error}")
```

## Graceful degradation
```python
async def get_user_safe(user_id: int) -> User | None:
    try:
        return await user_repo.get(user_id)
    except ConnectionError:
        logger.error("DB unavailable, returning cached")
        return await cache_repo.get(user_id)
    except Exception:
        logger.exception("Unexpected error")
        return None
```
