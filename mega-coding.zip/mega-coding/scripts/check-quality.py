#!/usr/bin/env python3
"""
Мега-проверка качества кода.

Использование:
  python scripts/check-quality.py <command> [путь]

Команды:
  lint          — проверить синтаксис Python-файлов
  check-logs    — просканировать логи на ошибки
  test-bot      — создать тестовую заглушку бота для отладки
  all           — всё сразу
"""

import ast
import sys
import os
import re
import shutil
from pathlib import Path


def cmd_lint(root: str = "."):
    """Проверить все .py файлы на синтаксические ошибки."""
    root_p = Path(root).resolve()
    errors = []
    for pyfile in root_p.rglob("*.py"):
        try:
            ast.parse(pyfile.read_text())
        except SyntaxError as e:
            errors.append((pyfile, e))
    if errors:
        print(f"❌ Найдено {len(errors)} ошибок:\n")
        for f, e in errors:
            print(f"  {f.relative_to(root_p)}:{e.lineno}: {e.msg}")
        return False
    else:
        print("✅ Все .py файлы синтаксически валидны")
        return True


def cmd_check_logs(log_dir: str = "logs"):
    """Просканировать папку логов на ERROR/CRITICAL."""
    log_p = Path(log_dir)
    if not log_p.exists():
        print(f"ℹ️ Папка логов не найдена: {log_dir}")
        return True

    errors_found = 0
    for logfile in log_p.rglob("*.log"):
        for line in logfile.read_text().splitlines():
            if "ERROR" in line or "CRITICAL" in line or "Traceback" in line:
                if errors_found == 0:
                    print(f"🔍 Ошибки в {logfile}:")
                print(f"  {line[:200]}")
                errors_found += 1

    if errors_found:
        print(f"\n⚠️ Всего ошибок в логах: {errors_found}")
        return False
    else:
        print("✅ Ошибки в логах не найдены")
        return True


def cmd_test_bot(root: str = "."):
    """Создать тестовую заглушку бота для отладки."""
    root_p = Path(root).resolve()
    test_file = root_p / "test_bot_stub.py"

    code = '''\
"""
Тестовая заглушка бота.
Запуск: python test_bot_stub.py
"""

import asyncio
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def main():
    logger.info("🚀 Тестовый бот запущен")
    logger.info("📋 Проверка: окружение готово")
    # TODO: вставь сюда тестируемую логику
    logger.info("✅ Тест пройден")
    return True


if __name__ == "__main__":
    asyncio.run(main())
'''
    test_file.write_text(code)
    print(f"✅ Тестовая заглушка создана: {test_file}")


def main():
    commands = {
        "lint": cmd_lint,
        "check-logs": cmd_check_logs,
        "test-bot": cmd_test_bot,
        "all": lambda r: (
            cmd_lint(r) if cmd_lint(r) else None,
            cmd_check_logs(r),
            cmd_test_bot(r),
        ),
    }

    if len(sys.argv) < 2 or sys.argv[1] not in commands:
        print(__doc__)
        print(f"Доступные команды: {', '.join(commands.keys())}")
        sys.exit(1)

    cmd = sys.argv[1]
    path = sys.argv[2] if len(sys.argv) > 2 else "."
    commands[cmd](path)


if __name__ == "__main__":
    main()
